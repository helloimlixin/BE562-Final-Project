/*
 * File:   median_joining.h
 * Author: Salim
 *
 * Created on November 17, 2011, 1:03 AM
 */
#ifndef MEDIAN_JOINING_H
#define	MEDIAN_JOINING_H

#include <vector>

#include "constants.h"

int
median_joining(int tot_terminals, int probes, int terminals[][MAX_PROBES],
               int **mst_node_store, int **mst_edge_store, int epsilon,
               int distance_option, int tot_scg_sets, int **scg,
               int *probes_on_chromosome);

void generate_distance_matrix(std::vector<std::vector<int> > &weight,
                              int terminals[][MAX_PROBES],
                              int tot_terminals, int probes, int start,
                              int distance_option, int tot_scg_sets,
                              int ** scg, int *probes_on_chromosome);

void return_min_index(int &row, int &col,
                      const std::vector<std::vector<int> > & distance,
                      int tot_nodes, int []);

int prune_table_local(std::vector<std::vector<int> >&, int , int);

#endif	/* MEDIAN_JOINING_H */
