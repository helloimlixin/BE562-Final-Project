#include <cmath>
#include "binary_heap.h"

// Returns the index of the parent of a node in the binary heap
// i is the index of a node of which parent will be returned
// returns the index of the parent of node at position i
int parent(int i)
{
    
    return (int)(floor(i/2));    
}

// Returns the index of the left child of a node in the binary heap
// i is the index of a node of which left child will be returned
// returns the index of the left child of node at position i
int left_child(int i)
{
    return (2 * i);
}

// Returns the index of the right child of a node in the binary heap
// i is the index of a node of which right child will be returned
// returns the index of the right child of node at position i
int right_child(int i)
{
    return (2 * i + 1);
}

// Allows the value of A[i] to move down in the min heap
// until the subtree rooted at index i becomes a min heap
// A stores the key value of the nodes in the heap
// index stores the indices of the nodes at each position
// of the A array
// i is the index on which "heapify" will be done
// size denotes the total number of nodes in the heap
void min_heapify(int A[], int index[], int i, int size)
{			
  // l are r the indices of the left and right children
  // of the node at position i
  int l = 0;
  int r = 0;
  int smallest = 0; // which of parent and two children is smallest
  int temp; // for swapping
  
  while(1){
    
    l = 2 * i;
    r = 2 * i + 1;
    
    // The smallest of the A[i], A[l] and A[r] is determined
    // and its index is stored in smallest	
    if((l <= size) && (A[l] < A[i]))
      smallest = l;
    else
      smallest = i;

    if((r <= size) && (A[r] < A[smallest]))
      smallest = r;
    
    // if A[i] is not the smallest, then the min heap property
    // is violated and the subtree rooted at node i has to be "heapified"
    if(smallest != i){
      
      // Swap the root with the smallest child		         
      temp = A[i];
      A[i] = A[smallest];
      A[smallest] = temp;
      temp = index[i];
      index[i] = index[smallest];
      index[smallest] = temp;     

      // Subtree rooted at smallest may violate the min heap property,
      // so heapify this subtree recursively
      i = smallest;
    }
    else
      break;
    
  }        
}


// Goes through each element in the first half of the array
// and calls min_heapify on each of them to build the heap
// A stores the key value of the nodes in the heap
// index stores the indices of the nodes at each position
// of the A array
// size denotes the total number of nodes in the heap 
void build_min_heap(int A[], int index[], int size)
{
    for (int i = (int)floor(size/2); i >= 1; i--)
        min_heapify(A,index, i,size);
}

// Sort the elements in A from large to small using the binary heap
// Complexity is O(nlgn)
// A stores the key value of the nodes in the heap
// index stores the indices of the nodes at each position
// of the A array
// size denotes the total number of nodes in the heap 
void heapsort(int A[], int index[], int size)
{
  // Build a min heap on the elements of A    
  build_min_heap(A, index, size);
	
  int temp; // used for swapping
  // The minimum element of A is now in A[1].
  // Swap it with A[size], decrease the size and
  // and heapify the remaining array. Continue this
  // until all elements of A are sorted large to small
  for (int i = size; i >= 1; i--){
    temp = A[i];
    A[i] = A[1];
    A[1] = temp;
    temp = index[i];
    index[i] = index[1];
    index[1] = temp;               
    size = size - 1;
    min_heapify(A, index, 1, size);    
  }
}

// Returns the element of A with minimum key. 
// A stores the key value of the nodes in the heap
// index stores the indices of the nodes at each position
// of the A array
// size denotes the total number of nodes in the heap 
// returns the minimum key
int extract_min(int A[], int index[], int size)
{

  // first element in the heap is the one with the minimum key
   int min = A[1]; 

   // Discard this minimum key element by copying the last element
   // in the array A
   A[1] = A[size];
   index[1] = index[size];

   // Reduce the size of A by 1 and readjust the heap based
   // on the subtree rooted at the first index 
   size = size - 1;
   min_heapify(A,index,1,size);

   // return the minimum key
   return min;
}


// Decrease the key of an element indexed by i
// A stores the key value of the nodes in the heap
// index stores the indices of the nodes at each position of the A array
// i stores the index of the node whose key value will be decreased
// key is the new value of A[i]
void decrase_key(int A[], int index[], int i, int key)
{
  // Change the value of A[i] to key    
  A[i] = key;
  
  int par; //index of parent
  int temp; // used for swapping

  // Changing value of A[i] may disturb the heap property of A.
  // Traverse the path from A[i] to the root, find a proper place
  // for the newly decreased key. At each stage, compare a particular
  // element to its parent and if the parent has higher key, swap
  // the parent with the element
  while (i > 1){
    par = (int)(floor(i/2));
    
    // if parent has smaller key than child, then the subtree rooted
    // at the parent node satisfies the heap property.
    if(A[par] <= A[i])
      break;

    temp = A[i];
    A[i] = A[par];
    A[par] = temp;
    temp = index[i];
    index[i] = index[par];
    index[par] = temp;        
    i = par;
  }
}

// Swap the value of two variables a and b
// a and b are passed by reference
// currently unused because swapping is being done in line.
void swap(int &a, int &b)
{
    int temp = a;
    a = b;
    b = temp;
}
