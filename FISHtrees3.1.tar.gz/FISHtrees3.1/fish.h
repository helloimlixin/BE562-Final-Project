// Pennington G, Smith CA, Shackney S, Schwartz R. Reconstructing tumor
// phylogenies from heterogeneous single-cell data. J Bioinform Comput
// Biol. 2007 Apr;5(2a):407-427.

#ifndef FISH_H
#define FISH_H

#include <string>
#include <vector>

// File name suffix for patient data files.
////#define INPUT_TXT "input.txt"
#define INPUT_TXT "txt"

// Five different options for the ploidyless modeling,
// one of which must be specified on the  command line
enum {
  NO_PLOIDY_LESS = 0,
  PLOIDY_LESS_EXACT = 1,
  PLOIDY_LESS_HEURISTIC = 2,
  PLOIDY_LESS_HEURISTIC_GENOME_DUPLICATION = 3,
  PLOIDY_LESS_HEURISTIC_WEIGHTED = 4};

// String symbol for the cell count per cell type in patient data files.
#define STR_COUNT string("count")

// File name for the directed graph of all possible nodes and edges.
#define POSSIBLE_GRAPH_DOT "possible-graph.dot"

// File name and line prefix for consensus graphs of joint ploidy and 
// gene probes on given patient data files.
#define PLOIDY_BASED "ploidy-based"

// File name and line prefix for consensus graphs of joint gene probes 
// only on given patient data files.
#define PLOIDY_LESS "ploidy-less"

// Symbol for solid edge head in text output format.
#define EDGE_SOLID_HEAD "<="

// Symbol for solid edge tail in text output format.
#define EDGE_SOLID_TAIL "=="

// Symbol for broken edge head in text output format.
#define EDGE_BROKEN_HEAD "<-"

// Symbol for broken edge tail in text output format.
#define EDGE_BROKEN_TAIL "--"

// Seed for the random number generator.
////#define SEED time(NULL)
#define SEED 314159

// Normal copy numbers of chromosomes (or ploidies) and gene probes.
// In "2.2. Probability model", "the root is always defined to be the 
// (2,2) state."
#define NORMAL_COPY 2

// Minimum and aximum copy numbers to be used in calculation.
// In "2.1. Input data", "N is 10 and any counts above 10 are collectively 
// grouped into a single row or column".
#define MIN_COPY 0
#define MAX_COPY 9
////#define MAX_COPY 10

// Minimum copy numbers of chromosomes (or ploidies) to be used in calculation.
////#define MIN_CHR_COPY 0
#define MIN_CHR_COPY 1

#define MAX_STRING 10

// Threshold to pre-filter out low-frequency state unconditional by its 
// global frequency.
#define BOUND_E .0
////#define BOUND_E .01

// Threshold to pre-filter out low-frequency state conditional on its 
// neighbor frequencies.
// In "2.1. Input data", "deleting from each patient's data any states 
// for which the observed frequency is less than a fraction f of the sum 
// of the frequencies of its neighbors. f is 10% for the single-assay 
// inferences but is increased to 30% for the tree-merging study".
#define BOUND_F .0
////#define BOUND_F .1

// Threshold to terminate EM.
// In "2.4. Parameter inference", "For the maximization stage of the
// algorithm, we use the fraction of edges assigned to each type in the 
// expectation phase as a maximum likelihood estimate of that edge 
// type's prior probability for the next EM round. We repeat the above 
// steps until all parameters converge with an error of less than one 
// percent".
#define BOUND_P .005
////#define BOUND_P .01

// Threshold to include a pathway into consensus graph.
// In "2.5. Identifying a global consensus network", "Those pathways 
// occurring in a t fraction of trees are added to the global consensus 
// network. For the present study, t = 5%".
////#define BOUND_T .0
#define BOUND_T .05
////#define BOUND_T 1.0

// Monotonic changes of copy numbers of chromosomes (or ploidies).
////#define MONO_CHR 0
#define MONO_CHR 1

// Match copy numbers of chromosomes (or ploidies) when merge two gene probes.
// In "2.7. Merging trees across assays", "when probe sets overlap 
// between the trees. In such cases, we can penalize joint states with 
// disagreement in probe values across assays".
////#define MATCH_CHR 1
#define MATCH_CHR 0

// Edges in parent trees can appear multiple times in the joint tree, 
// in which nodes in one of the parent trees can be paired with multiple 
// nodes in the other parent tree.
// In "2.7. Merging trees across assays", "each edge found in one of the 
// parent trees appears exactly once in the joint tree".
////#define MANY_TO_MANY 0
#define MANY_TO_MANY 1

#if ((((MONO_CHR) != 0) && ((MONO_CHR) != 1)) || \
     (((MATCH_CHR) != 0) && ((MATCH_CHR) != 1)) || \
     (((MANY_TO_MANY) != 0) && ((MANY_TO_MANY) != 1)))
#error "Error: MONO_CHR, MATCH_CHR and MANY_TO_MANY must be 0 or 1"
#endif

// Minutes to time out the SCIP MIP solver.
// When SCIP times out, there is usually a gap between the primal bound and the
// dual bound, but it returns a feasible solution
////#define TIMEOUT 5
#define TIMEOUT 60

// Number of mutation types.
// In "2.2. Probability model", "four possible known molecular 
//mechanisms for tumorigenesis".
////#define MUTATION_TYPES 4 // INVALID = -2 // MIN_CHR_COPY 0 // MATCH_CHR 1 
#define MUTATION_TYPES 6 // INVALID = -1
////#define MUTATION_TYPES 7 // INVALID = -1

// Defines the maximum number of states (terminals) in the patient file
#define MAX_TERMINALS 1000

// Encode, in a macro, the rule that setting MUTATION_TYPES == 4 is
// the same as using gene probes only.
#define GENE_PROBES_ONLY ((MUTATION_TYPES)==4)

#if (MUTATION_TYPES) != 4 && (MUTATION_TYPES)!= 6 && (MUTATION_TYPES) != 7
#  error "Invalid value for MUTATION_TYPES"
#endif

// Declare mutation types as edges, which connect two nodes of states.
// In "2.2. Probability model", "p_g+ for gene gain, p_g- for gene loss, 
// p_c+ for chromosome duplication, and p_c- for chromosome loss".
enum mutation_type
{
#if GENE_PROBES_ONLY
  INVALID = -2,  // Invalid state change when only using gene probes
#else
  INVALID = -1,  // Invalid state change for MUTATION_TYPES = 6|7.
#endif
  CHR_GENE_LOSS, // Chromosome with gene loss.
  CHR_LOSS,      // Chromosome loss.
  GENE_LOSS,     // Gene loss.
  GENE_GAIN,     // Gene gain.
  CHR_GAIN,      // Chromosome gain.
  CHR_GENE_GAIN, // Chromosome with gene gain.
  CHR_GENE_DUPL // Chromosome with gene duplication.
};

// Declare matrix of MAX_COPY+1 columns by MAX_COPY+1 rows of integers.
typedef int int_matrix[MAX_COPY+1][MAX_COPY+1];

// Declare vector of MUTATIONS_TYPES real numbers.
typedef double double_vector[MUTATION_TYPES];

// Declare vector of MUTATIONS_TYPES integers.
typedef int int_vector[MUTATION_TYPES];

typedef std::vector<std::string> vec_names;

#endif
