/*
 * File:   binary_heap.h
 * Author: Salim
 *
 * Created on April 4, 2012, 1:05 AM
 */
#ifndef BINARY_HEAP_H
#define	BINARY_HEAP_H

//Standard operations for a binary heap
//in this implementattion the minimum item is at A[1]
//Procedures are commented in binary_heap.cpp
int parent(int i);
int left_child(int i);
int right_child(int i);
void min_heapify(int A[], int index[], int i, int size);
void build_min_heap(int A[], int index[], int size);
void heapsort(int A[], int index[], int size);
int extract_min(int A[], int index[], int size);
void decrase_key(int A[], int index[], int i, int key);
void swap(int &a, int &b);
#endif	/* BINARY_HEAP_H */
