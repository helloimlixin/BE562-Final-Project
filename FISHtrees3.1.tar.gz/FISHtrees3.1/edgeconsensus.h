// In "2.5. Identifying a global consensus network", "We then find a
// global consensus network by identifying all pathways used in at least
// some fraction t of all patients. Given the per-patient trees T_1,
/// ..., T_n, we can identify consensus pathways by searching
// depth-first through each tree individually and then, for each node,
// counting how many other trees have the same node and exhibit the same
// pathway from that node to the root. Those pathways occurring in a t
// fraction of trees are added to the global consensus network. For the
// present study, t = 5%. Note that this consensus network need not
// itself be a tree, since a node may be reachable by more than one
// common pathway in different individual trees."

// Definition of consensus edge (used in consensus graph).

#ifndef EDGECONSENSUS_H
#define EDGECONSENSUS_H

#include <vector>

#include "nodeconsensus.h"
#include "edge.h"

// Declare directed edge to represent a mutation from one consensus node 
// to another consensus node.
class edgeconsensus
{
  // Mutation type from source to target node.
  // Can be assigned by class constructor.
  int type;

  // Tail node as source of directed edge.
  nodeconsensus *tail;

  // Head node as target of directed edge.
  nodeconsensus *head;

  // Number of patient data files (as joint trees).
  // Will be used as the size of the vector_of_edges.
  int number_of_files;

  // Number of patient data files (as joint trees) in which this edge occurs.
  // Therefore has a valid reference to a joint edge in the vector_of_edges.
  int number_of_trees_sharing_edge;

  // Array (as vector) of references (as C/C++ pointers) to joint edges
  // in joint trees.
  // vector_of_edges[i] represents the reference to the joint edge in
  // the i-th joint tree.
  // vector_of_edges[i] is NULL if this consensus edge does not occur in
  // the i-th joint tree.
  std::vector<edge *> vector_of_edges;

  // Unary operator for output.
  friend std::ostream &operator<<(std::ostream &, const edgeconsensus &);

public:
  // Class constructor.
  edgeconsensus();

  // Class constructor given references to tail/source and head/target 
  // nodes, mutation type, and number of patient data files.
  // The type is shared among all joint edges in vector_of_edges and
  // this requirement is used in the constructor to identify all the
  // joint edges that should be referred to by this consensus edge.
  edgeconsensus(nodeconsensus *, nodeconsensus *, int, int);

  // Get tail/source node of this edge.
  nodeconsensus *get_tail();

  // Get head/target node of this edge.
  nodeconsensus *get_head();

  // Set the corresponding reference in vector_of_edges to the given
  // index and joint edge.
  void set_edge_in_vector(int, edge *);

  // Get the corresponding reference to the joint edge in
  // vector_of_edges by the given index.
  edge *get_edge_in_vector(int);

  // Get ratio of this consensus edge among all joint nodes.
  double get_ratio();

  // Get type of this edge.
  int get_type();

};

#endif
