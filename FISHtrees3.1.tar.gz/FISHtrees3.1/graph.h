// A graph of nodes and edges represents a data structure for a pair of 
// ploidy or chromosome probe and gene probe for a patient.
// In "2.3. Optimal tree inference", "a directed graph G = (V,E), where
// V is the set of observed states, and E is the set of all possible
// single mutation events connecting pairs of states in V".
// In "2.3. Optimal tree inference", "Let G' = (V',E') be a directed
// graph of all possible states and edges".
// In "2.3. Optimal tree inference", "find an optimal phylogenetic tree 
// for each patient using an algorithm for finding minimum weight 
// directed spanning trees (arborescences)".
// In "2.3. Optimal tree inference", "Convert the FISH matrix for an    
// individual patient into a graph G".
// In "2.5. Identifying a global consensus network", "find a best-fit 
// tree for each patient and a global consensus network for the entire 
// population".
// In "2.7. Merging trees across assays", "a merge graph G = (V,E) where 
// V = V_A x V_B and E = {((u_A,w_B),(v_A,w_B))|(u_A,v_A) \in E_A} \cup 
// {((w_A,u_B),(w_A,v_B))|(u_B,v_B) \in E_B}".

#ifndef GRAPH_H
#define GRAPH_H

#include <map>
#include <list>
#include <string>

#include "obs_graph.h"
#include "node.h"
#include "edge.h"

//weight of the self loop
const double INF = 10000;
const double NEGINFINITY = -10000.0;

// Declare graph to represent a set of states of copy numbers of 
// chromosome probe and gene probe per patient as nodes and possible 
// mutations as edges.
class graph
{
protected:
  // Label of chromosome and gene names.
  std::string label;

public:
  // Number of nodes. (TO BE MOVED INTO PRIVATE)
  int size;

  // Root node to represent normal cell.
  node *root;

  // List of nodes.
  std::list<node *> list_of_nodes;

  // Table of edges.
  edge ***table_of_edges;

  // Class constructor.
  graph();

  // Class constructor with given label string.
  explicit graph(std::string);

  // Class destructor.
  ~graph();
  
  void addnode(node *);

  // Output a set of all nodes owned by this graph, including children
  // of joint nodes.
  void all_owned_nodes(std::set<node*> & nodes);

  // Delete nodes of the graph, including children of joint nodes.
  void deep_delete_nodes();

  // Delete direct nodes of the graph, but not children of joint
  // nodes.
  void shallow_delete_nodes();

  // Clear and reset graph edges.
  void clear();

  // Get label of this graph.
  std::string get_label();

  // Get list of references to nodes in this graph.
  std::list<node *> *get_list_of_nodes();

  //   
  void initialize_table_of_edges(int **, int **, int, node ***, int, int,int, int, int**, int*);

  void initialize_table_of_edges_par(int **, int, node ***, int, int,
                                     std::vector<std::vector<double> > );

  // Construct graph of nodes and edges for non-zero frequency states.
  void set_nodes_and_edges(const std::string&, const std::string&,
                           const obs_graph &,
                           std::list<std::map<std::string,int> > *);

  // Calculate mutation prior probabilities in this graph.
  void calculate_mutation_probabilities(double_vector);

  // Set edge weight to be node frequency times edge probability.
  // In "2.3. Optimal tree inference", "Once we have ensured that every 
  // node of G is reachable, we add a weight function w(v,u) = f_v p(v,u)
  // to G and find an optimal phylogenetic tree for each patient using an
  // algorithm for finding minimum weight directed spanning trees
  // (arborescences) due to Chu and Liu".
  // In "2.4. Parameter inference", "For each possible parent v of u,
  // excluding current descendants, compute w(v,u) = f_v p(v,u), where f_v
  // is v's node frequency and p(v,u) is the prior probability of the edge
  // type from v to u".
  void set_edge_weight_frequency_times_probability(double_vector);

  // Set edge weight to be minus the log of its probability.
  // In "2.3. Optimal tree inference", "Solve the multiple source shortest
  // path problem from R to v* in G', where the weight of an edge e \in E'
  // is equal to -log p_e (minus the log of its probability)".
  // In "2.3. Optimal tree inference", "Add all edges to G allowed by the
  // connectivity model of Sec. 2.2, each weighted as minus the log of its
  // probability".
  void set_edge_weight_minus_log_probability(double_vector);
  void set_edge_weight_probability(double_vector);
  void take_log_of_weights_for_highweight_branching();

  // Get dual nodes (nodes in G') that correspond to nodes a)
  // reachable in the graph; b) present in the graph but unreachable
  void get_dual_nodes(obs_graph::node_set & reachable,
                      obs_graph::node_set & unreachable);

  // Get number of nodes in this graph.
  int get_number_of_nodes();

  // Get parent node as the tail of an edge of a given node as the head
  // of an edge, assuming this graph is a tree.
  node *get_parent_node(node *);

  // Get parent edge where a given node is the head of the edge, 
  // assuming this graph is a tree.
  edge *get_parent_edge(node *);

  // Test whether a given node is a leaf node, assuming this graph is a tree.
  bool is_leaf(node *);

  // Remove a node from this graph.
  int delete_node(node *ref_node);

  // Trim leaf Steiner nodes recursively.
  int trim_leaf_steiner_nodes();

  // Calculate accumulated observed probabilities of all descendants.
  double accumulate_observed_probabilities(node *);

  // Calculate accumulated modeled probabilities of all descendants.
  double accumulate_modeled_probabilities(node *);

  // Stable-sort weights among incoming edges for the given node.
  int stable_sort_by_edge_weights(node *ref_node, std::list<edge *> *);
};

// Test whether this graph is acyclic. It does so by repeatedly deleting
// nodes which are sources or sinks. In an acyclic graph, this process
// will end in an edge-free graph. Parameter top indicates whether this
// is a call from outside (top = true) or a recursive call (top = false).

/*basic functions for manipulating graphs*/

/*makeEdge allocates memeory for an edge, and assigns initial
  values to its fields */
edge *makeEdge (/***char *label,***/ node *tail, node *head, edge *oldEdge,
		double prob, double wt, double distance, int occ);

void addEdgeLabels(graph *G);

/*This function assigns indices to nodes of G*/
void assignIndices(graph *G);

/*We assume that T is a tree; the function returns TRUE
  if node v is a leaf of T, root is the root of T*/
bool leaf(node *v, graph *T, node * root);

/*copyEdge calls makeEdge to make a copy of a given edge */
edge *copyEdge (edge *e);

/* procedure for deleting edge from a graph, also breaks parent links*/
void deleteEdge(edge *e, graph *G);

/*source returns TRUE if vertex v has indegree 0 in graph G*/
bool source (graph *G, node *v);

/*sink returns TRUE if vertex v has outdegree 0 in graph G*/
bool sink (graph *G, node *v);

/*free the dynamically allocated memory associated with graph G*/
void deleteGraph(graph *G);

/*initialize edges table of G.  Requires G->size to be already fixed.*/
void initEdges(graph *G);

/*straightforward function for copying a graph, creating duplicates of
  all edges and nodes */

/*function counts the number of nodes on a graph*/
int countNodes(graph *G);

/*test whether a graph is acyclic.  It does so by repeatedly deleting
  nodes which are sources or sinks.  In an acyclic graph, this process will
  end in an edge-free graph. TOP indicates whether this is a call
  from outside (TRUE) or a recursive call (FALSE) */
bool isAcyclic(graph *G, bool TOP);

/*flowIn returns weight of (v1,v2) if v1 is a parent of v2
  in graph G, NEGINFINITY,   otherwise */
double flowIn (node *v1, node *v2, graph *G);

/*finds heaviest edge in G with head at v.  Considers only
  positive weight edges.  If no edge is found, points to NULL*/
edge *findHeavyEdge(node *v, graph *G);

/* assignParents sets the parent fields of the nodes of G to correspond
   to the edges of G.  If any node of G has more than one incoming edge,
   assignParents will flag an error. */           
void assignParents(graph *G/*****, graph *H*****/);

#endif
