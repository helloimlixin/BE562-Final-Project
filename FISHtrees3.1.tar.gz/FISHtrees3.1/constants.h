#ifndef CONSTANTS_H
#define CONSTANTS_H

// Maximum number of probes present in the patient file
#define MAX_PROBES 12

// Maximum number of candidate steiner nodes allowed 
// for generating the steiner tree using the exact approach
#define MAX_STEINER_NODES_EXACT 3

// Maximum number of candidate steiner nodes allowed 
// for generating the steiner tree using the heuristic approach
#define MAX_STEINER_NODES_HEURISTIC 300

// Maximum number of iterations allowed in the steiner tree
// inference algorithm
#define MAX_ITERATION 20

// Maximum number of candidates in the exact approach
#define MAX_CANDIDATES 100000


// Maximum number of triplets that would be generated at each step of the 
// heuristic approach
#define MAXIMUM_TRIPLETS 10000

#endif
