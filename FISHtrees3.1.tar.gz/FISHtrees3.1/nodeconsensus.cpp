// In "2.5. Identifying a global consensus network", "We then find a 
// global consensus network by identifying all pathways used in at least 
// some fraction t of all patients. Given the per-patient trees T_1, 
/// ..., T_n, we can identify consensus pathways by searching 
// depth-first through each tree individually and then, for each node, 
// counting how many other trees have the same node and exhibit the same 
// pathway from that node to the root. Those pathways occurring in a t 
// fraction of trees are added to the global consensus network. For the 
// present study, t = 5%. Note that this consensus network need not 
// itself be a tree, since a node may be reachable by more than one 
// common pathway in different individual trees."

// Implementation of consensus node (used in consensus edge and graph).

#include <iomanip>
#include <iostream>

#include "nodeconsensus.h"

using namespace std;

// Class constructor.
nodeconsensus::nodeconsensus()
{
  // Initialize index to be -1.
  index = -1;

  // Initialize label to be an empty string.
  label.clear();

  // Initialize number of files to be -1.
  number_of_files = -1;

  // Initialize number of nodes to be -1.
  number_of_trees_sharing_node = -1;

  frequency = 0;
  observed = 0;
}

// Class constructor given index of the consensus node among all nodes 
// in the consensus graph, label of the consensus node, and number of
// patient data files.
// The label is shared among all joint nodes in vector_of_nodes and
// this requirement is used in the constructor to identify all the
// joint nodes that should be referred to by this consensus node.
nodeconsensus::nodeconsensus(int in_index, string in_label, 
  int in_number_of_files) : vector_of_nodes(in_number_of_files, (node*)0)
{
  // Initialize index to be in_index.
  index = in_index;

  // Initialize label to be in_label.
  label = in_label;

  // Initialize number of files to be in_number_of_files.
  number_of_files = in_number_of_files;

  // Initialize number of nodes to be 0.
  number_of_trees_sharing_node = 0;

  frequency = 0;
  observed = 0;
}

// Output node index and label with indices of joint nodes in joint trees.
ostream &operator<<(ostream &output, const nodeconsensus &node0)
{
  // Write index and label of this consensus node.
  output << node0.index<< "{";

  // Declare if the first joint node to be output.
  bool is_first = true;

  // Loop through every reference to joint node in vector_of_nodes.
  for (int index_file = 0; index_file < node0.number_of_files; 
    index_file++)
  {
    // Check if this is the first joint node to be output.
    if (is_first)
    {
      // Set the first joint node flag to be false.
      is_first = false;
    }
    else 
    {
      // Write comma sign as delimiter.
      output << ",";
    }

    // Check if each reference to joint node is NULL.
    if (node0.vector_of_nodes[index_file] == NULL)
    {
      // Write invalid index if reference is NULL.
      output << "-1";
    }
    else
    {
      // Write index of joint node.
      output << (node0.vector_of_nodes[index_file])->index;
    }
  }
  output << "}";
  return output;
}

// Compare if label of node1 is smaller than label of node2.
bool operator<(const nodeconsensus &node1, const nodeconsensus &node2)
{
  // Return compare result.
  return (node1.label.compare(node2.label) < 0);
}

// Compare if label of node1 is larger than label of node2.
bool operator>(const nodeconsensus &node1, const nodeconsensus &node2)
{
  // Return compare result.
  return (node1.label.compare(node2.label) > 0);
}

// Compare if label of node1 is the same as label of node2.
bool operator==(const nodeconsensus &node1, const nodeconsensus &node2)
{
  // Return compare result.
  return (node1.label.compare(node2.label) == 0);
}

// Compare if label of node1 is different from label of node2.
bool operator!=(const nodeconsensus &node1, const nodeconsensus &node2)
{
  // Return compare result.
  return (node1.label.compare(node2.label) != 0);
}

// Set the corresponding reference in vector_of_nodes to the given
// index and joint node.
void nodeconsensus::set_node_in_vector(int index_file, node *ref_node)
{
  // Check if current corresponding reference is NULL.
  if (vector_of_nodes[index_file] == NULL)
  {
    // Increase number of valid refernces to joint nodes if this 
    // assignment is not a replacement and hence the if test succeeded.
    number_of_trees_sharing_node++;
  }

  // Copy the given reference to joint node into vector_of_nodes.
  vector_of_nodes[index_file] = ref_node; 
}

// Get the corresponding reference to the joint node in
// vector_of_nodes by the given index.
node *nodeconsensus::get_node_in_vector(int index_file)
{
  // Return reference to joint node.
  return vector_of_nodes[index_file]; 
}

// Get ratio of this consensus node among all joint nodes.
double nodeconsensus::get_ratio()
{
  // Return ratio of number_of_trees_sharing_node divided by 
  // number_of_files.
  return ((double)number_of_trees_sharing_node / (double)number_of_files);
}

// Return true if this node is the root node of any of the constituent
// trees.
bool nodeconsensus::is_a_root()
{
  vector<node*>::iterator n = this->vector_of_nodes.begin();
  vector<node*>::iterator n_end = this->vector_of_nodes.end();
  for ( ;  n != n_end;  ++n ) {
    if ( *n != NULL && (*n)->parent == NULL )
      return true;
  }
  return false;
}
