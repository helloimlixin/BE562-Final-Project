// In "2.5. Identifying a global consensus network", "We then find a
// global consensus network by identifying all pathways used in at least
// some fraction t of all patients. Given the per-patient trees T_1,
/// ..., T_n, we can identify consensus pathways by searching
// depth-first through each tree individually and then, for each node,
// counting how many other trees have the same node and exhibit the same
// pathway from that node to the root. Those pathways occurring in a t
// fraction of trees are added to the global consensus network. For the
// present study, t = 5%. Note that this consensus network need not
// itself be a tree, since a node may be reachable by more than one
// common pathway in different individual trees."

#include <functional>

#include "consensus.h"

using namespace std;

// Build a consensus network as graph on all joint trees.
void consensus_network(graphconsensus **ref_consensus_graph, 
  graph *joint_tree[], int number_of_files)
{
  // Declare consensus graph for returning results.
  *ref_consensus_graph = new graphconsensus();

  // Declare list of labels as strings.
  list<string> list_of_labels;

  // Loop through every joint tree.
  for (int index_file = 0; index_file < number_of_files; index_file++)
  {
    // Get reference to list of references to joint nodes in each joint tree.
    list<node *> *list_of_joint_nodes = 
      joint_tree[index_file]->get_list_of_nodes();

    // Iterate on list of references to joint nodes in each joint tree.
    list<node *>::iterator ref_joint_node;

    // Loop through every reference to joint node.
    for (ref_joint_node = list_of_joint_nodes->begin(); 
      ref_joint_node != list_of_joint_nodes->end(); 
      ++ref_joint_node)
    {
      // Retrieve and store each node label.
      list_of_labels.push_back((*ref_joint_node)->get_label());
    }
  }

  // Sort list of labels.
  list_of_labels.sort();

  // Remove deplicated labels from list of labels.
  list_of_labels.unique(equal_to<string>());

  // Declare number of nodes in the consensus graph.
  int number_of_consensus_nodes = 0;

  // Iterate on list of labels.
  list<string>::iterator ref_label;

  // Loop through every label in list; labels are in ascending order;
  // indices are assigned to consensus starting at 0 with increment 1;
  // add one consensus node at one time.
  for (ref_label = list_of_labels.begin(); ref_label != list_of_labels.end(); 
    ++ref_label)
  {
    // Create new consensus node.
    nodeconsensus *ref_consensus_node = new 
      nodeconsensus(number_of_consensus_nodes, *ref_label, number_of_files);

    // Declare modeled probability to be 0.0.
    double modeled_consensus = 0.0;

    // Declare observed probability to be 0.0.
    double observed_consensus = 0.0;

    // Loop through every joint tree.
    for (int index_file = 0; index_file < number_of_files; index_file++)
    {
      // Get reference to list of references to joint nodes in each joint tree.
      list<node *> *list_of_joint_nodes = 
        joint_tree[index_file]->get_list_of_nodes();

      // Iterate on list of references to joint nodes in each joint tree.
      list<node *>::iterator ref_joint_node;

      // Loop through every reference to joint node.
      for (ref_joint_node = list_of_joint_nodes->begin(); 
        ref_joint_node != list_of_joint_nodes->end(); 
        ++ref_joint_node)
      {
        // Retrieve node index.
        //int index_joint_node = (*ref_joint_node)->get_index();

        // Retrieve node label.
        string label_joint_node = (*ref_joint_node)->get_label();

        // Check if labels of nodes are the same.
        if ((*ref_label).compare(label_joint_node) == 0)
        {
          // Add reference to joint node into vector of nodes.
          ref_consensus_node->set_node_in_vector(index_file, 
            (*ref_joint_node));

          // Add modeled probability from the joint node to consensus node.
          modeled_consensus += (*ref_joint_node)->get_modeled();

          // Add observed probability from the joint node to consensus node.
          observed_consensus += (*ref_joint_node)->get_observed();
        }
      }
    }

    // Calculate average modeled probability among joint trees.
    ref_consensus_node->frequency = 
      modeled_consensus / (double)number_of_files;

    // Calculate average observed probability among joint trees.
    ref_consensus_node->observed = 
      observed_consensus / (double)number_of_files;

    // Add consensus node into consensus graph.
    (*ref_consensus_graph)->add_node(ref_consensus_node);

    // Increase number of consensus nodes by 1.
    number_of_consensus_nodes++;
  }

  // Set up consensus edges in consensus graph.
  (*ref_consensus_graph)->set_edges(joint_tree, number_of_files);
}
