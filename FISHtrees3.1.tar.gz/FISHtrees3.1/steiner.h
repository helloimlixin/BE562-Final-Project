// In "2.3. Optimal tree inference", "In order to ensure that every 
// state in G is reachable from the root (defined as the (2,2) state), 
// we then add Steiner nodes with a heuristic method presented as 
// Algorithm 1. These Steiner nodes are inferred to be states that were 
// present at one point in the evolution of the tumor but either died 
// off or were missed during data collection due to inadequate sampling".
// "Algorithm 1 Heuristic algorithm for Steiner node inference
// 1: Given G = (V,E). Let G' = (V',E') be a directed graph of all 
//    possible states and edges, and let R \subseteq V be the set of 
//    vertices of G reachable from the root.
// 2: while R \neq V do
// 3:   Perform a breadth-first traversal of G' starting from R and 
//      stopping when we encounter a vertex v \in V - R. Let k be the 
//      distance from R to v (the length of the path found by BFS).
// 4:   Consider all nodes in V - R at distance k from R, and let v* be 
//      the one from which we can reach the most nodes in V - R (the 
//      largest island).
// 5:   Solve the multiple source shortest path problem from R to v* in 
//      G', where the weight of an edge e \in E' is equal to -log p_e 
//      (minus the log of its probability).
// 6:   Add the nodes and edges on the shortest path from V to v* in G.
// 7: end while".

#ifndef STEINER_H
#define STEINER_H

#include <vector>
#include <list>
#include <map>
#include <set>
#include <string>

#include "fish.h"
#include "obs_graph.h"
#include "graph.h"

// In "2.3. Optimal tree inference", "Algorithm 1 Heuristic algorithm 
// for Steiner node inference".
void
perform_steiner_node_inference(graph *, const std::string &,
                               const std::string &, obs_graph & gr,
                               double_vector,
                               std::list<std::map<std::string,int> > *);

#endif
