// In "2.5. Identifying a global consensus network", "We then find a 
// global consensus network by identifying all pathways used in at least 
// some fraction t of all patients. Given the per-patient trees T_1, 
/// ..., T_n, we can identify consensus pathways by searching 
// depth-first through each tree individually and then, for each node, 
// counting how many other trees have the same node and exhibit the same 
// pathway from that node to the root. Those pathways occurring in a t 
// fraction of trees are added to the global consensus network. For the 
// present study, t = 5%. Note that this consensus network need not 
// itself be a tree, since a node may be reachable by more than one 
// common pathway in different individual trees."

// Implementation of consensus graph.

#include <algorithm>
#include <fstream>
#include <iomanip>
#include <map>
#include <set>
#include <sstream>

#include <cfloat>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cassert>

#include "consensus_trees.h"
#include "graphconsensus.h"

#ifndef VERBOSE
#define VERBOSE 0
#endif

using namespace std;

struct nodeconsensus_index_less {
  bool operator()(const nodeconsensus * a, const nodeconsensus * b) const
  {
    return a->get_index() < b->get_index();
  }
};

struct edge_index_less {
  bool operator()(const graphconsensus::consensus_pair & a,
                  const graphconsensus::consensus_pair & b) const
  {
    if(a.first->get_index() < b.first->get_index())
      return true;

    if(a.first->get_index() > b.first->get_index())
      return false;

    // Nil parent always comes first
    if (a.second == 0)
      return b.second != 0;  // If both are nil, equal (so return false)

    // a.second is not nil, so if b.second == 0, 'a' must be first
    if (b.second == 0)
      return false;

    return a.second->get_index() < b.second->get_index();
  }
};

struct as_node_stats {
  int count;
  double observed, modeled;

  as_node_stats (const child_parent_map & parents,
                 const graphconsensus::count_to_node_map & name_nodes) :
    count(), observed(), modeled()
  {
    child_parent_map::const_iterator p, pend = parents.end();
    for (p = parents.begin();  p != pend;  ++p) {
      count++;
      observed += name_nodes.at(p->first)->get_observed();
      modeled += name_nodes.at(p->first)->get_modeled();
    }
  }
  as_node_stats (const node_set & nodes,
                 const graphconsensus::count_to_node_map & name_nodes) :
    count(), observed(), modeled()
  {
    node_set::const_iterator p, pend = nodes.end();
    for (p = nodes.begin();  p != pend;  ++p) {
      count++;
      observed += name_nodes.at(*p)->get_observed();
      modeled += name_nodes.at(*p)->get_modeled();
    }
  }
};

ostream &
operator<<(ostream & s, const as_node_stats & stats)
{
  int precision = s.precision(5);
  s << stats.count << "\t" << stats.observed << "\t" << stats.modeled;
  s.precision(precision);
  return s;
}

// Build a string showing the copy number of all ploidy/gene probes given
// the label stored in a node.  This routine is primarily for display,
// because the full labels are quite verbose.
//
// For joint nodes, the ploidy probe will be repeated, because ploidy
// mismatched nodes are technically possible, though biologically suspect.
string label_to_config(const string & label)
{
  string config;
  size_t cursor = 0;
  while (1) {
    // Skip the first parenthesized group
    cursor = label.find_first_of('(', cursor);
    if (cursor == string::npos)
      break;
    cursor++;

    size_t pos_open_paren = label.find_first_of('(', cursor);
    size_t pos_close_paren = label.find_first_of(')', pos_open_paren + 1);
    cursor = pos_close_paren + 1;

    string counts =
      label.substr(pos_open_paren+1, pos_close_paren - pos_open_paren - 1);

    size_t pos_comma = counts.find_first_of(',');
    counts[pos_comma] = ';';

    if (!config.empty()) {
      config += ";";
    }
    config += counts;
  }
  return config;
}

// Destructor
graphconsensus::~graphconsensus()
{
  int size = list_of_nodes.size();
  if (table_of_edges) {
    for(int i = 0;  i < size;  i++) {
      if (table_of_edges[i]) {
        for (int j = 0;  j < size;  j++) {
          delete table_of_edges[i][j];
        }
        delete [] table_of_edges[i];
      }
    }
    delete [] table_of_edges;
  }
  list<nodeconsensus*>::iterator nn;
  for (nn = list_of_nodes.begin();  nn != list_of_nodes.end();  ++nn) {
    delete *nn;
  }
}


// Add reference to given consensus node at the end of list_of_nodes.
void graphconsensus::add_node(nodeconsensus *ref_node)
{
  // Add given consensus node at the end of the list_of_nodes.
  list_of_nodes.push_back(ref_node);
}

// Set up table of references to consensus edges given a vector of
// joint trees and number of joint trees.
void graphconsensus::set_edges(graph *joint_tree[], int number_of_files)
{
  int size = list_of_nodes.size();

  // Allocate storage for table of references to consensus edges.
  table_of_edges = new edgeconsensus**[size];

  // Loop through every node in the first dimension of table of edges.
  for (int index_node = 0; index_node < size; index_node++)
  {
    // Allocate storage for the second dimension of table of edges.
    table_of_edges[index_node] = new edgeconsensus*[size];
  }

  // Loop through every tail/source node of an edge.
  for (int index_tail = 0; index_tail < size; index_tail++)
  {
    // Loop through every head/target node of an edge.
    for (int index_head = 0; index_head < size; index_head++)
    {
      // Initialize edge reference to null.
      table_of_edges[index_tail][index_head] = NULL;
    }
  }

  // Declare mapping from index of consensus node to its reference to 
  // consensus node.
  map<int,nodeconsensus *> map_index_to_ref;

  // Declare mapping from index of joint node per patient data file 
  // (as joint tree) to index of consensus node.
  vector<map<int,int> > map_joint_to_consensus(number_of_files);

  // Iterate on list of references to consensus nodes.
  list<nodeconsensus *>::iterator ref_consensus_node;

  // Loop through every reference to consensus node.
  for (ref_consensus_node = list_of_nodes.begin();
    ref_consensus_node != list_of_nodes.end(); ++ref_consensus_node)
  {
    // Map index of consensus node to its reference.
    map_index_to_ref[(*ref_consensus_node)->get_index()] = 
      (*ref_consensus_node);

    // Loop through every joint tree.
    for (int index_file = 0; index_file < number_of_files; index_file++)
    {
      // Get corresponding joint node of the consensus node.
      node *ref_joint_node = 
        (*ref_consensus_node)->get_node_in_vector(index_file);

      // Check if corresponding joint node exists.
      if (ref_joint_node != NULL)
      {
        map_joint_to_consensus[index_file][ref_joint_node->get_index()] 
          = (*ref_consensus_node)->get_index();
      }
    }
  }

  // Loop through every reference to consensus node.
  for (ref_consensus_node = list_of_nodes.begin();
    ref_consensus_node != list_of_nodes.end(); ++ref_consensus_node)
  {
    // Map index of consensus node to its reference.
    map_index_to_ref[(*ref_consensus_node)->get_index()] = 
      (*ref_consensus_node);

    // Loop through every joint tree.
    for (int index_file = 0; index_file < number_of_files; index_file++)
    {
      // Get corresponding joint node of the consensus node.
      node *ref_joint_node = 
        (*ref_consensus_node)->get_node_in_vector(index_file);

      // Check if corresponding joint node exists.
      if (ref_joint_node != NULL)
      {
        // Get parent edge of the joint node from the corresponding 
        // joint tree.
        edge *ref_joint_edge = 
          joint_tree[index_file]->get_parent_edge(ref_joint_node);

        // Check if the parent joint edge is NULL where the joint node 
        // is the root node of the corresponding joing tree.
        if (ref_joint_edge == NULL)
        {
          // Set root reference to the current consensus node.
          root = (*ref_consensus_node);
        }
        // Check if the parent joint edge is valid given the joint node 
        // (as the head/target node) of the joint edge.
        else
        {
          // Get reference to the parent consensus node.
          nodeconsensus *ref_parent_consensus_node = 
            map_index_to_ref[map_joint_to_consensus[index_file][ref_joint_edge->get_tail()->get_index()]];

          // Get index of the tail/source node of consensus edge.
          int index_tail = ref_parent_consensus_node->get_index();

          // Get index of the head/target node of consensus edge
          int index_head = (*ref_consensus_node)->get_index();

          // Check if the corresponding edge in table of edges is NULL.
          if (table_of_edges[index_tail][index_head] == NULL)
          {
            // Create reference to new consensus edge where the 
            // tail/source node is the parent consensusnode, the 
            // head/target node is the current consensus node and the 
            // edge type is copied from the corresponding joint edge.
            table_of_edges[index_tail][index_head] = new 
              edgeconsensus(ref_parent_consensus_node, 
              *ref_consensus_node, ref_joint_edge->get_type(), 
              number_of_files);
          }

          //  Add reference to joint edge into vector of edges.
          table_of_edges[index_tail][index_head]->set_edge_in_vector(index_file,
            ref_joint_edge);
        }
      }
    }
  }
}


graphconsensus::count_to_node_map
graphconsensus::map_counts_to_nodes()
{
  count_to_node_map name_nodes;
  list<nodeconsensus*>::const_iterator p, pend = this->list_of_nodes.end();
  for (p = this->list_of_nodes.begin();   p != pend;  ++p) {
    string node_name = label_to_config((*p)->get_label());
    name_nodes[node_name] = *p;
  }
  return name_nodes;
}

vec_child_parent_map
graphconsensus::find_constituent_trees(const count_to_node_map & name_nodes)
{
  const list<nodeconsensus*> & nodes = this->list_of_nodes;
  edgeconsensus *** edges = this->table_of_edges;
  int number_of_trees = this->number_of_files();

  vec_child_parent_map trees(number_of_trees);
  int nnodes = nodes.size();

  vector<string> node_names(name_nodes.size());
  count_to_node_map::const_iterator q, qend = name_nodes.end();
  for(q = name_nodes.begin();  q != qend;  ++q) {
    node_names[q->second->get_index()] = q->first;
  }
  for (int tree_index = 0;  tree_index < number_of_trees;  tree_index++) {
    map<string,string> & tree = trees[tree_index];
    list<nodeconsensus*>::const_iterator p, pend = nodes.end();
    int child_index = 0;

    for (p = nodes.begin();  p != pend;  ++p, ++child_index) {
      if (NULL == (*p)->vector_of_nodes[tree_index])
        continue;  // not in graph
      int parent_index;
      for (parent_index = 0;  parent_index < nnodes;  parent_index++) {
        edgeconsensus * edge = edges[parent_index][child_index];
        if (NULL != edge && NULL != edge->get_edge_in_vector(tree_index))
          break;
      }
      if (parent_index == nnodes) {
        tree[ node_names[child_index] ] = "nil";
      } else {
        tree[ node_names[child_index] ] = node_names[parent_index];
      }
    }
  }
  return trees;
}

// Find all nodes that are a) observed in one of the input sets; or b)
// the root of one of the individual trees.
node_set
graphconsensus::find_observed_subset(const count_to_node_map & name_nodes)
{
  node_set subset;
  count_to_node_map::const_iterator p, pend = name_nodes.end();

  for (p = name_nodes.begin();  p != pend;  ++p ) {
    nodeconsensus * node = p->second;
    if ( node->observed > 0 || node->is_a_root() ) {
      subset.insert(p->first);
    }
  }
  return subset;
}

vector<nodeconsensus*>
graphconsensus::find_named_nodes(const node_set &names,
                                 const count_to_node_map & name_to_nodes)
{
  vector<nodeconsensus*> consensus_nodes;
  node_set::const_iterator p, pend = names.end();
  for (p = names.begin();  p != pend;  ++p) {
    consensus_nodes.push_back(name_to_nodes.at(*p));
  }
  sort(consensus_nodes.begin(), consensus_nodes.end(),
       nodeconsensus_index_less());
  return consensus_nodes;
}

vector<graphconsensus:: consensus_pair>
graphconsensus::find_named_edges(const child_parent_map & named_edges,
                                 const count_to_node_map & name_to_nodes)
{
  vector<consensus_pair> consensus_edges;
  child_parent_map::const_iterator p, pend = named_edges.end();
  for (p = named_edges.begin();  p != pend;  ++p) {
    nodeconsensus * parent = 0;

    if (p->second != "nil") {
      parent = name_to_nodes.at(p->second);
    }
    consensus_edges.push_back(make_pair(name_to_nodes.at(p->first), parent));
  }
  sort(consensus_edges.begin(), consensus_edges.end(), edge_index_less());
  return consensus_edges;
}

void
graphconsensus::display_named_nodes(ostream & ss,
                                    const node_set & names,
                                    const count_to_node_map & name_to_node)
{
  vector<nodeconsensus*> nodes = this->find_named_nodes(names, name_to_node);
  streamsize prec = ss.precision();
  ios_base::fmtflags fl = ss.flags();
  ss << setprecision(5) << fixed;

  for (size_t k = 0;  k < nodes.size();   k++) {
    nodeconsensus * n = nodes[k];
    ss << *n << ":" << n->get_modeled() << ":" << n->get_label() << "\n";
  }
  ss.precision(prec);
  ss.flags(fl);
}


void
graphconsensus::display_tree_fragment(ostream & ss,
                                      const child_parent_map & fragment,
                                      double threshold,
                                      const count_to_node_map & name_to_node)
{
  streamsize prec = ss.precision();
  ios_base::fmtflags fl = ss.flags();
  ss << setprecision(5) << fixed;

  vector<consensus_pair> edges =
    this->find_named_edges(fragment, name_to_node);

  vector<consensus_pair>::iterator p, pend = edges.end();
  for (p = edges.begin();  p != pend;  ++p) {
    nodeconsensus * child = p->first;
    ss << *child << ":" << child->get_modeled() << ":"
       << child->get_label();

    if (p->second) {
      edgeconsensus * edge =
        table_of_edges[p->second->get_index()][p->first->get_index()];
      if (!edge) {
        ss << EDGE_BROKEN_HEAD << "*" << EDGE_BROKEN_TAIL;
      } else if ((threshold - edge->get_ratio()) < DBL_EPSILON) {
        ss << EDGE_SOLID_HEAD << edge->get_type() << EDGE_SOLID_TAIL;
      } else {
        ss << EDGE_BROKEN_HEAD << edge->get_type() << EDGE_BROKEN_TAIL;
      }
      ss << *p->second << "\n";
    } else {
      ss << endl;
    }
  }
  ss.precision(prec);
  ss.flags(fl);

}

// Output number of nodes and the corresponding probabilities given a
// threshold for the frequency (as probability) with which a consensus
// node that occurs among all joint trees.
void graphconsensus::output_at_least_threshold_nodes(string prefix,
  double threshold)
{
  enum { kblacklist_targets = 1 };

  count_to_node_map name_nodes = this->map_counts_to_nodes();
  vec_child_parent_map trees = this->find_constituent_trees(name_nodes);

  int node_min_trees = round(threshold * this->number_of_files());

  node_set shared_nodes = find_shared_nodes(trees, node_min_trees);

  this->display_named_nodes(cout, shared_nodes, name_nodes);

  cout << prefix << "\t" << as_node_stats(shared_nodes, name_nodes) << endl;
}

// Output number of nodes and the corresponding probabilities given a
// threshold for the frequency (as probability) with which a consensus 
// node that occurs among all joint trees and is reachable from the 
// root consensus node.
void graphconsensus::output_at_least_threshold_nodes_from_root(
  string prefix, double threshold)
{
  count_to_node_map name_nodes = this->map_counts_to_nodes();
  vec_child_parent_map orig_trees = this->find_constituent_trees(name_nodes);
  node_set observed_nodes = this->find_observed_subset(name_nodes);

  // Change this to allow threshold to be used
  int node_min_trees = round(threshold * this->number_of_files());
  const int edge_min_trees =  1; // Edges can be in *any* tree

  child_parent_map consensus_fragment =
    find_consensus_tree_fragment(orig_trees, observed_nodes, node_min_trees,
                                 edge_min_trees);

  this->display_tree_fragment(cout, consensus_fragment, threshold,
                              name_nodes);
  cout << prefix << "\t" << as_node_stats(consensus_fragment, name_nodes) << endl;
}

// Output number of nodes and the corresponding probabilities given a
// threshold for the frequency (as probability) with which a consensus 
// node and incoming consensus path (as edges) that occurs among all
// joint trees and isreachable from the root consensus node.
void graphconsensus::output_at_least_threshold_nodes_and_edges_from_root(
  string prefix, double threshold)
{
  count_to_node_map name_nodes = this->map_counts_to_nodes();
  vec_child_parent_map orig_trees = this->find_constituent_trees(name_nodes);
  node_set observed_nodes = this->find_observed_subset(name_nodes);

  const int node_min_trees = 1;
  int edge_min_trees = round(threshold * this->number_of_files());

  child_parent_map consensus_fragment =
    find_consensus_tree_fragment(orig_trees, observed_nodes, node_min_trees,
                                 edge_min_trees);

  this->display_tree_fragment(cout, consensus_fragment, threshold,
                              name_nodes);
  cout << prefix << "\t" << as_node_stats(consensus_fragment, name_nodes) << endl;
}

// Output number of nodes and the corresponding probabilities given a
// threshold for the frequency (as probability) with which a consensus
// node that occurs among all joint trees and is reachable from the
// root consensus node via direct and alternate paths.
// The reason to allow alternate paths is that the intermediate states 
// (as nodes) may not be observed in the input data file for some
// joint trees, although these intermediate states could have occurred.
void graphconsensus::output_at_least_threshold_nodes_and_paths_from_root(
    string prefix, double threshold)
{
  count_to_node_map name_nodes = this->map_counts_to_nodes();
  vec_child_parent_map orig_trees = this->find_constituent_trees(name_nodes);
  node_set observed_nodes = this->find_observed_subset(name_nodes);

  int node_min_trees = round(threshold * this->number_of_files());
  int edge_min_trees = round(threshold * this->number_of_files());

  child_parent_map consensus_fragment =
    find_consensus_tree_fragment(orig_trees, observed_nodes, node_min_trees,
                                 edge_min_trees);

  this->display_tree_fragment(cout, consensus_fragment, threshold,
                              name_nodes);
  cout << prefix << "\t" << as_node_stats(consensus_fragment, name_nodes) << endl;
}

// Output whole or partial consensus graph given a threshold as the
// ratio of a corresponding consensus node or edge occurs among all
// joint trees in Graphviz DOT format as defined in:
// http://www.graphviz.org/doc/info/lang.html
void graphconsensus::output_at_least_threshold_in_dot_format(string dir, 
  string prefix, double threshold)
{
  count_to_node_map name_nodes = this->map_counts_to_nodes();
  vec_child_parent_map orig_trees = this->find_constituent_trees(name_nodes);
  node_set observed_nodes = this->find_observed_subset(name_nodes);

  int node_min_trees = round(threshold * this->number_of_files());
  int edge_min_trees = round(threshold * this->number_of_files());

  // Declare output file stream by concatenating argument strings.
  stringstream filename_stream;

  size_t slash = dir.rfind('/');
  if (slash != string::npos) {
    dir = dir.substr(slash + 1);
  }

  filename_stream << dir << "." << prefix << 
    "." << threshold << ".dot";

  ofstream ss(filename_stream.str().c_str());
  if (!ss) {
    perror(0);
    exit(1);
  }
  // Write filename of the joint tree in the DOT format.
   cout << "Consensus graph (" << threshold << ") in DOT format = " <<
    filename_stream.str() << endl;

  vec_cp_edges core_edges =
    find_consensus_graph(orig_trees, observed_nodes, node_min_trees,
                         edge_min_trees);

  enum { not_core_only = false };
  print_core_dot(ss, core_edges, observed_nodes, orig_trees,
                 "Consensus Graph", not_core_only);
}
