#ifndef WEIGHTED_DISTANCE_H
#define WEIGHTED_DISTANCE_H

#include <vector>

#include "fish.h"
#include "constants.h"

class graph;


//maximum number of GD events used while calculating the weighted distance
#define MAX_GD 5

//maximum number of times the EM algorithm will iterate
#define MAX_ITERATIONS 30

//Threshold for convergence test
#define THR 0

graph *
generate_weighted_trees(int number_of_probes,
                        const vec_names & name_gene,
                        const int terminals[][MAX_PROBES],
                        std::vector<int> cell_count,
                        int total_record,
                        int tot_scg_sets,
                        int const * const * chr_profile);

#endif
