// Utility subroutines for the main program.

#include <fstream>
#include <sstream>

#include <cstdlib>
#include <cstring>
#include <cfloat>

#include "utility.h"


#ifndef VERBOSE
#define VERBOSE 0
#endif

using namespace std;

/**
 * Print basic help for the command line arguments of this program.
 *
 * Usually printed if an error in the commmand line arguments is
 * detected.
 */
static void usage(const string & exe_name)
{
  cerr << "\nusage: " << exe_name << " data_directory\n"
    << "           chr_probe1 gene_probe1 [chr_probe2 gene_probe2]...\n"
    << "           strategy\n\n";
  cerr <<
    "  Where strategy can take on the values -4, -3, -2, -1, 0, 1, 2, 3, 4.  The\n";
  cerr <<
    "  program can use a ploidy-based method, a ploidy-less method, or\n";
  cerr <<
    "  both to generate trees.  If the strategy is nonnegative a\n";
  cerr <<
    "  ploidy-based method will be employed.  If the strategy is nonzero a\n";
  cerr <<
    "  ploidy-less method will be employed, with the absolute value of the\n";
  cerr <<
    "  parameter indicating the ploidy-less strategy to use.\n" << endl;
}

/**
 * Process and echo command line arguments.  Print usage and exit on
 * error. See the usage() function for a description of the command-line
 * argument format.
 *
 *     fish data_directory \
 *         chr_probe1 gene_probe1 [chr_probe2 gene_probe2]...
 *         strategy
 *
 * Where strategy can take on the values -3, -2, -1, 0, 1, 2, 3.  The
 * program can use a ploidy-based method, a ploidy-less method, or
 * both to generate trees.  If the strategy is nonnegative a
 * ploidy-based method will be employed.  If the strategy is nonzero a
 * ploidy-less method will be employed, with the absolute value of the
 * parameter indicating the ploidy-less strategy to use.
 *
 * argc, argv -- unedited arguments as passed to main()
 * directory -- directory containing patient data files
 * name_chr -- empty on entry, on exit chromosome probes named in argv
 * name_gene -- empty on entry, on exit gene probes named in argv
 *      Genes probes and chromosome probes are paired, so name_chr
 *      and name_gene will have the same length.
 * model_ploidy -- nonzero (true) if a ploidy-based approach is to be
 *      run.
 * ploidy_less_approach -- nonzero if a ploidy-less approach is to be
 *      used; the value of 1, 2, or 3 determines which approach is used.
 */
void
process_command_line_arguments(int argc, char *argv[],
                               string & directory,
                               vec_names & name_chr, vec_names & name_gene,
                               int & model_ploidy,
                               int & ploidy_less_approach)
{
  // Number of given pairs of chromosome probes and gene probes.
  int number_of_pairs = (argc - 3) / 2;

  // Verify number of command line arguments.
  // Number of arguments should be odd because preceding the pairs are
  // 'fish' and the data directory and the rightmost argument
  // specifies the strategy to use.
  if ((argc < 5) || ((argc % 2) !=1))
  {
    // Number of command line arguments is invalid.
    usage(argv[0]);
    exit(EXIT_FAILURE);
  }

  name_chr.resize(number_of_pairs);
  name_gene.resize(number_of_pairs);

  directory = argv[1];
  // Write the queried directory.
  cout << "Input data directory =\t" << directory << endl;

  // Loop through every pair of chromosome probe and gene probe.
  for (int index_pair = 0; index_pair < number_of_pairs; index_pair++)
  {
    // Write symbol of a chromosome probe.
    name_chr[index_pair] = argv[index_pair * 2 + 2];
    cout << "Chromosome probe " << index_pair + 1 << " =\t" <<
      name_chr[index_pair] << endl;

    // Write symbol of a gene probe.
    name_gene[index_pair] = argv[index_pair * 2 + 3];
    cout << "Gene probe " << index_pair + 1 << " =\t" <<
      name_gene[index_pair] << endl;
  }

  // Write a new line.
  cout << endl;

  int last_arg = atoi(argv[argc-1]);
  if (last_arg == 0 && string("0") != argv[argc-1])
    last_arg = 0xBAD;   // Quick and dirty way to mark last_arg as bad.

  model_ploidy = last_arg >= 0;
  // Approach for generating ploidy less tree, either exact or
  // heuristic approach

  ploidy_less_approach = abs(last_arg);

  if((ploidy_less_approach != NO_PLOIDY_LESS) &&
     (ploidy_less_approach != PLOIDY_LESS_EXACT) &&
     (ploidy_less_approach != PLOIDY_LESS_HEURISTIC) &&
     (ploidy_less_approach != PLOIDY_LESS_HEURISTIC_GENOME_DUPLICATION) &&
     (ploidy_less_approach != PLOIDY_LESS_HEURISTIC_WEIGHTED)) {
    // Number of or content command line arguments is invalid.
    cerr
      << "ERROR: The final argument must be an integer between -4 and 4.\n"
      << "ERROR: Instead, we saw '" << argv[argc-1] << "'." << endl;
    usage(argv[0]);
    exit(EXIT_FAILURE);
  }
}


// Locate a low-frequency noisy state, whose frequency is less than e(%)
// of the total frequencies of all states or f(%) of the sum of
// frequencies of its neighbors. Second attempt at this method.
void filter_low_frequency_states2(obs_graph::freq_t & frequencies,
  int total_cells)
{
  // Declare a list of nodes for low-frequency states.
  list<node> noise_list;

  // Write filtering requirement.
  if (VERBOSE) {
    cout << "Low-frequency states dropped if they are below " <<
      BOUND_E * 100.0 << "% threshold of total counts or below " <<
      BOUND_F * 100.0 << "% threshold summing neighbor counts =" << endl;
  }

  // Loop through every possible copy number of chromosomes or ploidy.
  for (int index_chr = MIN_CHR_COPY; index_chr <= MAX_COPY; index_chr++)
  {
    // Loop through every possible copy number of gene probes.
    for (int index_gene = 0; index_gene <= MAX_COPY; index_gene++)
    {
      // Declare number of neighbors and sum of their frequencies.
      int number_of_neighbor = 0;
      double neighbor = 0.0;

      // Check if copy number of chromosomes or ploidy is larger than
      // the minimum copy number of chromosomes or ploidy.
      if (index_chr > MIN_CHR_COPY)
      {
        number_of_neighbor++;
        neighbor += frequencies[index_chr - 1][index_gene];
      }

      // Check if copy number of chromosomes or ploidy is smaller than
      // the maximum copy number of chromosomes or ploidy.
      if (index_chr < MAX_COPY)
      {
        number_of_neighbor++;
        neighbor += frequencies[index_chr + 1][index_gene];
      }

      // Check if copy number of gene probes is larger than the minimum
      // copy number of gene probes.
      if (index_gene > 0)
      {
        number_of_neighbor++;
        neighbor += frequencies[index_chr][index_gene - 1];
      }

      // Check if copy number of gene probes is smaller than the maximum
      // copy number of gene probes.
      if (index_gene < MAX_COPY)
      {
        number_of_neighbor++;
        neighbor += frequencies[index_chr][index_gene + 1];
      }

      // Check if frequency of this state is larger than 0.0.
      if (frequencies[index_chr][index_gene] > DBL_EPSILON)
      {
        // Check if frequency of this state is smaller than e(%).
        if (frequencies[index_chr][index_gene] <
          (total_cells * BOUND_E))
        {
          // Write and record a low-frequency state that is being dropped.
          cout << "dropped\t" << frequencies[index_chr][index_gene] <<
            " =\t" << frequencies[index_chr][index_gene] <<
            "\t < " << BOUND_E * 100.0 << "% * total " << total_cells
            << endl;
          noise_list.push_back(node(index_chr, index_gene));
        }
        // Check if frequency of this state is smaller than f(%).
        else if (frequencies[index_chr][index_gene] <
          (neighbor * BOUND_F))
        {
          // Write and record a low-frequency state that is being dropped.
          cout << "dropped\t" << frequencies[index_chr][index_gene] <<
            " =\t" << frequencies[index_chr][index_gene] <<
            "\t < " << BOUND_F * 100.0 << "% * neighbors " << neighbor
            << endl;
          noise_list.push_back(node(index_chr, index_gene));
        }
        else if (VERBOSE)
        {
          // Write a state that is kept.
          cout << "kept\t" << frequencies[index_chr][index_gene] <<
            " =\t" << frequencies[index_chr][index_gene] <<
            "\t >= " << BOUND_E * 100.0 << "% * total " << total_cells
            << " && " << BOUND_F * 100.0 << "% * neighbors " << neighbor
            << endl;
        }
      }
    }
  }

  // Loop through list of noisy states.
  list<node>::iterator state = noise_list.begin();
  while (state != noise_list.end())
  {
    frequencies[(*state).chr][(*state).gene] = 0.0;
    ++state;
  }
}
