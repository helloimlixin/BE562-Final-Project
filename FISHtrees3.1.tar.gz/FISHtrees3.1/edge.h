// A directed edge in a graph represents a valid mutation from a given
// node to a connected tumourigenesis node.
// In "2.3. Optimal tree inference", "E is the set of all possible
// single mutation events connecting pairs of states".

#ifndef EDGE_H
#define EDGE_H

#include "node.h"

// Declare directed edge to represent a mutation from one state node to 
// another state node.
class edge
{
  // Unary operator.
  friend std::ostream &operator<<(std::ostream &, const edge &);

public:
  // Tail node as parent as source of the directed edge.
  // Can be assigned by class constructor.
  node *tail;

  // Head node as child as target of the directed edge.
  // Can be assigned by class constructor.
  node *head;

  // Mutation type from source to target node.
  // Can be assigned by class constructor.
  int type;

  // In possible graph G', there is no table of edges.
  // In input graph G, edge weight equals parent node frequency times 
  // mutation edge probability.
  double weight;

  edge *old_edge; // Reference to the old edge.

  // Class constructor.
  edge();

  // Class copy constructor.
  edge(const edge&);

  // Class constructor with given parent/source and child/target nodes.
  edge(node *, node *, int);

  // Get tail/source node of this edge.
  node *get_tail();

  // Get head/target node of this edge.
  node *get_head();

  // Get type of this edge.
  int get_type();
};

#endif
