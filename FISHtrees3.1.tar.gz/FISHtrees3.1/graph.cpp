// A graph of nodes and edges represents a data structure for a pair of 
// ploidy or chromosome probe and gene probe for a patient.
// In "2.3. Optimal tree inference", "a directed graph G = (V,E), where 
// V is the set of observed states, and E is the set of all possible 
// single mutation events connecting pairs of states in V".
// In "2.3. Optimal tree inference", "Let G' = (V',E') be a directed 
// graph of all possible states and edges".
// In "2.3. Optimal tree inference", "find an optimal phylogenetic tree 
// for each patient using an algorithm for finding minimum weight 
// directed spanning trees (arborescences)".
// In "2.3. Optimal tree inference", "Convert the FISH matrix for an 
// individual patient into a graph G".
// In "2.5. Identifying a global consensus network", "find a best-fit 
// tree for each patient and a global consensus network for the entire 
// population".
// In "2.7. Merging trees across assays", "a merge graph G = (V,E) where 
// V = V_A x V_B and E = {((u_A,w_B),(v_A,w_B))|(u_A,v_A) \in E_A} \cup 
// {((w_A,u_B),(w_A,v_B))|(u_B,v_B) \in E_B}".

#include <cstdlib>
#include <cstdio>
#include <cassert>
#include <cfloat>
#include <cmath>
#include <cstring>

#include "graph.h"

#include "fish.h"
#include "output.h"
#include "calculate_pairwise_distance.h"

using namespace std;

// Class constructor.
graph::graph()
{
  // Initialize label to be an empty string.
  label.clear();

  // Initialize number of nodes to be 0.
  size = 0;

  // Initialize reference pointer to root node.
  root = NULL;

  // Initialize list of nodes to be an empty list.
  list_of_nodes.clear();

  // initialize reference pointer to table of edges to be NULL.
  table_of_edges = NULL;
}

// Class constructor with given label string.
graph::graph(string in_label) : label(in_label)
{

  // Initialize number of nodes to be 0.
  size = 0;

  // Initialize reference pointer to root node.
  root = NULL;

  // Initialize list of nodes to be an empty list.
  list_of_nodes.clear();

  // initialize reference pointer to table of edges to be NULL.
  table_of_edges = NULL;
}

// Class destructor.
graph::~graph()
{
  // Clear graph of nodes and edges.
  clear();
}


// Output a set of all nodes owned by this graph, including children
// of joint nodes.  The intent is to produce a set of nodes that may be
// deleted.  Since a node may be the child of more than one joint node,
// deleting nodes while avoiding double deletion is not as simple as walking
// the tree of nodes.
void graph::all_owned_nodes(set<node*> & nodes)
{
  list<node*>::iterator nn;
  for (nn = list_of_nodes.begin(); nn != list_of_nodes.end(); ++nn) {
    node * jn = *nn;
    while(jn) {
      nodes.insert(jn);
      nodes.insert(jn->single_node);

      jn = jn->joint_node;
    }
  }
}

// Delete nodes of the graph, including children of joint nodes.  For
// graphs that do not represent a joint tree, this is equivalent to
// deleting the nodes.  For graphs that do represent a joint tree,
// delete the joint nodes and the pair of nodes referred to by the
// fields node::joint_node and node::single_node, recursively.  In
// fact, only the field node::joint_node may contain a node that is
// itself a joint node, so the recursion is equivalent to a simple
// loop.
void graph::deep_delete_nodes()
{
  set<node*> owned_nodes;

  this->all_owned_nodes(owned_nodes);

  set<node*>::iterator pn;
  for (pn = owned_nodes.begin();  pn != owned_nodes.end();  ++pn)
    delete *pn;
}

// Delete direct nodes of the graph, but not children of joint nodes.
// This routine (followed by 'delete'ing the graph itself) allows
// us to destroy a joint graph without destroying its parents.
void graph::shallow_delete_nodes()
{
  list<node*>::iterator nn;
  for (nn = list_of_nodes.begin(); nn != list_of_nodes.end(); ++nn) {
    delete *nn;
  }
  list_of_nodes.clear();
}

// Clear graph of nodes and edges.
void graph::clear()
{
  // Check if this graph has been used before.
    
  if (size > 0)
  {
    // Clear table of edges.
    for (int index_outer = 0; index_outer < size; index_outer++)
    {
      for (int index_inner = 0; index_inner < size; index_inner++)
      {
        if (table_of_edges[index_outer][index_inner] != NULL)
        {
          delete table_of_edges[index_outer][index_inner];
        }
      }
      delete [] table_of_edges[index_outer];
    }
    delete [] table_of_edges;
    table_of_edges = NULL;

    // Reset root node to be NULL.
    root = NULL;
    
    // Clear list of nodes.
    list_of_nodes.clear();

    // Reset number of nodes to be 0.
    size = 0;
  }
}

// Get label of this graph.
string graph::get_label()
{
  // Return the label variable.
  return label;
}

// Get list of references to nodes in this graph.
list<node *> *graph::get_list_of_nodes()
{
  // Return list of references to nodes in this graph.
  return &list_of_nodes;
}

void graph::addnode(node *new_node)
{
    list_of_nodes.push_back(new_node);
size++;
}

// Initialize the distance function, tot_scg_sets is the number of sets of probes on the same chromosome
void graph::initialize_table_of_edges(int **nodes, int **edges, int total_nodes, node ***joint_nodes, int probes, int /* root_index */, int steiner_node_generation_method, int tot_scg_sets, int** scg, int *probes_on_chromosome)
{
    table_of_edges = NULL;
  table_of_edges = new edge **[size];
  
  if (table_of_edges == NULL)
  {
    cerr << "Error: Insufficient memory storage for table of edges ..."
      << endl;
    exit(EXIT_FAILURE);
  }
  for (int index_node = 0; index_node < total_nodes; index_node++)
  {
    // Allocate storage for the second dimension of table of edges.    
    table_of_edges[index_node] = new edge *[total_nodes];

    if (table_of_edges[index_node] == NULL)
    {
      cerr << "Error: Insufficient memory storage for table of edges ..."
        << endl;
      exit(EXIT_FAILURE);
    }
  }
  
  // Loop through every node as the source of an edge.
  for (int index_outer = 0; index_outer < total_nodes; index_outer++)
  {
    // Loop through every node as the target of an edge.
    for (int index_inner = 0; index_inner < total_nodes; index_inner++)
    {
      // Initialize edge reference to null.
      table_of_edges[index_outer][index_inner] = NULL;
    }
  }
  
  for (int i = 0; i < total_nodes-1; i++){
      //cout << edges[i][0] << edges[i][1] << endl;
      //cout << table_of_edges[edges[i][0]][edges[i][1]] << endl;  
      /*
      int root = -1;
      int other = -1;
      if(edges[i][0] == root_index){
          root = edges[i][0];
          other = edges[i][1];
      }
      else if(edges[i][1] == root_index){
          root = edges[i][1];
          other = edges[i][0];
      }
      if(root >= 0)
        table_of_edges[root][other] =
                new edge(&joint_nodes[root][probes-1], &joint_nodes[other][probes-1], 0);
      else*/
      int gene_count = edges[i][0] - edges[i][1];
      int type = 0;
//Adam//      if(gene_count < 0)
if(gene_count > 0)
//Adam//
          type = 2;
      else
          type = 3;
        // calculate edge weight
      double temp_weight = 0;

      for (int j = 0; j < probes; j++)
          temp_weight += abs(nodes[edges[i][0]][j] - nodes[edges[i][1]][j]);

	//calculate the pairwise distance using the new gene duplication based method if
	//option PLOIDY_LESS_HEURISTIC_GENOME_DUPLICATION (3) is selected in the command line
      if(steiner_node_generation_method == PLOIDY_LESS_HEURISTIC_GENOME_DUPLICATION) {
		if(temp_weight > 1){
			assert(probes > 0);
			vector<vector<int> > t_node(2, vector<int>(probes));

			for (int j = 0; j < probes; j++){
				t_node[0][j] = nodes[edges[i][0]][j];
				t_node[1][j] = nodes[edges[i][1]][j];
			}		    
		
			int smaller = 0; //which node has the smaller value at the first probe where they differ
			int other = 1;
			for (int k = 0; k < probes; k++){
				if(t_node[0][k] == t_node[1][k])
					continue;
				if(t_node[0][k] < t_node[1][k])
					break;
				if(t_node[0][k] > t_node[1][k]){
					smaller = 1;
					other = 0;						
					break;
				}
			}
			//get distance via the model that allows for duplication
			temp_weight = calculate_pairwise_distance(&t_node[smaller][0],&t_node[other][0],probes,
								  tot_scg_sets,scg, probes_on_chromosome);
		}
	}
        table_of_edges[edges[i][0]][edges[i][1]] =
                new edge(joint_nodes[edges[i][0]][probes-1], joint_nodes[edges[i][1]][probes-1], type);
        table_of_edges[edges[i][0]][edges[i][1]]->weight = temp_weight;
                //new edge(&joint_nodes[edges[i][0]][0], &joint_nodes[edges[i][1]][0], 0);
  }
}


//for the parameter learning method
void
graph::initialize_table_of_edges_par(int **nodes, int total_nodes,
                                     node ***joint_nodes, int probes,
                                     int /* root_index */,
                                     vector<vector<double> > edge_weight)
{
  table_of_edges = NULL;
  table_of_edges = new edge **[size];

  if (table_of_edges == NULL)
  {
    cerr << "Error: Insufficient memory storage for table of edges ..."
         << endl;
    exit(EXIT_FAILURE);
  }
  for (int index_node = 0; index_node < total_nodes; index_node++)
  {
    // Allocate storage for the second dimension of table of edges.
    table_of_edges[index_node] = new edge *[total_nodes];

    if (table_of_edges[index_node] == NULL)
    {
      cerr << "Error: Insufficient memory storage for table of edges ..."
           << endl;
      exit(EXIT_FAILURE);
    }
  }

  // Loop through every node as the source of an edge.
  for (int index_outer = 0; index_outer < total_nodes; index_outer++)
  {
    // Loop through every node as the target of an edge.
    for (int index_inner = 0; index_inner < total_nodes; index_inner++)
    {
      // Initialize edge reference to null.
      table_of_edges[index_outer][index_inner] = NULL;
    }
  }
  int diff = 0;
  int type = 2;
  for (int i = 0; i < total_nodes; i++){
    for(int j=0; j < total_nodes; j++){
      if(i==j)
        continue;
      if(edge_weight[i][j] == INF)
        continue;
      diff = 0;
      for(int p=0;p<probes; p++)
        diff = diff + (nodes[i][p] - nodes[j][p]);
      //Adam//      if(gene_count < 0)
      if(diff > 0)
        //Adam//
        type = 2;
      else
        type = 3;
      table_of_edges[i][j] =
        new edge(joint_nodes[i][probes-1], joint_nodes[j][probes-1], type);
      table_of_edges[i][j]->weight = -edge_weight[i][j];
    } // end for j
  } // end for i
}


// Construct graph of nodes and edges for non-zero frequency states.
void graph::set_nodes_and_edges(const string & ref_name_chr,
                                const string & ref_name_gene,
                                const obs_graph & gr,
  list<map<string,int> > *ref_list_counts)
{
  // Clear and reset graph.
  clear();

  // Declare mappings betwen state index and graph index.
  map<int,int> state2graph;
  map<int,node *> graph2node;

  // 
  double observed_sum = 0.0;

  // Initialize sum of all node frequencies in the joint tree to be 0.0.
  double frequency_sum = 0.0;

  // Loop through every possible copy number of chromosome probe.
  for (int index_chr = MIN_CHR_COPY; index_chr <= MAX_COPY; index_chr++)    
  {
    // Loop through every possible copy number of gene probe.
    for (int index_gene = 0; index_gene <= MAX_COPY; index_gene++)
    {
      // Check if state frequency is non-zero.
      if (gr.frequencies[index_chr][index_gene] > DBL_EPSILON)
      {
        // Create new node for non-zero frequency state.
        node *new_node = new node(ref_name_chr, ref_name_gene, index_chr,
          index_gene, size);

        // 
        new_node->set_observed(ref_list_counts);

        // 
        observed_sum += new_node->observed;

        // Copy frequency to new node.
        new_node->frequency = gr.frequencies[index_chr][index_gene];

        // Add frequency to total frequency.
        frequency_sum += new_node->frequency;

        // Add new node to list of node in this graph.
        list_of_nodes.push_back(new_node);

        // Create mappings between state index and graph index.
        state2graph[new_node->get_state_index()] = size;
        graph2node[size] = new_node;

        // Increase the size of graph based on list of nodes.
        size++;

        // Check and set root state.
        if ((index_chr == NORMAL_COPY) && (index_gene == NORMAL_COPY))
        {
          root = new_node;
        }
      }
    }
  }

  assert(root != NULL);

  // Iterate on list of nodes.
  list<node *>::iterator ref_node;

  // Loop through every node in this graph 
  for (ref_node = list_of_nodes.begin();
    ref_node != list_of_nodes.end(); ++ref_node)
  {
    (*ref_node)->observed /= observed_sum;

    (*ref_node)->frequency /= frequency_sum;
  }

  // Allocate storage for the first dimension of table of edges.
  table_of_edges = new edge **[size];
  if (table_of_edges == NULL)
  {
    cerr << "Error: Insufficient memory storage for table of edges ..."
      << endl;
    exit(EXIT_FAILURE);
  }

  // Loop through every node in the first dimension of table of edges.
  for (int index_node = 0; index_node < size; index_node++)
  {
    // Allocate storage for the second dimension of table of edges.
    table_of_edges[index_node] = new edge *[size];
    if (table_of_edges[index_node] == NULL)
    {
      cerr << "Error: Insufficient memory storage for table of edges ..."
        << endl;
      exit(EXIT_FAILURE);
    }
  }

  // Loop through every node as the source of an edge.
  for (int index_outer = 0; index_outer < size; index_outer++)
  {
    // Loop through every node as the target of an edge.
    for (int index_inner = 0; index_inner < size; index_inner++)
    {
      // Initialize edge reference to null.
      table_of_edges[index_outer][index_inner] = NULL;
    }
  }

  // Loop through every node as the source of an edge.
  for (int index_outer = 0; index_outer < size; index_outer++)
  {
    // Get source node of edge.
    node *source = graph2node[index_outer];

    // Iterate on list of possible child nodes.
    obs_graph::children_t::const_iterator child;

    // Loop through every possible child node from the source node.
    for (child = gr.children[source->chr][source->gene].begin();
         child != gr.children[source->chr][source->gene].end();
         ++child)
    {
      // Check if possible child state frequency is non-zero.
      if (gr.get_freq(child->second) > DBL_EPSILON)
      {
        // Get graph index of target node of the edge.
        int index_inner = state2graph[gr.get_state_index(child->second)];

        // Get target node of edge.
        node *target = graph2node[index_inner];

        // Create new edge from source node as tail to target node as 
        // head of the given mutation type.
        table_of_edges[index_outer][index_inner] =
          new edge(source, target, child->first);
      }
    }
  }
}

// Calculate mutation probabilities in given graph.
void graph::calculate_mutation_probabilities(double_vector mutation_prob)
{
  // Counts vector for counting each mutation type.
  vector<int> count(MUTATION_TYPES);
  // Total counts of counts vector.
  int total = 0;
  
  // Initialize counts to a vector of all ones; we use 1 as a pseudocount
  // to avoid zero probabilities.
  for (int index = 0; index < MUTATION_TYPES; index++)
  {
    count[index] = 1;
    total++;
  }

  // Loop through every node as the source of an edge.
  for (int index_outer = 0; index_outer < size; index_outer++)
  {
    // Loop through every node as the target of an edge.
    for (int index_inner = 0; index_inner < size; index_inner++)
    {
      // Check if edge exists.
      if (table_of_edges[index_outer][index_inner] != NULL)
      {
        // Increase count by one for corresponding mutation type.
        count[table_of_edges[index_outer][index_inner]->type]++;
        // Increase total count by one.
        total++;
      }
    }
  }

  // Check if total count equals 0.
  if (total == 0)
  {
    // Loop through every mutation type.
    for (int index = 0; index < MUTATION_TYPES; index++)
    {
      // Set mutation probability to 0.
      mutation_prob[index] = 0.0;
    }
  }
  // Check if total count is larger than 0.
  else
  {
    // Loop through every mutation type.
    for (int index = 0; index < MUTATION_TYPES; index++)
    {
      // Calculate mutation probability as count devided by total count.
      mutation_prob[index] = (double)count[index] / (double)total;
    }
  }
}

// Set edge weight to be node frequency times edge probability.
// In "2.3. Optimal tree inference", "Once we have ensured that every 
// node of G is reachable, we add a weight function w(v,u) = f_v p(v,u) 
// to G and find an optimal phylogenetic tree for each patient using an 
// algorithm for finding minimum weight directed spanning trees 
// (arborescences) due to Chu and Liu".
// In "2.4. Parameter inference", "For each possible parent v of u, 
// excluding current descendants, compute w(v,u) = f_v p(v,u), where f_v 
// is v's node frequency and p(v,u) is the prior probability of the edge 
// type from v to u".
void graph::set_edge_weight_frequency_times_probability(double_vector mutation_prob)
{
  // Loop through every node as the source of an edge.
  for (int index_outer = 0; index_outer < size; index_outer++)
  {
    // Loop through every node as the target of an edge.
    for (int index_inner = 0; index_inner < size; index_inner++)
    {
      // Check if edge exists.
      if (table_of_edges[index_outer][index_inner] != NULL)
      {
        // Calculate edge weight as minus the log of its probability.
        table_of_edges[index_outer][index_inner]->weight = 
          table_of_edges[index_outer][index_inner]->tail->frequency * 
          mutation_prob[table_of_edges[index_outer][index_inner]->type];
      }
    }
  }
}


void graph::set_edge_weight_probability(double_vector mutation_prob)
{
  // Loop through every node as the source of an edge.
  for (int index_outer = 0; index_outer < size; index_outer++)
  {
    // Loop through every node as the target of an edge.
    for (int index_inner = 0; index_inner < size; index_inner++)
    {
      // Check if edge exists.
      if (table_of_edges[index_outer][index_inner] != NULL)
      {
        // Set the edge weight equal to its probability
        table_of_edges[index_outer][index_inner]->weight =
          mutation_prob[table_of_edges[index_outer][index_inner]->type];
      }
    }
  }
}


void graph::take_log_of_weights_for_highweight_branching()
{
  // Loop through every node as the source of an edge.
  for (int index_outer = 0; index_outer < size; index_outer++)
  {
    // Loop through every node as the target of an edge.
    for (int index_inner = 0; index_inner < size; index_inner++)
    {
      // Check if edge exists.
      if (table_of_edges[index_outer][index_inner] != NULL)
      {
        // Calculate edge weight as the log of its probability,
        // without negating; this will result in negative numbers for
        // the weights.
        table_of_edges[index_outer][index_inner]->weight =
	  log(table_of_edges[index_outer][index_inner]->weight);
      }
    }
  }
}

// Set edge weight to be minus the log of its probability. 
// In "2.3. Optimal tree inference", "Solve the multiple source shortest 
// path problem from R to v* in G', where the weight of an edge e \in E' 
// is equal to -log p_e (minus the log of its probability)".
// In "2.3. Optimal tree inference", "Add all edges to G allowed by the 
// connectivity model of Sec. 2.2, each weighted as minus the log of its 
// probability".
void graph::set_edge_weight_minus_log_probability(double_vector mutation_prob)
{
  // Loop through every node as the source of an edge.
  for (int index_outer = 0; index_outer < size; index_outer++)
  {
    // Loop through every node as the target of an edge.
    for (int index_inner = 0; index_inner < size; index_inner++)
    {
      // Check if edge exists.
      if (table_of_edges[index_outer][index_inner] != NULL)
      {
        // Calculate edge weight as minus the log of its probability.
	if (mutation_prob[table_of_edges[index_outer][index_inner]->type] < DBL_EPSILON)
	  table_of_edges[index_outer][index_inner]->weight = 0.0;
	else {
	  table_of_edges[index_outer][index_inner]->weight = 
	    -1.0 * 
          log(mutation_prob[table_of_edges[index_outer][index_inner]->type]);
	}
      }
    }
  }
}


// Get dual nodes (nodes in G') that correspond to nodes a)
// reachable in the graph; b) present in the graph but unreachable
void graph::get_dual_nodes(obs_graph::node_set & reachable,
                           obs_graph::node_set & unreachable)
{
  assert(root);

  reachable.clear();
  unreachable.clear();

  // All nodes as nodes in the possible graph
  obs_graph::vec_node dual_nodes;
  list<node*>::iterator it;
  for (it = list_of_nodes.begin();  it != list_of_nodes.end(); ++it) {
    dual_nodes.push_back(obs_graph::node((*it)->chr, (*it)->gene));
  }

  vector<pair<int, int> > heads;

  // Depth-first search (DFS) using "heads" as an external stack
  // Push index of head node and the index of the next node that
  // is a potential child (at this point 0).
  heads.push_back(pair<int,int>(root->index, 0));

  while(!heads.empty()) {
    int head = heads.back().first;
    int i = heads.back().second;

    reachable.insert(dual_nodes[head]);

    for ( ; i < size;  i++) {
      if (table_of_edges[head][i] && !reachable.count(dual_nodes[i]))
        break;                // Next child, not already visited
    }
    if (i < size) {       // i is the next child to visit
      heads.back().second = i + 1;
      heads.push_back(pair<int,int>(i, 0));
    } else {              // no more children, done with DFS of head
      heads.pop_back();
    }
  }
  obs_graph::vec_node::iterator n;
  for (n = dual_nodes.begin();  n != dual_nodes.end();  ++n) {
    if (!reachable.count(*n)) {
      unreachable.insert(*n);
    }
  }
}


// Get number of nodes in this graph.
int graph::get_number_of_nodes()
{
  return list_of_nodes.size();
}


// Get parent node as the tail of an edge of a given node as the head
// of an edge, assuming this graph is a tree.
node *graph::get_parent_node(node *ref_node)
{
  // Initialize a reference to the parent node to be NULL.
  node *parent_node = NULL;

  // Loop through table of edges from the given node as tail node.
  for (int index_tail = 0; index_tail < size; index_tail++)
  {
    // Check if outgoing edge from the given node exists.
    if (table_of_edges[index_tail][ref_node->index] != NULL)
    {
      // Check if there are multiple parent nodes.
      if (parent_node != NULL)
      {
        cerr << "Error: Found miltiple parents to " << *ref_node <<
          endl;
        exit(EXIT_FAILURE);
      }

      // Retrieve parent node as the tail node of the edge.
      parent_node = table_of_edges[index_tail][ref_node->index]->tail;
    }
  }

  // Return the reference to the parent node.
  return parent_node;
}

// Get parent edge where a given node is the head of the edge,
// assuming this graph is a tree.
edge *graph::get_parent_edge(node *ref_node)
{
  // Initialize a reference to the parent node to be NULL.
  edge *parent_edge = NULL;

  // Loop through table of edges from the given node as tail node.
  for (int index_tail = 0; index_tail < size; index_tail++)
  {
    // Check if outgoing edge from the given node exists.
    if (table_of_edges[index_tail][ref_node->index] != NULL)
    {
      // Check if there are multiple parent nodes.
      if (parent_edge != NULL)
      {
        cerr << "Error: Found miltiple parents to " << *ref_node <<
          endl;
        exit(EXIT_FAILURE);
      }

      // Retrieve parent node as the tail node of the edge.
      parent_edge = table_of_edges[index_tail][ref_node->index];
    }
  }

  // Return the reference to the parent node.
  return parent_edge;
}

// Test whether a given node is a leaf node, assuming this graph is a tree.
bool graph::is_leaf(node *ref_node)
{
  // Loop through table of edges from the given node as tail node.
  for (int index_head = 0; index_head < size; index_head++)
  {
    // Check if outgoing edge from the given node exists.
    if (table_of_edges[ref_node->index][index_head] != NULL)
    {
      // Return the given node not being a leaf node.
      return false;
    }
  }

  // Return the given node being a leaf node.
  return true;
}


// Remove a node from this graph including renumbering remaining nodes to lower-by-1 indices.
int graph::delete_node(node *ref_given_node)
{
  // Declare return node index (as -1 if given node is not found).
  int index_return = -1;

  // Iterate on list of nodes.
  list<node *>::iterator ref_node;

  // Loop through every node in this graph
  for (ref_node = list_of_nodes.begin();
    ref_node != list_of_nodes.end(); ++ref_node)
  {
    // Check if the given node was found.
    if (index_return > -1)
    {
      // Decrease the node index by 1.
      --(*(*ref_node));
    }

    // Check if this is the given node.
    else if ((*ref_node) == ref_given_node)
    {
      // Set return node index to this node.
      index_return = (*ref_node)->get_index();

      // Loop through indices for tails of edges smaller than the given node.
      for (int index_tail = 0; index_tail < index_return; index_tail++)
      {
        // Check if there is a parent edge to the given node.
        if (table_of_edges[index_tail][index_return] != NULL)
        {
          // Release storage for this edge.
          delete table_of_edges[index_tail][index_return];

          // Remove reference to this edge.
          table_of_edges[index_tail][index_return] = NULL;
        }

        // Loop through indices for heads of edges larger than the given node.
        for (int index_head = index_return + 1; index_head < size; index_head++)
        {
          // Decrease index for head of edge by 1.
          table_of_edges[index_tail][index_head - 1] =
            table_of_edges[index_tail][index_head];
        }

        // Remove reference to the last edge.
        table_of_edges[index_tail][size - 1] = NULL;
      }

      // Loop through indices for tails of edges larger than the given node.
      for (int index_tail = index_return + 1; index_tail < size; index_tail++)
      {
        // Check if there is a parent edge to the given node.
        if (table_of_edges[index_tail][index_return] != NULL)
        {
          // Release storage for this edge.
          delete table_of_edges[index_tail][index_return];

          // Remove reference to this edge.
          table_of_edges[index_tail][index_return] = NULL;
        }

        // Loop through indices for heads of edges smaller than the given node.
        for (int index_head = 0; index_head < index_return; index_head++)
        {
          // Decrease index for tail of edge by 1.
          table_of_edges[index_tail - 1][index_head] =
            table_of_edges[index_tail][index_head];
        }

        // Loop through indices for heads of edges larger than the given node.
        for (int index_head = index_return + 1; index_head < size; index_head++)
        {
          // Decrease both indices for tail and head of edge by 1.
          table_of_edges[index_tail - 1][index_head - 1] =
            table_of_edges[index_tail][index_head];
        }

        // Remove reference to the last edge.
        table_of_edges[index_tail][size - 1] = NULL;
      }
    }
  }

  // Check if the given node was found.
  if (index_return > -1)
  {
    // Remove the given node from list_of_nodes.
    list_of_nodes.remove(ref_given_node);

    // Release storage for the given node.
    delete ref_given_node;

    // Decrease number of nodes by 1.
    size--;

    // Release storage for the last vector of edge references.
    delete [] table_of_edges[size];
  }

  // Return node or not-found index.
  return index_return;
}

// Trim leaf Steiner nodes recursively.
int graph::trim_leaf_steiner_nodes()
{
  // Nodes owned by the graph before trimming is done.
  set<node*> orig_nodes;

  this->all_owned_nodes(orig_nodes);   

  // Declare number of nodes trimmed.
  int number_of_nodes = 0;

  // Declare index for removed node if any.
  int delete_index = -1;

  // Loop until no more trimming is needed.
  do
  {
    // Initialize index for removed node to -1.
    delete_index = -1;

    // Iterate on list of nodes.
    list<node *>::reverse_iterator ref_node;

    // Loop through every node in this graph
    for (ref_node = list_of_nodes.rbegin();
      ref_node != list_of_nodes.rend(); ++ref_node)
    {
      // Check if this is a leaf Steiner node.
      if (((*ref_node)->observed < DBL_EPSILON) && is_leaf(*ref_node))
      {
        // Delete leaf Steiner node from this graph.
        // It, but not its children are freed.  Since children of joint
        // nodes are shared between joint nodes, one must first determine
        // no further references exist before deleting children.
        orig_nodes.erase(*ref_node); 
        delete_index = delete_node(*ref_node);

        // Increase number of nodes trimmed by 1.
        number_of_nodes++;

        // Terminate the loop.
        break;
      }
    }
  } while (delete_index > -1);

  set<node*> remaining_nodes;

  // Nodes still owned after trimming has been done.
  this->all_owned_nodes(remaining_nodes);

  // Delete nodes that had references before trimming was done, but
  // have no further references after trimming.
  set<node*>::iterator nn;
  for (nn = remaining_nodes.begin();  nn != remaining_nodes.end();  ++nn) {
    orig_nodes.erase(*nn);
  }
  for (nn = orig_nodes.begin();  nn != orig_nodes.end();  ++nn) {
    delete *nn;
  }


  // Return number_of_nodes trimmed.
  return number_of_nodes;
}

// Calculate accumulated observed probabilities of all descendants.
double graph::accumulate_observed_probabilities(node *ref_given_node)
{
  // Declare index for tail of edge as the given node.
  int index_tail = ref_given_node->get_index();

  // Loop through indices for heads of edges.
  for (int index_head = 0; index_head < size; index_head++)
  {
    // Check if there is any child edge from the given node.
    if (table_of_edges[index_tail][index_head] != NULL)
    {
      // Accumulate observed probability from child node to the given node.
      ref_given_node->accumulate_observed_probability(
        accumulate_observed_probabilities(
        table_of_edges[index_tail][index_head]->head));
    }
  }

  // Return accumulated observed probability.
  return ref_given_node->get_observed();
}

// Calculate accumulated modeled probabilities of all descendants.
double graph::accumulate_modeled_probabilities(node *ref_given_node)
{
  // Declare index for tail of edge as the given node.
  int index_tail = ref_given_node->get_index();

  // Loop through indices for heads of edges.
  for (int index_head = 0; index_head < size; index_head++)
  {
    // Check if there is any child edge from the given node.
    if (table_of_edges[index_tail][index_head] != NULL)
    {
      // Accumulate observed probability from child node to the given node.
      ref_given_node->accumulate_modeled_probability(
        accumulate_modeled_probabilities(
        table_of_edges[index_tail][index_head]->head));
    }
  }

  // Return accumulated observed probability.
  return ref_given_node->get_modeled();
}


// Test whether this graph is acyclic. It does so by repeatedly deleting 
// nodes which are sources or sinks. In an acyclic graph, this process 
// will end in an edge-free graph. Parameter top indicates whether this 
// is a call from outside (top = true) or a recursive call (top = false).

/*basic functions for manipulating graphs*/


/*makeEdge allocates memeory for an edge, and assigns initial
  values to its fields */

edge *makeEdge (/***char *label,***/ node *tail, node *head, edge *oldEdge,
		double /* prob */, double wt, double /* distance */, int occ)
{
  edge *newEdge;  /*points to new edge*/
  newEdge = new edge;

  newEdge->tail = tail;
  newEdge->head = head;
  newEdge->old_edge = oldEdge;
  newEdge->weight = wt;
  newEdge->type = occ;

  return(newEdge);
}


/*This function assigns indices to nodes of G*/
void assignIndices(graph *this_graph)
{
  // Node index in this graph.
  int index_graph = 0;

  // Iterate on list of nodes.
  list<node *>::iterator this_node;

  // Loop through every node as parent node.
  for (this_node = this_graph->list_of_nodes.begin();
    this_node != this_graph->list_of_nodes.end(); ++this_node)
  {
    (*this_node)->index = index_graph++;
  }
}

/*copyEdge calls makeEdge to make a copy of a given edge */
edge *copyEdge (edge *e)
{
return(makeEdge(e->tail,e->head,e->old_edge,0.0,e->weight,0.0,e->type));
}

/* procedure for deleting edge from a graph, also breaks parent links*/
void deleteEdge(edge *e, graph *G)
{
  if (NULL != e)
    {
      G->table_of_edges[e->tail->index][e->head->index] = NULL;
      if (e->head->parent == e->tail)
	e->head->parent = NULL;

      delete e;
    }
}

/*source returns TRUE if vertex v has indegree 0 in graph G*/
bool source (graph *G, node *v)
{
  int i; /*loop index over node indices in G*/
  for(i = 0; i < G->size; i++)
    if (NULL != G->table_of_edges[i][v->index])
      return(false);
  return(true);
}

/*sink returns TRUE if vertex v has outdegree 0 in graph G*/
bool sink (graph *G, node *v)
{
  int i; /*loop index over node indices in G*/

  for(i = 0; i < G->size; i++)
    if (NULL != G->table_of_edges[v->index][i])
      return(false);
  return(true);
}

/*initialize edges table of G.  Requires G->size to be already fixed.*/
void initEdges(graph *G)

{
  int i,j; /*loop indices over nodes*/

  G->table_of_edges = new edge **[G->size];
  for(j=0;j < G->size;j++)
    G->table_of_edges[j] = new edge *[G->size];

  for(i=0;i < G->size;i++)
    for(j=0;j < G->size;j++)
      G->table_of_edges[i][j] = NULL;
}

/*straightforward function for copying a graph, creating duplicates of
  all edges and nodes */

/*function counts the number of nodes on a graph*/
int countNodes(graph *this_graph)
{
  int counter = 0; /*will be returned as the number of nodes of G*/
  // Iterate on list of nodes.
  list<node *>::iterator this_node;

  // Loop through every node as parent node.
  for (this_node = this_graph->list_of_nodes.begin();
    (*this_node != NULL) && (this_node != this_graph->list_of_nodes.end());
    ++this_node)
  {
    counter++;
  }

  return(counter);
}


/*flowIn returns weight of (v1,v2) if v1 is a parent of v2
  in graph G, NEGINFINITY,   otherwise */

double flowIn (node *v1, node *v2, graph *G)
{
  edge *e; /*placeholder for a possible edge*/

  e = G->table_of_edges[v1->index][v2->index];
  if (NULL != e)
      return(e->weight);
  else
    return(NEGINFINITY);
}

/*finds heaviest edge in G with head at v.  Considers only
  positive weight edges.  If no edge is found, points to NULL*/
/// argument: top
edge *findHeavyEdge(node *v, graph *G)
{
  int i;  /*loop index over nodes of G*/
  edge *e;  /*loop variable*/
  edge *best; /*points to best edge found*/
  double highWeight = NEGINFINITY;  /*highest weight seen so far*/

/*in selecting the greedy graph, we wish to exclude negative weight edges*/
  best = NULL;
  for(i = 0; i < G->size;i++)
    {
      e = G->table_of_edges[i][v->index];
      if (NULL != e)
	if (e->weight > highWeight)  /*e is now the best edge*/
	  {
	    best = e;
	    highWeight = e->weight;
	  }
    }
  return(best);
}

/* assignParents sets the parent fields of the nodes of G to correspond
   to the edges of G.  If any node of G has more than one incoming edge,
   assignParents will flag an error. */
void assignParents(graph *this_graph)
{
  int i,j; /*loop indices for nodes in G*/
  edge *e; /*placeholder for an edge in G*/

  // Iterate on list of nodes.
  list<node *>::iterator this_node;

  // Loop through every node as parent node.
  for (this_node = this_graph->list_of_nodes.begin();
    this_node != this_graph->list_of_nodes.end(); ++this_node)
  {
    (*this_node)->parent = NULL;
  }

  for(i = 0; i < this_graph->size; i++)
    for(j = 0; j < this_graph->size; j++)
      {
        e = this_graph->table_of_edges[i][j];
        if (NULL != e)
          {
            if (NULL != e->head->parent)
              {
                fprintf(stderr,"Error with assignParents function.\n");
                exit(EXIT_FAILURE);
              }
            else
              e->head->parent = e->tail;
          }
      }
}

bool isAcyclic(graph *gr, bool /* ignore */ )
{
    enum { kNotVisited = 0,  kVisited, kVisitInProgress };

    vector<pair<int, int> > heads;
    vector<char> visited(gr->size, kNotVisited);

    list<node*>::iterator nn, end_nodes = gr->list_of_nodes.end();
    for (nn = gr->list_of_nodes.begin(); nn != end_nodes; ++nn) {
        if (visited[(*nn)->index] == kVisited)
            continue;

        // Depth-first search (DFS) using "heads" as an external stack
        // Push index of head node and the index of the next node that
        // is a potential child (at this point 0).
        heads.push_back(pair<int,int>((*nn)->index, 0));
        while(!heads.empty()) {
            int head = heads.back().first;
            int i = heads.back().second;

            visited[head] = kVisitInProgress;

            for ( ; i < gr->size;  i++) {
                if (!gr->table_of_edges[head][i])
                    continue;    // Not a child
                if (visited[i] == kNotVisited)
                    break;       // Next child to visit
                if (visited[i] == kVisitInProgress)
                    return false;  // We found a cycle
            }
            if (i < gr->size) {   // i is the next child to visit
                heads.back().second = i + 1;
                heads.push_back(pair<int,int>(i, 0));
            } else {    // no more children, done with DFS of head
                heads.pop_back();
                visited[head] = kVisited;
            }
        }
    }
    return true;
}
