// A single-probe node in a graph or tree represents a state pair of
// copy numbers of a given chromosome and a given single gene in an
// individual cell.
// In "2.1. Input data", "i copies of the chromosome and j copies of the 
// gene, which we call state (i,j)".
//
// A joint node in a tree or graph represents a state pair of two 
// state indices representing nodes from two trees or two graphs.
// In "2.7. Merging trees across assays", "Let A and B be two trees
// given as input to the merging algorithm. We number the nodes of each 
// tree in topological order and use the variable i to represent the ith 
// node of A and j to represent the jth node of B. ... state [i,j]".

#include <sstream>

#include "node.h"

#include "fish.h"

using namespace std;

// Class constructor.
// This constructor is used to create a nodes matrix as pseudo graph
// of all possible nodes and edges to read patient data.
node::node()
{
  // Initialize copy number of chromosome probe to be -1.
  chr = -1;

  // Initialize copy number of gene probe to be -1.
  gene = -1;

  // Initialize index to be -1.
  index = -1;

  // Clear label string.
  label.clear();

  // 
  observed = 0.0;

  // Initialize frequency to be 0.0;
  frequency = 0.0;

  // Initialize parent to be NULL.
  parent = NULL;
  // Initialize is-in-cycle to be false.
  is_in_cycle = false;
  // Initialize cycle weight to be 0.0.
  cycle_weight = 0.0;
  // Initialize next node to be NULL.
  next_node = NULL;
  // Initialize old node to be NULL.
  old_node = NULL;

  // Initialize joint node to be NULL.
  joint_node = NULL;

  // Initialize single node to be NULL.
  single_node = NULL;
}

// Class constructor with initial values of the pairs of a node to be 
// given copies of chromosome probe and gene probe.
// This constructor is used for joint graphs and concensus graph.
node::node(int in_chr, int in_gene)
{
  // Initialize copy number of chromosome probe to be in_chr.
  chr = in_chr;

  // Initialize copy number of gene probe to be in_gene.
  gene = in_gene;

  // Initialize index to be -1.
  index = -1;

  // Clear label string.
  label.clear();

  // 
  observed = 0.0;

  // Initialize frequency to be 0.0;
  frequency = 0.0;

  // Initialize parent to be NULL.
  parent = NULL;
  // Initialize is-in-cycle to be false.
  is_in_cycle = false;
  // Initialize cycle weight to be 0.0.
  cycle_weight = 0.0;
  // Initialize next node to be NULL.
  next_node = NULL;
  // Initialize old node to be NULL.
  old_node = NULL;

  // Initialize joint node to be NULL.
  joint_node = NULL;

  // Initialize single node to be NULL.
  single_node = NULL;
}

// Class constructor with given pairs of names and values, and index.
// This constructor is used in the graph per probe for each patient 
// for tree inference.
node::node(const string & ref_chr, const string & ref_gene,
           int in_chr, int in_gene, int in_index)
{
  // 
  chr_symbol = ref_chr;

  // 
  gene_symbol = ref_gene;

  // Initialize copy number of chromosome probe to be in_chr.
  chr = in_chr;

  // Initialize copy number of gene probe to be in_gene.
  gene = in_gene;

  // Initialize index to be the numeric linear-lexicographic state.
  index = in_index;

  // Declare string stream to store label.
  stringstream ss_label;

  if (GENE_PROBES_ONLY)
  {
    // Initialize label to be ref_chr=in_chr+ref_gene=in_gene).
    ss_label << ref_chr << "=" << in_chr << "+" << ref_gene << "=" <<
      in_gene;
  }
  // Check if matching numbers of chromosomes or ploidies is set.
  else if (MATCH_CHR == 1)
  {
    // Initialize label to be ref_gene(in_chr,in_gene).
    ss_label << ref_gene << "(" << in_chr << "," << in_gene << ")";
  }
  // Check if matching numbers of chromosomes or plodies is not set.
  else
  {
    // Initialize label to be (ref_chr,ref_gene)=(in_chr,in_gene).
    ss_label << "(" << ref_chr << "," << ref_gene << ")=(" << in_chr
      << "," << in_gene << ")";
  }

  // Write string stream into label.
  label = ss_label.str();

  // 
  observed = 0.0;

  // Initialize frequency to be 0.0;
  frequency = 0.0;

  // Initialize parent to be NULL.
  parent = NULL;
  // Initialize is-in-cycle to be false.
  is_in_cycle = false;
  // Initialize cycle weight to be 0.0.
  cycle_weight = 0.0;
  // Initialize next node to be NULL.
  next_node = NULL;
  // Initialize old node to be NULL.
  old_node = NULL;

  // Initialize joint node to be NULL.
  joint_node = NULL;

  // Initialize single node to be NULL.
  single_node = NULL;
}

// Output copy numbers of chromosome probe and gene probe in pair format.
ostream &operator<<(ostream &output, const node &node0)
{
  // Check if this node is representing a single probe state.
  if (node0.single_node == NULL)
  {
    output << "(" << node0.chr << "," << node0.gene << ")";
  }
  // Check if this node is representing a joint node in joint tree.
  else
  {
    output << "[" << node0.chr << "," << node0.gene << "]";
  }
  return output;
}

// Test if copies of chromosome probes in node1 is fewer than copies of 
// chromosome probes in node2.
bool operator<(const node &node1, const node &node2)
{
  return ((node1.chr < node2.chr) ||
    ((node1.chr == node2.chr) && (node1.gene < node2.gene)));
}

// Test if copies of chromosome probes in node1 is more than copies of 
// chromosome probes in node2.
bool operator>(const node &node1, const node &node2)
{
  return ((node1.chr > node2.chr) ||
    ((node1.chr == node2.chr) && (node1.gene > node2.gene)));
}

// Test if copies of chromosome probes in node1 is equal to copies of 
// chromosome probes in node2.
bool operator==(const node &node1, const node &node2)
{
  return ((node1.chr == node2.chr) && (node1.gene == node2.gene));
}

// Test if copies of chromosome probes in node1 is unequal to copies of 
// chromosome probes in node2.
bool operator!=(const node &node1, const node &node2)
{
  return ((node1.chr != node2.chr) || (node1.gene != node2.gene));
}

// Decrease node index by 1.
node &node::operator--()
{
  // Decrease index by 1.
  --index;

  // Return this node.
  return *this;
}

// Get number of chromosome probes or ploidy of this node.
string node::get_chr_symbol()
{
  return chr_symbol;
}

// 
string node::get_gene_symbol()
{
  return gene_symbol;
}

// Get number of chromosome probes or ploidy of this node.
int node::get_chr()
{
  return chr;
}

// Get number of gene probes of this node.
int node::get_gene()
{
  return gene;
}

// Get index of this node.
int node::get_index()
{
  // Return index of this node.
  return index;
}

// Get label of this node.
string node::get_label()
{
  // Return label of this node.
  return label;
}

// Get observed probability.
double node::get_observed()
{
  // Return observed probability.
  return observed;
}

// Get modeled probability.
double node::get_modeled()
{
  // Return observed probability.
  return frequency;
}

// Get joint node of this joint node.
node *node::get_joint_node()
{
  // Return joint node of this joint node in the joint tree.
  return joint_node;
}

// Get single node of this joint node.
node *node::get_single_node()
{
  // Return single probe node of this joint node in the joint tree.
  return single_node;
}

// Get linear-lexicographic state index of two-dimensional 
// (#chromomse/ploidy,#gene) node.
int node::get_state_index()
{
  // Return index in [0,(MAX_COPY + 1) x (MAX_COPY + 1)).
  return (((MAX_COPY + 1) * chr) + gene);
}

// Set values of the pairs of a node to be copies of chromosome probe 
// and gene probe.
void node::set_values(int in_chr, int in_gene)
{
  // Set copy number of chromosome probe to be in_chr.
  chr = in_chr;

  // Set copy number of gene probe to be in_gene.
  gene = in_gene;
}

// 
void node::set_observed(list<map<string,int> > *ref_list_counts)
{
  // 
  observed = 0.0;

  // 
  map<string,int> map_symbol_to_count;

  // 
  node *next_node = this;

  //
  const int ploidy_cnt =
    (this->single_node) ? this->get_single_node()->get_chr() : this->get_chr();

  while (next_node != NULL)
  {
    // 
    if (!next_node->get_chr_symbol().empty() &&
        !next_node->get_gene_symbol().empty())
    {
      map_symbol_to_count[next_node->get_chr_symbol()] =
        next_node->get_chr();
      map_symbol_to_count[next_node->get_gene_symbol()] =
        next_node->get_gene();

      // 
      next_node = NULL;
    }
    // 
    else
    {
      // 
      node *next_single_node = next_node->get_single_node();
      if (next_single_node != NULL)
      {
        // 
        if (!next_single_node->get_chr_symbol().empty() &&
            !next_single_node->get_gene_symbol().empty())
        {
      if (ploidy_cnt != next_single_node->get_chr()) {
        // This composite node has mismatched ploidy and so *cannot* be
        // observed.  Setting counts to -1 (an impossible value) forces
        // the node to be unmatched by anything in the data.
        map_symbol_to_count[next_single_node->get_chr_symbol()] = -1;
        map_symbol_to_count[next_single_node->get_gene_symbol()] = -1;
      } else {
        map_symbol_to_count[next_single_node->get_chr_symbol()] =
          next_single_node->get_chr();
        map_symbol_to_count[next_single_node->get_gene_symbol()] =
          next_single_node->get_gene();
      }
          // 
          next_node = next_node->get_joint_node();
        }
      }
      // 
      else
      {
        // 
        next_node = NULL;
      }
    }
  }

  // Iterate on list of counts mappings.
  list<map<string,int> >::iterator ref_map_counts;

  // Loop through every count mapping
  for (ref_map_counts = ref_list_counts->begin();
    ref_map_counts != ref_list_counts->end(); ++ref_map_counts)
  {
    // 
    bool matched = true;

    // 
    map<string,int>::iterator ref_symbol_to_count;

    // 
    for (ref_symbol_to_count = map_symbol_to_count.begin(); 
      ref_symbol_to_count != map_symbol_to_count.end(); 
      ++ref_symbol_to_count)
    {
      // 
      if ((ref_symbol_to_count->second == MAX_COPY) &&
        ((*ref_map_counts)[ref_symbol_to_count->first] >= MAX_COPY))
      {
        continue;
      }
      // 
      else if ((*ref_map_counts)[ref_symbol_to_count->first] != 
        ref_symbol_to_count->second)
      {
        matched = false;
      }
    }

    // 
    if (matched)
    {
      // 
      observed += (double)(*ref_map_counts)[STR_COUNT];
    }
  }
}

// Accumulate given observed probability to the current observed probability.
double node::accumulate_observed_probability(double given_observed)
{
  // Add given observed probability to this node's observed probabiltiy.
  observed += given_observed;

  return observed;
}

// Accumulate given modeled probability to the current modeled probability.
double node::accumulate_modeled_probability(double given_modeled)
{
  // Add given modeled probability to this node's modeled probabiltiy.
  frequency += given_modeled;

  return frequency;
}
