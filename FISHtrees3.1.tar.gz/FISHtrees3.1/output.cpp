#include <cstdio>
#include <cassert>

// Output structured data to the standard output or a given file.
#include "constants.h"
#include "output.h"
#include "generate_steiner_trees.h"

#ifndef VERBOSE
#define VERBOSE 0
#endif

using namespace std;

// Output all allowed nodes in the program as a two-dimensional matrix.
void output_possible_graph(const obs_graph & /* gr */)
{
  // Loop through every copy number of chromosome probes.
  for (int index_chr = MIN_CHR_COPY; index_chr <= MAX_COPY; index_chr++)
  {
    // Loop through every copy number of gene probes.
    for (int index_gene = 0; index_gene <= MAX_COPY; index_gene++)
    {
      // Write an allowed node.
      cout << obs_graph::node(index_chr, index_gene) << "\t";
    }

    // Write a new line for current copy number of chromosome probes.
    cout << endl;
  }
}

// Output possible graph in Graphviz DOT format as defined in:
// http://www.graphviz.org/doc/info/lang.html
void output_possible_graph_in_dot_format(const char *dot_file,
  const obs_graph & gr)
{
  // Declare and open file for writing.
  FILE *out_file = fopen(dot_file, "w");

  // Write header as the first line.
  fprintf(out_file, "digraph states {\n");

  // Write to change node shape to plain text only.
  fprintf(out_file, "\tnode [shape=plaintext];\n");

  // Write an open bracket for the ruler.
  fprintf(out_file, "\t{");

  // Loop through every copy number of chromosome probes.
  for (int index_chr = MIN_CHR_COPY; index_chr < MAX_COPY; index_chr++)
  {
    // Write a ruler stop.
    fprintf(out_file, " \"#%d\" ->", index_chr);
  }

  // Write the close bracket for the ruler.
  fprintf(out_file, " \"#%d\" [color = white]; }\n", MAX_COPY);

  // Write the file name as the label.
  fprintf(out_file, "\tlabelloc=\"t\";label=\"%s\";\n", dot_file);

  // Write to change node shape to a record shape.
  fprintf(out_file, "\tnode [shape=record];\n");

  // Loop through every copy number of chromosome probes.
  for (int index_chr = MIN_CHR_COPY; index_chr <= MAX_COPY; index_chr++)
  {
    // Write a layout constraint to the given file.
    fprintf(out_file, "\t{ rank=same; \"#%d\";", index_chr);

    // Loop through every copy number of gene probes.
    for (int index_gene = 0; index_gene <= MAX_COPY; index_gene++)
    {
      // Retrieve a reference to the node in possible graph by its
      // two-dimensional indices.
      obs_graph::node ref_node(index_chr, index_gene);

      // Write a node by its index and label to the given file.
      fprintf(out_file, " %02d [label=\"%d|%d\"];",
        gr.get_state_index(ref_node), ref_node.chr, ref_node.gene);
    }

    // Write to close a layout constraint to the given file.
    fprintf(out_file, " }\n");
  }

  // Loop through every copy number of chromosome probes.
  for (int index_chr = MIN_CHR_COPY; index_chr <= MAX_COPY; index_chr++)
  {
    // Loop through every copy number of gene probes.
    for (int index_gene = 0; index_gene <= MAX_COPY; index_gene++)
    {
      // Retrieve a reference to the node in possible graph by its
      // two-dimensional indices.
      obs_graph::node ref_node(index_chr, index_gene);

      // Iterate on list of mappings between allowed mutation types and
      // child nodes.
      const obs_graph::children_t & children = gr.get_children(ref_node);
      obs_graph::children_t::const_iterator child;

      // Loop through every mapping between allowed mutation type and
      // child node.
      for (child = children.begin();
        child != children.end(); ++child)
      {
        // Write an edge as a pair of two indices, its tail node index
        // and its head node index, with a color corresponding to the
        // edge mutation type to the given file.
        switch (child->first)
        {
        case INVALID:
          assert(child->first != INVALID);  // i.e. assert(false)
          break;
        case CHR_GENE_LOSS:
          fprintf(out_file, "\t%02d -> %02d [color=yellow];\n",
            gr.get_state_index(ref_node),
            gr.get_state_index(child->second));
          break;
        case CHR_LOSS:
          fprintf(out_file, "\t%02d -> %02d [color=orange];\n",
            gr.get_state_index(ref_node),
            gr.get_state_index(child->second));
          break;
        case GENE_LOSS:
          fprintf(out_file, "\t%02d -> %02d [color=red];\n",
            gr.get_state_index(ref_node),
            gr.get_state_index(child->second));
          break;
        case GENE_GAIN:
          fprintf(out_file, "\t%02d -> %02d [color=green];\n",
            gr.get_state_index(ref_node),
            gr.get_state_index(child->second));
          break;
        case CHR_GAIN:
          fprintf(out_file, "\t%02d -> %02d [color=blue];\n",
            gr.get_state_index(ref_node),
            gr.get_state_index(child->second));
          break;
        case CHR_GENE_GAIN:
          fprintf(out_file, "\t%02d -> %02d [color=purple];\n",
            gr.get_state_index(ref_node),
            gr.get_state_index(child->second));
          break;
        case CHR_GENE_DUPL:
          fprintf(out_file, "\t%02d -> %02d [color=gray];\n",
            gr.get_state_index(ref_node),
            gr.get_state_index(child->second));
          break;
        }
      }
    }
  }

  // Write tail as the last line.
  fprintf(out_file, "}\n");

  // Close the given file.
  fclose(out_file);
}

// Output patient data file.
void output_patient_file(FILE *out_file,
  int num_chr, list<string> sym_chr, int num_gene, list<string> sym_gene,
  int num_type, int num_cell, list<map<string,int> > *ref_list_counts)
{
  // Write number of chromosomes or ploidies.
  fprintf(out_file, "%d", num_chr);

  // Loop through every symbol of chromosome or ploidy.
  for (list<string>::iterator ref_chr = sym_chr.begin();
       ref_chr != sym_chr.end();
       ++ref_chr)
  {
    // Write symbol of chromosome or ploidy.
    fprintf(out_file, "\t%s", (*ref_chr).c_str());
  }

  // Write number of gene probes.
  fprintf(out_file, "\t%d", num_gene);

  // Loop through every symbol of gene.
  for (list<string>::iterator ref_gene = sym_gene.begin();
       ref_gene != sym_gene.end();
       ++ref_gene)
  {
    // Write symbol of gene probe.
    fprintf(out_file, "\t%s", (*ref_gene).c_str());
  }

  // Write a new line.
  fprintf(out_file, "\n");

  // Write number of cell types, number of cells, and a new line.
  fprintf(out_file, "%d\t%d\n", num_type, num_cell);

  // Iterate on list of counts mappings.
  list<map<string,int> >::iterator ref_map_counts;

  // Loop through every count mapping
  for (ref_map_counts = ref_list_counts->begin();
    ref_map_counts != ref_list_counts->end(); ++ref_map_counts)
  {
    // Iterate on list of symbols of chromosomes or ploidies.
    list<string>::iterator ref_chr;

    // Loop through every symbol of chromosome or ploidy.
    for (ref_chr = sym_chr.begin(); ref_chr != sym_chr.end(); ++ref_chr)
    {
      // Retrieve and write count of chromosome or ploidy.
      fprintf(out_file, "%d\t", (*ref_map_counts)[*ref_chr]);
    }

    // Iterate on list of symbols of genes.
    list<string>::iterator ref_gene;

    // Loop through every symbol of gene.
    for (ref_gene = sym_gene.begin(); ref_gene != sym_gene.end(); ++ref_gene)
    {
      // Retrieve and write count of gene.
      fprintf(out_file, "%d\t", (*ref_map_counts)[*ref_gene]);
    }

    // Retrieve and write cell count.
    fprintf(out_file, "%d\n", (*ref_map_counts)[STR_COUNT]);
  }

  // Write a new line.
  fprintf(out_file, "\n");
}

// Output node frequencies as a two-dimensional matrix.
void output_node_frequencies(obs_graph::freq_t & freq)
{
  // Loop through every number of chromosome probes.
  for (int index_chr = MIN_CHR_COPY; index_chr <= MAX_COPY; index_chr++)
  {
    // Write number of chromosome probes.
    cout << "(" << index_chr << ",0-" << MAX_COPY << ")";

    // Loop through every number of gene probes.
    for (int index_gene = 0; index_gene <= MAX_COPY; index_gene++)
    {
      // Write node frequency.
      cout << "\t" << freq[index_chr][index_gene];
    }

    // Write a new line for current number of chromosome probes.
    cout << endl;
  }
}

// Output graph in a list of parent nodes as tail nodes of edges where
// each node connects to a list of child nodes as head nodes of edges.
void output_graph(graph *ref_graph)
{
  // Iterate on list of parent nodes.
  list<node *>::iterator ref_node;

  // Loop through every parent node as the tail node of an edge.
  for (ref_node = ref_graph->list_of_nodes.begin();
    ref_node != ref_graph->list_of_nodes.end(); ++ref_node)
  {
    // Write parent node.
    cout << (*ref_node)->index << *(*ref_node);

    // Loop through every graph index as possible child node.
    for (int index_graph = 0; index_graph < ref_graph->size; index_graph++)
    {
      // Check if the edge from parent node to child node exists.
      if (ref_graph->table_of_edges[(*ref_node)->index][index_graph]
        != NULL)
      {
        // Write child node as the head node of an edge.
        cout << "|" <<
          ref_graph->table_of_edges[(*ref_node)->index][index_graph]->type
          << ":" <<
          *(ref_graph->table_of_edges[(*ref_node)->index][index_graph]->head);
      }
    }

    // Write a new line for current number of chromosome probes.
    cout << endl;
  }
}

// Output graph with node frequencies and edge weights in a list of
// parent nodes as tail nodes of edges where each node connects to a
// list of child nodes as head nodes of edges.
void output_graph_with_node_frequency_and_edge_weight(graph *ref_graph)
{
  // Iterate on list of parent nodes.
  list<node *>::iterator ref_node;

  // Loop through every parent node as the tail node of an edge.
  for (ref_node = ref_graph->list_of_nodes.begin();
    ref_node != ref_graph->list_of_nodes.end(); ++ref_node)
  {
    // Write parent node with node frequency.
    cout << (*ref_node)->index << *(*ref_node) << ":";
    fprintf(stdout, "%.5f", (*ref_node)->frequency);

    // Loop through every graph index as possible child node.
    for (int index_graph = 0; index_graph < ref_graph->size; index_graph++)
    {
      // Check if the edge from parent node to child node exists.
      if (ref_graph->table_of_edges[(*ref_node)->index][index_graph]
        != NULL)
      {
        // Write child node as the head node of an edge with edge weight
        // and node frequency.
        cout << "|" <<
          ref_graph->table_of_edges[(*ref_node)->index][index_graph]->type
          << ":";
        fprintf(stdout, "%.5f",
          ref_graph->table_of_edges[(*ref_node)->index][index_graph]->weight);
        cout << ":" <<
          ref_graph->table_of_edges[(*ref_node)->index][index_graph]->head->index
          <<
          *(ref_graph->table_of_edges[(*ref_node)->index][index_graph]->head);
      }
    }

    // Write a new line for current number of chromosome probes.
    cout << endl;
  }
}

// Output node frequencies in a graph as a two-dimensional matrix.
void output_graph_as_table_of_node_frequencies(graph *ref_graph)
{
  // Iterate on list of nodes.
  list<node *>::iterator ref_node = ref_graph->list_of_nodes.begin();

  // Loop through every number of chromosome probes.
  for (int index_chr = MIN_CHR_COPY; index_chr <= MAX_COPY; index_chr++)
  {
    // Write number of chromosome probes.
    cout << "(" << index_chr << ",0-" << MAX_COPY << ")";

    // Loop through every number of gene probes.
    for (int index_gene = 0; index_gene <= MAX_COPY; index_gene++)
    {
      // Check if numbers of chromosome and gene probes match current
      // node in the list of nodes.
      if (ref_node != ref_graph->list_of_nodes.end() &&
          ((*ref_node)->chr == index_chr) &&
        ((*ref_node)->gene == index_gene))
      {
        // Write non-zero node frequency.
        fprintf(stdout, "\t%.5f", (*ref_node)->frequency);
        ++ref_node;
      }
      else
      {
        // Write zero node frequency.
        cout << "\t0.0";
      }
    }

    // Write a new line for current number of chromosome probes.
    cout << endl;
  }
}

// Output table of edges in a graph as a two-dimensional matrix.
void output_graph_as_table_of_edges(graph *ref_graph)
{
  // Iterate on list of parent nodes.
  list<node *>::iterator ref_node;

  // Loop through every parent node as the tail node of an edge.
  for (ref_node = ref_graph->list_of_nodes.begin();
    ref_node != ref_graph->list_of_nodes.end(); ++ref_node)
  {
    // Write parent node.
    cout << *(*ref_node) << ":";

    // Loop through every graph index as possible child node.
    for (int index_graph = 0; index_graph < ref_graph->size; index_graph++)
    {
      // Check if the edge from parent node to child node exists.
      if (ref_graph->table_of_edges[(*ref_node)->index][index_graph]
        != NULL)
      {
        // Write child node as the head node of an edge.
        cout << "\t" <<
          *(ref_graph->table_of_edges[(*ref_node)->index][index_graph]->head);
      }
      else
      {
        // Write non-existing edge.
        cout << "\t-";
      }
    }

    // Write a new line for current number of chromosome probes.
    cout << endl;
  }
}

// Output list of nodes.
void output_list_of_nodes(list<node *> *ref_list_of_nodes)
{
  // Check if the given list is empty.
  if (ref_list_of_nodes->empty())
  {
    // Write an empty list.
    cout << "::" << endl;

    // Return the caller.
    return;
  }

  // Iterate on list of nodes.
  list<node *>::iterator ref_node;

  // Loop through every node.
  for (ref_node = ref_list_of_nodes->begin();
    ref_node != ref_list_of_nodes->end(); ++ref_node)
  {
    // Write node.
    cout << "::" << **ref_node;
  }
}

// Output list of edges.
void output_list_of_edges(list<edge *> *ref_list_of_edges)
{
  // Iterate on list of edges.
  list<edge *>::iterator ref_edge;

  // Loop through every edge.
  for (ref_edge = ref_list_of_edges->begin();
    ref_edge != ref_list_of_edges->end(); ++ref_edge)
  {
    // Write edge.
    cout << *(*ref_edge) << endl;
  }
}

// Output list of paths.
void output_list_of_paths(list<list<edge *> > *ref_list_of_paths)
{
  // Iterate on list of paths.
  list<list<edge *> >::iterator ref_path;

  // Loop through every path.
  for (ref_path = ref_list_of_paths->begin();
    ref_path != ref_list_of_paths->end(); ++ref_path)
  {
    // Iterate on list of edges as a path.
    list<edge *>::iterator ref_edge;

    // Loop through every edge in a path.
    for (ref_edge = (*ref_path).begin();
      ref_edge != (*ref_path).end(); ++ref_edge)
    {
      // Write edge.
      cout << *(*ref_edge);
    }

    // Write a new line for current path.
    cout << endl;
  }
}

// Output mutation probabilities vector as a one-dimensional array.
void output_mutation_probabilities(double_vector probabilities,
  const string & name_chr, const string & name_gene)
{
  // Write chromosome probe name and gene probe name.
  if (!GENE_PROBES_ONLY)
  {
    cout << name_chr << "+" << name_gene << ".loss\t";
  }
  cout << name_chr << ".loss\t"
       << name_gene << ".loss\t"
       << name_gene << ".gain\t"
       << name_chr << ".gain";
  if (!GENE_PROBES_ONLY)
  {
    cout << "\t" << name_chr << "+" << name_gene << ".gain";
  }
  if (CHR_GENE_DUPL < MUTATION_TYPES)
  {
    cout << "\t" << name_chr << "+" << name_gene << ".dupl";
  }
  cout << endl;

  // Loop through every mutation type.
  for (int index = 0; index < MUTATION_TYPES; index++)
  {
    // Write mutation probability of the given mutation type.
    fprintf(stdout, "%.5f", probabilities[index]);

    // Write a delimiter or a new line.
    if (index < (MUTATION_TYPES - 1))
    {
      cout << "\t";
    }
    else
    {
      cout << endl;
    }
  }
}

// Output tree with node frequencies and edge weights in a list of child
// nodes as head nodes of edges where each child node connects to its
// parent node as head node of the edge except the root node.
void output_tree_with_node_frequency_and_edge_weight(graph *rooted_tree)
{
  // Iterate on list of nodes.
  list<node *>::iterator ref_node;

  // Loop through every node.
  for (ref_node = rooted_tree->list_of_nodes.begin();
    ref_node != rooted_tree->list_of_nodes.end(); ++ref_node)
  {
    // Write child node as the head node of an edge with node frequency
    // and label.
    cout << (*ref_node)->index << *(*ref_node) << ":";
    fprintf(stdout, "%.5f", (*ref_node)->frequency);
    cout << ":" << (*ref_node)->label;

    // Get the parent node of this node.
    node *parent_node = rooted_tree->get_parent_node(*ref_node);

    // Check if parent node exists for the non-root node.
    if (parent_node != NULL)
    {
      // Write parent node as the tail node of an edge with edge weight
      // and node frequency.
      cout << "<-" <<
        rooted_tree->table_of_edges[parent_node->index][(*ref_node)->index]->type
        << ":";
      fprintf(stdout, "%.5f",
        rooted_tree->table_of_edges[parent_node->index][(*ref_node)->index]->weight);
      cout << "--" << parent_node->index << *parent_node;
    }

    // Write a new line.
    cout << endl;
  }
}

// Output tree in Newick tree format to a given output file.
void output_tree_in_newick_format(FILE *out_file, graph *rooted_tree)
{
  // Check if root node connects to any node in the tree.
  if (!rooted_tree->is_leaf(rooted_tree->root))
  {
    // Write an open parenthesis.
    fprintf(out_file, "(");

    // Loop through every root edge.
    bool need_comma = false;
    for (int index_head = 0; index_head < rooted_tree->size; index_head++)
    {
      // Retrieve outgoing edge directly from the root node.
      edge *root_edge =
        rooted_tree->table_of_edges[rooted_tree->root->index][index_head];

      // Check if an outgoing root edge exists.
      if (root_edge != NULL)
      {
        // Check if a comma sign is needed.
        if (need_comma)
        {
          fprintf(out_file, ",");
        }
        need_comma = true;

        // Output subtree from the root edge.
        output_subtree_in_newick_format(out_file, rooted_tree, root_edge);
      }
    }

    // Write a close parenthesis.
    fprintf(out_file, ")");
  }

  // Write the index of root node.
  fprintf(out_file, "%d;\n", rooted_tree->root->index);
}

// Output subtree in Newick tree format to a given output file.
void output_subtree_in_newick_format(FILE *out_file, graph *rooted_tree,
  edge *in_edge)
{
  // Check if head node of the given edge connects to any node in the tree.
  if (!rooted_tree->is_leaf(in_edge->head))
  {
    // Write an open parenthesis.
    fprintf(out_file, "(");

    // Loop through every outgoing edge.
    bool need_comma = false;
    for (int index_head = 0; index_head < rooted_tree->size; index_head++)
    {
      // Retrieve an outgoing edge.
      edge *out_edge =
        rooted_tree->table_of_edges[in_edge->head->index][index_head];

      // Check if an outgoing root edge exists.
      if (out_edge != NULL)
      {
        // Check if a comma sign is needed.
        if (need_comma)
        {
          // Write a comma sign.
          fprintf(out_file, ",");
        }
        need_comma = true;

        // Output subtree from the outgoing edge.
        output_subtree_in_newick_format(out_file, rooted_tree, out_edge);
      }
    }

    // Write a close parenthesis.
    fprintf(out_file, ")");
  }

  // Write the index of head node of the given edge.
  fprintf(out_file, "%d:%.5f", in_edge->head->index, in_edge->weight);
}

// Output tree in Graphviz DOT format as defined in:
// http://www.graphviz.org/doc/info/lang.html
void output_tree_in_dot_format(string prefix, graph *rooted_tree)
{
  string filename;
  // Concatenate prefix to the graph label as the filename.
  if (rooted_tree->get_label().empty()) {
    filename = prefix + "." + "ploidyless" + ".dot";
  }
  else {
    filename = prefix + "." + rooted_tree->get_label() + ".dot";
  }

  // Write filename of the joint tree in the DOT format.
  //cout << "Joint tree in DOT format = " << filename << endl;

  // Open file for writing.
  FILE *out_file = fopen(filename.c_str(), "w");

  // Write header line to the file.
  fprintf(out_file, "digraph tree {\n");
  if (VERBOSE) {
    fprintf(out_file, "\tlabelloc=\"t\";label=\"%s\";\n", filename.c_str());
  }
  fprintf(out_file, "\tnode [shape=record];\n");

  // Iterate on list of nodes in the rooted tree.
  list<node *>::iterator ref_node;

  // Loop through every node in the rooted tree.
  for (ref_node = rooted_tree->list_of_nodes.begin();
    ref_node != rooted_tree->list_of_nodes.end(); ++ref_node)
  {
    // Retrieve node index.
    int index_node = (*ref_node)->get_index();

    // Retrieve node label.
    string label_node = (*ref_node)->get_label();

    // Replace '+' sign with "\n" in the node label.
    size_t found;
    while ((found = label_node.find('+')) != string::npos)
    {
      label_node.replace(found, 1, "\\n");
    }

    // Write node index and label to the file.
if ((*ref_node)->observed > 0.0)
{
if ((rooted_tree->get_label()).empty())
{
    fprintf(out_file, "\t%d [label=\"{%s|%.5f}\"];\n", index_node,
      label_node.c_str(), (*ref_node)->observed);
}
else
{
    fprintf(out_file, "\t%d [label=\"{%s|%.5f|%.5f}\"];\n", index_node,
      label_node.c_str(), (*ref_node)->observed, (*ref_node)->frequency);
}
}
else
{
if ((rooted_tree->get_label()).empty())
{
    fprintf(out_file, "\t%d [label=\"{%s|%.5f}\",style=dotted];\n", index_node,
      label_node.c_str(), (*ref_node)->observed);
}
else
{
    fprintf(out_file, "\t%d [label=\"{%s|%.5f|%.5f}\",style=dotted];\n",
      index_node, label_node.c_str(), (*ref_node)->observed,
      (*ref_node)->frequency);
}
}
  }

  // Loop through every tail node index of an edge in the rooted tree.
  for (int index_tail = 0; index_tail < rooted_tree->size; index_tail++)
  {
    // Loop through every head node index of an edge in the rooted tree.
    for (int index_head = 0; index_head < rooted_tree->size; index_head++)
    {
      // Skip non-existing edge.
      if (rooted_tree->table_of_edges[index_tail][index_head] == NULL)
      {
        continue;
      }

      // Write an edge as a pair of two indices, its tail node index and
      // its head node index, with a color corresponding to the edge
      // mutation type to the file.
/*****
if (filename.find('+') == string::npos)
*****/
if (true)
      switch (rooted_tree->table_of_edges[index_tail][index_head]->type)
      {
      case CHR_GENE_LOSS:
        fprintf(out_file, "\t%d -> %d [color=yellow,label=\"%.5f\"];\n",
          index_tail, index_head,
          rooted_tree->table_of_edges[index_tail][index_head]->weight);
        break;
      case CHR_LOSS:
        fprintf(out_file, "\t%d -> %d [color=orange,label=\"%.5f\"];\n",
          index_tail, index_head,
          rooted_tree->table_of_edges[index_tail][index_head]->weight);
        break;
      case GENE_LOSS:
        fprintf(out_file, "\t%d -> %d [color=red,label=\"%.5f\"];\n",
          index_tail, index_head,
          rooted_tree->table_of_edges[index_tail][index_head]->weight);
        break;
      case GENE_GAIN:
        fprintf(out_file, "\t%d -> %d [color=green,label=\"%.5f\"];\n",
          index_tail, index_head,
          rooted_tree->table_of_edges[index_tail][index_head]->weight);
        break;
      case CHR_GAIN:
        fprintf(out_file, "\t%d -> %d [color=blue,label=\"%.5f\"];\n",
          index_tail, index_head,
          rooted_tree->table_of_edges[index_tail][index_head]->weight);
        break;
      case CHR_GENE_GAIN:
        fprintf(out_file, "\t%d -> %d [color=purple,label=\"%.5f\"];\n",
          index_tail, index_head,
          rooted_tree->table_of_edges[index_tail][index_head]->weight);
        break;
      case CHR_GENE_DUPL:
        fprintf(out_file, "\t%d -> %d [color=gray,label=\"%.5f\"];\n",
          index_tail, index_head,
          rooted_tree->table_of_edges[index_tail][index_head]->weight);
        break;
      case INVALID:
        fprintf(out_file, "\t%d -> %d [color=gray,label=\"%.5f\"];\n",
          index_tail, index_head,
          rooted_tree->table_of_edges[index_tail][index_head]->weight);
        break;
      }
else
      switch (rooted_tree->table_of_edges[index_tail][index_head]->type)
      {
      case CHR_GENE_LOSS:
        fprintf(out_file, "\t%d -> %d [color=yellow];\n",
          index_tail, index_head);
        break;
      case CHR_LOSS:
        fprintf(out_file, "\t%d -> %d [color=orange];\n",
          index_tail, index_head);
        break;
      case GENE_LOSS:
        fprintf(out_file, "\t%d -> %d [color=red];\n",
          index_tail, index_head);
        break;
      case GENE_GAIN:
        fprintf(out_file, "\t%d -> %d [color=green];\n",
          index_tail, index_head);
        break;
      case CHR_GAIN:
        fprintf(out_file, "\t%d -> %d [color=blue];\n",
          index_tail, index_head);
        break;
      case CHR_GENE_GAIN:
        fprintf(out_file, "\t%d -> %d [color=purple];\n",
          index_tail, index_head);
        break;
      case CHR_GENE_DUPL:
        fprintf(out_file, "\t%d -> %d [color=gray];\n",
          index_tail, index_head);
        break;
      }
    }
  }

  // Write last line.
  fprintf(out_file, "}\n");

  // Close file handle.
  fclose(out_file);
}

// Output the Rectilinear Steiner Minimum Tree instance in a
// format specified by Thorsten Koch
// prefix is the filename prefix
// num_probes is the number of gene probes used
// terminals holds the description of the observed cell count patterns
// total record is the total number of nodes
void output_steiner_instance(string prefix, int num_probes, int terminals[][MAX_PROBES], int total_record, vector<int> & cell_counter)
{
  int i,j; //loop indices
  int adjusted_total_record; // adjusted after duplicates are consolidated

  adjusted_total_record = prune_identical_cells(terminals, total_record, num_probes, cell_counter);



  // Concatenate prefix to the graph label as the filename.
  string filename = prefix + "."  + "steiner" + ".txt";

  // Write filename of the joint tree in the DOT format.
  cout << "Steiner tree instance = " << filename << endl;

  // Open file for writing.
  FILE *instance_file = fopen(filename.c_str(), "w");

  fprintf(instance_file, "33D32945 STP File, STP Format Version 1.0\n");
  fprintf(instance_file, "Section Graph\n");
  fprintf(instance_file, "Nodes %d\n", adjusted_total_record);
  fprintf(instance_file, "Obstacles 0\n");
  fprintf(instance_file, "END\n");
  fprintf(instance_file, "\n");
  fprintf(instance_file, "SECTION Coordinates\n");
  for(i =0; i < adjusted_total_record; i++) {
    for(j = 0; j < num_probes; j++) {
      fprintf(instance_file, "D");
    }
    fprintf(instance_file, " ");
    fprintf(instance_file, "%d ", i+1);
    for(j = 0; j < num_probes; j++) {
      fprintf(instance_file, "%d ",terminals[i][j]);
    }
    fprintf(instance_file, "\n");
  }
  fprintf(instance_file, "END\n\n");
  fprintf(instance_file, "EOF\n");

  // Close file handle.
  fclose(instance_file);
}
