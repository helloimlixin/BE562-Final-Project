// In "2.5. Identifying a global consensus network", "We then find a 
// global consensus network by identifying all pathways used in at least
// some fraction t of all patients. Given the per-patient trees T_1, 
/// ..., T_n, we can identify consensus pathways by searching
// depth-first through each tree individually and then, for each node,
// counting how many other trees have the same node and exhibit the same 
// pathway from that node to the root. Those pathways occurring in a t
// fraction of trees are added to the global consensus network. For the
// present study, t = 5%. Note that this consensus network need not
// itself be a tree, since a node may be reachable by more than one
// common pathway in different individual trees."

#ifndef CONSENSUS_H
#define CONSENSUS_H

#include "graphconsensus.h"

// Build a consensus network as graph on all joint trees.
void consensus_network(graphconsensus **, graph *[], int);

#endif
