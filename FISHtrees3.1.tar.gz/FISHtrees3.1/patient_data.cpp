#include <algorithm>
#include <fstream>
#include <sstream>

#include <cstring>
#include <cstdlib>
#include <cassert>

#include <dirent.h>

#include "patient_data.h"

#include "utility.h"

#ifndef VERBOSE
#define VERBOSE 0
#endif

using namespace std;

// Initialize the scg (same chromosome genes) matrix
static int ** init_scg()
{
  int ** scg = new int*[MAX_PROBES]();
  for (int i = 0; i < MAX_PROBES; i++) {
    scg[i] = new int[MAX_PROBES+1];
  }
  return scg;
}


// Free the scg (same chromosome genes) matrix
static void free_scg(int ** scg)
{
  if (!scg)
    return;
  for (int i = 0; i < MAX_PROBES; i++) {
    delete [] scg[i];
  }
  delete [] scg;
}


// Return the file part of a path
string patient_data::basename(const string & path)
{
  string::size_type i = path.rfind('/');
  string filename = (i == string::npos) ? path : path.substr(i + 1);
  int len = filename.size();

  if (len >= 5 && 0 == filename.compare(len - 4, 4, ".txt")) {
    filename.resize(len - 4);
  }
  return filename;
}


// Test whether the filename consists of at least one character,
// which cannot be '.', followed by the given suffix
static bool
has_extension(const string & filename, const string & suffix)
{
  size_t len_fn = filename.size(), len_sfx = suffix.size();

  if (len_fn <= len_sfx)
    return false;

  return 0 == filename.compare(len_fn - len_sfx, len_sfx, suffix) &&
        filename[0] != '.';
}


// Find patient files within a directory
vec_names
patient_data::find_patient_files(const string & dir_name)
{
  vec_names files;

  // Initialize reference to the directory of patient data files to be NULL.
  // Directory type as defined in dirent.h.
  DIR *dir = NULL;

  // Initialize reference to the file structure to be NULL.
  // Structure as defined in dirent.h.
  struct dirent *file = NULL;

  // Check if the queried directory exists.
  if ((dir = opendir(dir_name.c_str())) == NULL)
  {
    // The queried directory does not exist.
    cerr << "Error: Cannot open '" << dir_name << "'" << endl;
    exit(EXIT_FAILURE);
  }

  // Loop through every file in the queried directory.
  while ((file = readdir(dir)))
  {
    // Retrieve each file name.
    string filename = file->d_name;
    string suffix = string(".") + INPUT_TXT;

    // Verify file name to be <PATIENT-ID>.INPUT_TXT.
    if (has_extension(filename, suffix)) {
      // Increase number of patient data files by one.
      files.push_back(dir_name + "/" + filename);
    }
  }

  // Close patient data files directory.
  closedir(dir);

  sort(files.begin(), files.end());

  // Write number of patient data files in the queried directory.
  cout << "Number of patient files in the input data directory = " <<
    files.size() << endl;

  // Write a new line.
  cout << endl;

  // Return number of patient data files in the queried directory.
  return files;
}


// Free the individual parts of this object
//
// Called from within the destructor within
// a constructor that fails.
void patient_data::free_parts()
{
  delete [] cell_count;
  delete [] terminals;
  free_scg(scg);
}


//Identify which gene probes are together on the same chromosome and
//store the information in the two dimensional structure scg
// If scg[i][0] > 0, then that value indicates how many gene probes
// are together on one chromosome
// The number of i such that scg[i][0] > 0 is the number of
// distinct chromosomes with more than one gene probe and it is this
// integer value that is returned.
// The chromosomes are treated here as C strings.
// Also sets the values in the third argument probes_on_chromosome
// where probes_chromsome[i] is the number of probes on the same
// chromosome as chromosome i.

static int
identify_scg_sets(const vec_names & chromosomes,
                  int *scg[], int *probes_on_chromosome, int num_gene)
{

  bool used[MAX_PROBES];
  int i, j, k ; // loop indices
  bool found_duplicate; //does this chromosome appear two times or more
  int count_for_set ; //count of number of times this chromosome occurs
  int tot_scg_sets = 0; // count of sets with multiple probes on a
                        // chromosome to return

  for(i = 0; i < num_gene; i++) {
    used[i] = false;
    scg[i][0] = 0;
  }

  for(i = 0; i < num_gene; i++) {
    if (!used[i]) {
      count_for_set = 0;
      found_duplicate = false;
      for(j = i+1; j < num_gene; j++) {
        if (0 == strcmp(&(chromosomes[i][0]), & (chromosomes[j][0]))) {
          if (!found_duplicate) {
            scg[tot_scg_sets][1]  = i;
            scg[tot_scg_sets][2]  = j;
            found_duplicate = true;
            used[i] = true;
            used[j] = true;
            count_for_set = 2;
          }
          else {
            scg[tot_scg_sets][count_for_set+1]  = j;
            count_for_set++;
            used[j] = true;
          }
        }
      }
      if (found_duplicate) {
        scg[tot_scg_sets][0] = count_for_set;
        for(k = 1; k <= count_for_set; k++)
          probes_on_chromosome[scg[tot_scg_sets][k]] = count_for_set;
        tot_scg_sets++;
      }
      else
        probes_on_chromosome[i] = 1;
    }
  }
  return tot_scg_sets;
}


// Parse a patient data file to record pairs of chromosomes/ploidies and
// gene probes and their indices, number of cell types and cells, and
// input cell counts.
// Parameters:
//   char *dirname : directory where the queried patient data file locates
//   string filename : file name of the queried patient data file
//   int number_of_pairs : number of pairs of chromosomes/ploidies and
//                         gene probes
//   char *name_chr[] : reference to symbols of chromosomes or ploidies
//   char *name_gene[] : reference to symbols of gene probes
//   int_matrix *cell_count : two dimensional matrices to record input
//                            cell counts for queried pairs of
//                            chromosomes/ploidies and gene probes
//   list<map<string,int> > *ref_list_counts : reference to list of
//                                             mapping to numbers of cells
//		int storage[][MAX_PROBES] : stores the probe count
//		value of each record
//  	vector<int> &cell_counter : stores the cell count of
//  	individual record
//    int &total_record : stores the total number of records in the
//    patient file
// bool count_only if true return only the count of cells, otherwise
// parse the file entirely
// Return:
//   an integer of total cell counts
static int
parse_patient_file(const string & filepath,
                   int number_of_pairs,
                   const vec_names & name_chr, const vec_names & name_gene,
                   int_matrix *cell_count,
                   patient_data::list_counts_t *ref_list_counts,
                   int storage[][MAX_PROBES],
                   vec_names & probe_chromosomes,
                   vector<int> &cell_counter, int &total_record,
                   bool count_only)
{
  // Declare total cell counts on the last column of the input file.
  int total_cell = 0;

  // Declare input file stream.
  ifstream infile;

  // Open patient data file for read.
  infile.open(filepath.c_str());

  // Verify if patient data file is readable.
  if (!infile) {
    cerr << "Error: Cannot open '" << filepath << "'" << endl;
    exit(EXIT_FAILURE);
  }

  // Declare number of chromosomes or ploidies.
  int num_chr;

  // Read and write number of chromosomes or ploidies.
  infile >> num_chr;
  if (!count_only) {
    cout << "Data file =\t" << patient_data::basename(filepath) << endl;
    cout << "Chromosome probe(s) =";
  }

  // Declare column ids in the input data file for queried
  // chromosomes/polidies and gene probes.
  vector<node> id(number_of_pairs);

  // Declare list to store symbols of chromosomes or ploidies.
  list<string> sym_chr;

  // Loop through number of chromosomes or ploidies.
  for (int index = 0; index < num_chr; index++) {
    // Declare symbol of chromosome or ploidy.
    string name;

    // Read, write and store symbol of chromosome or ploidy.
    infile >> name;
    if (!count_only)
      cout << "\t" << name;
    sym_chr.push_back(name);

    // Record column id of the queried chromosome or ploidy.
    for (int index_pair = 0; index_pair < number_of_pairs; index_pair++) {
      if (name.compare(name_chr[index_pair]) == 0) {
        id[index_pair].chr = index + 1;
      }
    }
  }
  if (!count_only)
    cout << endl;

  // Declare number of gene probes.
  int num_gene;
  vector<int> ordinal(MAX_PROBES); //which gene is in which position

  for (int i= 0; i < MAX_PROBES; i++)
    ordinal[i] = -1;

  // Read and write number of gene probes.
  infile >> num_gene;
  if (!count_only) {
    cout << "Gene probe(s) =";
  }

  // Declare list to store symbols of genes.
  list<string> sym_gene;

  // Loop through number of genes.
  for (int index = 0; index < num_gene; index++) {
    // Declare symbol of gene.
    string name;

    // Read, write and store symbol of gene.
    infile >> name;
    if (!count_only)
      cout << " " << name;
    sym_gene.push_back(name);

    // Record column id of queried gene probe.
    for (int index_pair = 0; index_pair < number_of_pairs; index_pair++) {
      if (name.compare(name_gene[index_pair]) == 0) {
        id[index_pair].gene = index + num_chr + 1;
        ordinal[index_pair] = index;
      }
    }
  }

  // Loop through every pair of queried chromosome/ploidy and gene probe.
  for (int index_pair = 0; index_pair < number_of_pairs; index_pair++) {
    // Check if the queried chromosome or ploidy is valid.
    if (id[index_pair].chr <= 0) {
      cerr << "Error: Cannot find chromosome probe or ploidy '" <<
        name_chr[index_pair] << "'" << endl;
      exit(EXIT_FAILURE);
    }

    // Write column id for the queried chromosome or ploidy.
    if (0) {
      if (!count_only) {
        cout << "Chromosome probe " << index_pair + 1 << " and index =\t" <<
          name_chr[index_pair] << "\t" << id[index_pair].chr << endl;
      }
    }
    // Check if queried gene probe is valid.
    if (id[index_pair].gene <= 0) {
      cerr << "Error: Cannot find gene probe '" <<
        name_gene[index_pair] << "'" << endl;
      exit(EXIT_FAILURE);
    }

    // Write column id for the queried gene probe.
    if (0) {
    if (! count_only) {
      cout << "Gene probe " << index_pair + 1 << " and index =\t" <<
        name_gene[index_pair] << "\t" << id[index_pair].gene << endl;
    }
    }
  }
  if (!count_only)
    cout << endl;

  // Declare number of cell types.
  int num_type;

  // Declare number of cells.
  int num_cell;

  vector<char> buffer(BSIZE);

  infile.getline(&(buffer[0]), BSIZE);
  infile.getline(&(buffer[0]), BSIZE);
  //cout << "second line of file is" << &buffer[0] << endl;
  string str(&(buffer[0]));
  string oneToken;
  stringstream ss(str);
  vector<string> tokens; // Create vector to hold our words
  int numTokens = 0;
  while (ss >> oneToken) {
    tokens.push_back(oneToken);
    numTokens++;
  }

  int tokensExpected;
  bool chromosomes_shown; //Are the chromosomes of each probe shown
  tokensExpected = 2 + num_gene;
  if (2 == numTokens) {
    chromosomes_shown = false;
    //set probe_chromosomes to null strings, so they are not matched later
    for (int i = 0; i < number_of_pairs; i++)
      probe_chromosomes[i] = string();
  }
  else {
    if (tokensExpected == numTokens)
      chromosomes_shown = true;
    else {
      cerr << "Number of tokens of second line is " << numTokens
           << " but it should be either 2 or " << tokensExpected << endl;
      exit(EXIT_FAILURE);
    }
  }

  num_type = atoi((tokens[0]).c_str());

  num_cell = atoi((tokens[1]).c_str());

  if (count_only) {
    if (chromosomes_shown)
      for (int i = 0; i < number_of_pairs; i++)
        probe_chromosomes[i] = tokens[2+ordinal[i]];
  }
  if (!count_only) {
    // Read and write number of cell types (as number of input lines beyond).
    //  infile >> num_type;
    cout << "Number of cell types =\t" << num_type << endl;

    // Read and write number of cells (as sum of the last column beyond).
    //  infile >> num_cell;
    cout << "Number of cells =\t" << num_cell << endl;
  }
  if (count_only) {
    total_record = num_type;
    infile.close();
    return(num_cell);
  }

  // Loop through every pair of chromosome/ploidy and gene probe.
  for (int index_pair = 0; index_pair < number_of_pairs; index_pair++) {
    // Loop through every possible copy number of chromosome or ploidy.
    for (int index_chr = 0; index_chr <= MAX_COPY; index_chr++) {
      // Loop through every possible copy number of gene probe.
      for (int index_gene = 0; index_gene <= MAX_COPY; index_gene++) {
        // Initialize state count matrices to be 0.
        cell_count[index_pair][index_chr][index_gene] = 0;
      }
    }
  }

  // Declare copy numbers of chromosome/ploidy or gene probe in a line
  // in the input data file.
  vector<node> copy(number_of_pairs);

  // Declare list to store counts.
  list<int> list_of_counts;

  // Declare column id for number of cells per .
  int id_cell = 1 + num_chr + num_gene;

  // Declare column id as a token index to read the input data file.
  int column = 0;

  // Declare next token read from the input data file.
  int token;

  total_record = 0;

  // This is to avoid any file without records containing all 2
  for (int i = 0; i < number_of_pairs; i++) {
    storage[total_record][i] = 2;
  }
  cell_counter[total_record] = 0;

  total_record += 1;

  // Loop through every token in the input data files.
  while (infile >> token) {
    // Increase the column id by 1.
    column++;

    // Check if this is the last column.
    if (column == id_cell) {
      // Declare mapping from symbols to counts.
      map<string,int> map_of_counts;

      // Iterate on list of counts.
      list<int>::iterator ref_count = list_of_counts.begin();

      // Iterate on list of symbols of chromosomes or ploidies.
      list<string>::iterator ref_chr;

      // Loop through every symbol of chromosome or ploidy.
      for (ref_chr = sym_chr.begin(); ref_chr != sym_chr.end(); ++ref_chr) {
        // Map symbol of chromosome or ploidy to count.
        map_of_counts[*ref_chr] = *ref_count;

        // Move reference to the next count.
        ++ref_count;
      }

      // Iterate on list of symbols of genes.
      list<string>::iterator ref_gene;

      // Loop through every symbol of gene.
      for (ref_gene = sym_gene.begin(); ref_gene != sym_gene.end(); ++ref_gene) {
        // Map symbol of chromosome or ploidy to count.
        map_of_counts[*ref_gene] = *ref_count;

        // Move reference to the next count.
        ++ref_count;
      }

      // Map symbol of chromosome or ploidy to count.
      map_of_counts[STR_COUNT] = token;

      // Insert mapping to list of count mappings.
      ref_list_counts->push_back(map_of_counts);

      // Reset list of counts.
      list_of_counts.clear();

      // Loop through every pair of chromosome/ploidy and gene probe.
      for (int index_pair = 0; index_pair < number_of_pairs; index_pair++) {
        // Record number of cells of this type at the end of
        // each line.  here copy is reset to 0 because this is
        // for the rightmost column copy gets set to the
        // observed values in a loop that is later in the code
        // file but corresponds to columns further left
        cell_count[index_pair][copy[index_pair].chr][copy[index_pair].gene]
          += token;
        copy[index_pair].chr = 0;
        copy[index_pair].gene = 0;
      }

      // Add cell count in last column to total cell count.
      total_cell += token;

      // Store the total number of cells
      cell_counter[total_record] = token;

      // Increase the total number of records parsed so far
      total_record++;

      // Reset column id.
      column = 0;

      // Continue onto next line of input file.
      continue;
    }

    // Store count.
    list_of_counts.push_back(token);

    // Loop through every pair of chromosome/ploidy and gene probe
    // to assign input copy numbers.
    for (int index_pair = 0; index_pair < number_of_pairs; index_pair++) {
      // Check copy number of chromosome or ploidy by the column id.
      if (column == id[index_pair].chr) {
        // Check if copy number of chromosome or ploidy is smaller than
        // the minimum copy number of chromosome or ploidy.
        if (token < MIN_CHR_COPY) {
          cerr << "Error: Copy number of chromosome probe '"
               << name_chr[index_pair] << "' cannot be smaller than "
               << MIN_CHR_COPY << "." << endl;
          exit(EXIT_FAILURE);
        }

        // Record MAX_COPY if the copy number is larger than MAX_COPY.
        copy[index_pair].chr = (token > MAX_COPY ? MAX_COPY : token);
      }
      // Check copy number of gene probe by the column id.
      else if (column == id[index_pair].gene) {
        // Record MAX_COPY if the copy number is larger than MAX_COPY.
        copy[index_pair].gene = (token > MAX_COPY ? MAX_COPY : token);

        // Store the probe count value in the storage array
        storage[total_record][index_pair] =
          (token > MAX_COPY ? MAX_COPY : token);

      }
    }
  }

  // Close input file.
  infile.close();
  cout << endl;

  if (VERBOSE) {
    // Output patient data file.
    output_patient_file(stderr, num_chr, sym_chr, num_gene, sym_gene,
                        num_type, num_cell, ref_list_counts);
  }

  // Validate if cell counts in the last column add up to the total
  // number of cells in the header of the input data file.
  if (total_cell != num_cell) {
    cerr << "Error: Last column sums up to " << total_cell
         << " but not to " << num_cell << endl;
    exit(EXIT_FAILURE);
  }

  //total_record -= 1;
  // Return total cell counts.
  return total_cell;
}


// Default constructor.
patient_data::patient_data() :
  total_cells(0), number_of_pairs(0),
  cell_count(0), terminals(0), probe_chromosomes(MAX_PROBES),
  cell_counter(cell_counter_size), total_record(0),
  probes_on_same_chromosome(max_probes, 0),
  tot_scg_sets(0), scg(0)
{
  try {
    terminals = new int[max_terminals][max_probes];
    scg = init_scg();
  } catch (...) {
    free_parts();
    throw;
  }
}


patient_data::~patient_data() {
  free_parts();
}


void
patient_data::parse_file(vec_names & name_chr,
                         vec_names & name_gene,
                         const string & filepath)
{
  number_of_pairs = name_chr.size();

  cell_count = new int_matrix[number_of_pairs];

  // Parse patient data file to record pairs of chromosome and
  // gene probes and indices, number of cell types and cells, and
  // input cell counts.  first call just counts the cells, second
  // call parses the file in full

  total_cells =
    parse_patient_file(filepath,
                       number_of_pairs, name_chr, name_gene,
                       cell_count, &list_counts, terminals,
                       probe_chromosomes, cell_counter, total_record,
                       true);

  cell_counter.reserve(total_cells+1);
  if (!(probe_chromosomes[0]).empty())
    tot_scg_sets =
      identify_scg_sets(probe_chromosomes, scg,
                        &probes_on_same_chromosome[0], number_of_pairs);
  else {
    tot_scg_sets = 0;
    for(int i = 0; i < number_of_pairs; i++)
      probes_on_same_chromosome[i] = 1;
  }
  total_cells =
    parse_patient_file(filepath,
                       number_of_pairs, name_chr, name_gene,
                       cell_count, &list_counts, terminals,
                       probe_chromosomes, cell_counter, total_record,
                       false);
}
