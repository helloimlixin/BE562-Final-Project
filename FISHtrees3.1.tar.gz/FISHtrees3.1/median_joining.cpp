#include <iostream>
#include <algorithm>

#include <climits>
#include <cassert>

#include "generate_steiner_trees.h"
#include "median_joining.h"
#include "mst_prim.h"
#include "calculate_pairwise_distance.h"

using namespace std;

// Generates the steiner tree using the median joining (heuristic) approach
// tot_terminals is the total number of terminals
// probes is the total number of probes listed by the user
// terminals is the probe count of the records in the patient file
// mst_node_store stores the copy number counts of each node in the steiner tree
// mst_edge_store stores indices of the two nodes of each edge in the steiner tree
// epsilon is an algorithmic specific parameter representing the tolerance level in the 
// minimum spanning network building process
// distance_option denotes whether to use L1 or genome doubling+L1 to compute distance
// mst_node_store and mst_edge_store are passed by reference and store the infered steiner tree
// tot_scg_sets is number of sets of probes on the same chromosome
// scg is a matrix indicating which probes go together on the same chromosome
// probes_on_chromosome[i] indicates how many probes are on the same chromosome as probe i
// Returns the total number of nodes in the infered steiner tree
int median_joining(int tot_terminals, int probes, int terminals[][MAX_PROBES], int **mst_node_store, int **mst_edge_store, int /* epsilon */, int distance_option, int tot_scg_sets, int **scg, int *probes_on_chromosome)
{
   // maximum number of total nodes that can be generated and tested
   int total_possible_nodes =  tot_terminals + MAX_STEINER_NODES_HEURISTIC;
   assert(total_possible_nodes > 0);
	
   //component_index keeps track of which node belongs to which component
   vector<int> component_index(total_possible_nodes);

   // keeps track of total number of steiner nodes generated in a particular pass of the algorithm
   int steiners = 0;   
   
   // nodes array stores the copy number value of each probe belonging to each node in the tree
   int (*nodes)[MAX_PROBES] =
       new int[tot_terminals+MAX_STEINER_NODES_HEURISTIC][MAX_PROBES];

   // 2D vector distance stores the pairwise distances amongst the nodes
   vector<vector<int> > distance;
   distance.resize(total_possible_nodes);
   for (int i = 0; i < total_possible_nodes; ++i){
       distance[i].resize(total_possible_nodes);        
   }

   // stores the pairwise distance among the nodes in the candidate mst
   vector<vector<int> > mst_distance;
   mst_distance.resize(total_possible_nodes);
   for (int i = 0; i < total_possible_nodes; ++i){
       mst_distance[i].resize(total_possible_nodes);        
   }

   // stores the copy number count of each probe for each node in the candidate mst   
   int (*mst_nodes)[MAX_PROBES] =
       new int[tot_terminals+MAX_STEINER_NODES_HEURISTIC][MAX_PROBES];

   // copy the terminals probe count value in the MST node array
   assert(tot_terminals>0);
   for (int i = 0; i < tot_terminals; i++)
       for (int j = 0; j < probes; j++)
           mst_nodes[i][j] = nodes[i][j] = terminals[i][j];
   
   // Declare variables to hold the edges. Each edge is stored in one
   // row of the array and represented by the two nodes' indices.
	 // mst_edges holds the edges for a particular MST generated at each loop.
	 // mst_edge_storage holds the edges for the minimally weighted MST generated so far
   int (*mst_edges)[2] = new int[total_possible_nodes][2];
   int (*mst_edge_storage)[2] = new int[total_possible_nodes][2];

   // Stores whether there is an edge between a particular pair of nodes
   // Note: vector<char> not vector<bool> because vector<bool> has oddball
   // semantics.
   vector<vector<char> > edge_indicator(total_possible_nodes,
                                        vector<char> (total_possible_nodes));

	 // Keeps track of the number of iterations in the algorithm
   int loop = 0;

   cout << "\nTotal terminals: " << tot_terminals;
   
   // Generate distance matrix that includes only the terminal nodes
   generate_distance_matrix(distance, nodes, tot_terminals, probes, 0, distance_option, tot_scg_sets, scg, probes_on_chromosome);

   // store the distance matrix of the 0-steiner mst for future use

	for(int t1 = 0; t1 < tot_terminals; t1++){
		for(int t2 =0; t2 < tot_terminals; t2++){					
			mst_distance[t1][t2] = distance[t1][t2];
		}				
	}
		
   
   // Generate MST that comprises of only the terminal nodes 
   int terminal_tree_weight = mst_prim(tot_terminals, distance, mst_edges, terminals, probes, INT_MAX);

   cout << "\nWeight of the 0-steiner MST: " << terminal_tree_weight << endl;
   
   // Set the weight of the MST as the minimum weight identified so far
   int global_min = terminal_tree_weight;
   
   // Store the edges of the MST as the minimal one
   for (int i = 0; i < tot_terminals; i++)
        for (int j = 0; j < 2; j++)
                mst_edge_storage[i][j] = mst_edges[i][j];
   
   while(1){
       
			 // Increases the total number of loops and checks whether maximum
			 // number of allowed iterations number has been reached
       loop += 1;
       if(loop == MAX_ITERATION)
           break;			 
       
			 // First identify the minimum spanning network (MSN).
       // Initialize the MSN by putting each node in a separate 
       // component and indicating no edge between any pair of nodes
       for (int i = 0; i < total_possible_nodes; i++){
           component_index[i] = i;
           for (int j = 0; j < total_possible_nodes; j++)
               edge_indicator[i][j] = 0;           
       }            
       
       // Check vector saves a representative decimal value for each
       // node which is calculated using the probe count values 
       // for each node currently in use in the tree
       vector<unsigned int> check_vector;
       unsigned int temp = 0;

			// Iterate through each of the nodes
       for (int i = 0; i < tot_terminals+steiners; i++){
          temp = 0;

					// For each node, iterate through all the probe count
					// values and calculate the decimal value 
          for (int j = 0; j < probes; j++){
              temp += (nodes[i][j] * myPow(MAX_COPY + 1,probes-j-1));
          }
          check_vector.push_back(temp);
       }   
       // Check vector saves a representative decimal value for each
       // node which is calculated using the probe count values
       // for each node either in the tree or a Steiner node
       // candidate.
       vector<unsigned int> candidate_check(check_vector);
       
       // Generate the distance matrix for building the MST using the terminals and steiner nodes
       generate_distance_matrix(distance, nodes, tot_terminals+steiners, probes, tot_terminals,distance_option, tot_scg_sets, scg, probes_on_chromosome);
       
       // Stores the total number of steiner nodes inferred at a particular stage
			 // of the algorithm
       int steiner_at_this_level = 0;

			 // Start of MSN building algorithm
       // This while loop identifies set of feasible edges
       while(1){ 
           
           int row = -1;
           int col = -1; 
 
           // Identifies the edge with minimum weight which connects nodes
					 // from two different components
           return_min_index(row, col, distance, tot_terminals+steiners, &component_index[0]);   
           
           // Change the entries in the edge_indicator table to reflect the 
           // inclusion of the selected edge                      
           edge_indicator[row][col] = 1;
           edge_indicator[col][row] = 1;
           
           // Merge the two components connected by the selected minimum weight 
           // edge. Change the component index identifier array so that the two
           // merged components have same component identifier.
					 // Holds the old index of a component. 
           int old_index = 0; 
           
           // Identify which component index identifier is smaller of the two 
           // and replace the larger one with that. Keep track of the older 
           // component index.
           if(component_index[row] < component_index[col]){
               old_index = component_index[col];
               component_index[col] = component_index[row];
           }
           else{
               old_index = component_index[row];
               component_index[row] = component_index[col];
           }
           
           // Go through the other nodes' component index identifier
           // and update them if needed for the minimal weight node
           for (int i = 0; i < tot_terminals+steiners; i++){
               if(component_index[i] == old_index)
                        component_index[i] = component_index[row];
           }

					 // counter to check if all the nodes is placed in the same component
           int counter = 0;
           
           // Checks to see if the graph is connected or not, meaning
           // all the nodes have been placed in the same component
           // and thus have same component index identifier. 
           for (int i = 1; i < tot_terminals+steiners; i++){               
               if(component_index[i] != component_index[i-1])
                   break;
               else
                   counter += 1;
           } 
           
           // If the graph is connected, then stop
           if(counter == tot_terminals + steiners-1)
               break;
       }  // end of inner while(1) loop       
       
       // Counter to keep the total count of triplets			   
       int triplets = -1;
       
       // Declare vector for storing triplet nodes' indices
       vector<vector<int> > triplet_store;       
       triplet_store.resize(MAXIMUM_TRIPLETS);   
       for (int i = 0; i < MAXIMUM_TRIPLETS; ++i){          
           triplet_store[i].resize(3);            
       }
       
       // Generate the triplets. 
			 // Iterate through all 3-node subsets in the MSN and checks if any 2 nodes in those
       // cardinality 3 subsets are connected or not
       for (int i = 0; i < tot_terminals+steiners; i++){
           for (int j = i+1; j < tot_terminals+steiners-1; j++){
               
               // Check if the two selected nodes are connected
               if(edge_indicator[i][j] == 1){                   
                   
                   for(int k = j+1; k < tot_terminals+steiners; k++){
                       
                       // Check if the third node is connected to any or 
                       // either of the two previously selected nodes or not
                       if(edge_indicator[i][k] == 1){
                           
                           // Increase the number of triplets by 1 and store 
                           // the triplet's node indices
                           triplets += 1;
                           triplet_store[triplets][0] = i;
                           triplet_store[triplets][1] = j;
                           triplet_store[triplets][2] = k;
                       }
                       if((edge_indicator[j][k] == 1) && ((k!=i)||(k!=j))){   
                           
                           // Increase the number of triplets by 1 and store 
                           // the triplet's node indices
                           triplets += 1;
                           triplet_store[triplets][0] = i;
                           triplet_store[triplets][1] = j;
                           triplet_store[triplets][2] = k;
                       }   
                   }                    
                }              
              }               
           }    
           
       // If no new triplets have been identified at this stage, then break
       if(triplets == -1)
           break;

       triplets += 1;
       
       // Prune the list of triplets to remove the duplicate ones
       triplets = prune_table_local(triplet_store,triplets,3);
      
       int steiner_count = -1;
       
       // Declare the storage for candidate steiner nodes
       vector<vector<int> > steiner_store(MAX_STEINER_NODES_HEURISTIC,
                                          vector<int>(probes));      
       
       // Loop through each set of triplet nodes index 
       for (int i = 0; i < triplets; i++){ 
           
					 // temporary storage for holding each set of triplet nodes
           int (*triplet_nodes)[MAX_PROBES] = new int[3][MAX_PROBES];
					 
           // store the nodes in the triplet node store           
           for(int counter = 0; counter < 3; counter++){               
               for (int l = 0; l < probes; l++){
                   triplet_nodes[counter][l] = nodes[triplet_store[i][counter]][l];                   
                }               
           }

					 // arr is used in the generate_candidate routine.
           vector<int> arr(probes);
           for (int iprobe = 0; iprobe < probes; iprobe++)
              arr[iprobe] = 0;
          
          // Declare storages for holding the candidate steiner nodes
          int res_size;
          int allocation_size_possibility1 =  myPow(3,probes);
          int allocation_size_possibility2 =
              MAX_CANDIDATES + (2 * MAX_STEINER_NODES_HEURISTIC);

          if (allocation_size_possibility1 > allocation_size_possibility2)
              res_size = allocation_size_possibility2;
          else
              res_size = allocation_size_possibility1;

          int (*result)[MAX_PROBES] = new int[res_size][MAX_PROBES];
          
          // Generate the candidate steiner nodes using the triplets
          int tot_steiners = generate_candidate(&arr[0], triplet_nodes, result, 3, probes, candidate_check);
  
					// Iterate through each candidate steiner node that has been generated.          
          // Test each steiner node to see if it can be included in the final set.          
          for (int j = 0; j < tot_steiners; j++){ 
            if (steiner_count == MAX_STEINER_NODES_HEURISTIC - 1)
              break;

              steiner_count += 1;
              
              // Include the selected steiner node in the node set to consider
              // it for MST generation
              for (int indexer = 0; indexer < probes; indexer++){
                  mst_nodes[tot_terminals+steiners][indexer] = steiner_store[steiner_count][indexer] = result[j][indexer];                  
              }
              
              // Generate the distance matrix for MST generation
              generate_distance_matrix(mst_distance, mst_nodes, tot_terminals+steiners+1, probes, tot_terminals,distance_option, tot_scg_sets,scg, probes_on_chromosome);
              
              // Generate the MST using the terminal set and the selected steiner node
              int w = mst_prim(tot_terminals+steiners+1,mst_distance,mst_edges,mst_nodes,probes,global_min);
              
              // if inclusion of a candidate steiner node reduces the tree weight, 
              // then include it in the steiner tree
              
              if(w < global_min){                
                global_min = w;
                temp = 0;
                
                // Calculate the representative decimal value for the steiner
                // node using the probe count values 
                for (int index = 0; index < probes; index++)                
                        temp += (result[j][index] * myPow(MAX_COPY + 1,probes-index-1));
                
                // Check if the selected steiner node has a match with the
                // terminal nodes or already stored steiner nodes
                
                if(!(binary_search (check_vector.begin(), check_vector.end(), temp))){ 
                    
                        // If the selected steiner node is a unique one, then push
                        // into the checking vector storage and sort the vector
                        // to facilitate future search operations
                        check_vector.push_back(temp);
                        sort(check_vector.begin(),check_vector.end());                
                        
                        // Store the steiner nodes in the node storage array
                        for (int index = 0; index < probes; index++){                        
                                nodes[tot_terminals+steiners][index] = mst_nodes[tot_terminals+steiners][index];//=  temp_store[ii][jj];                
                        }
                        
                        // Store the edges of the minimum weight MST identified so far
                        for (int out_index = 0; out_index < tot_terminals+steiners; out_index++)
                            for (int in_index = 0; in_index < 2; in_index++)
                                mst_edge_storage[out_index][in_index] = mst_edges[out_index][in_index];
												
												// Increase total steiner node counter and counter specific to this stage
                        steiners += 1;                        
                        steiner_at_this_level += 1;
                }           
              }                         
          } // end of for loop where each steiner node is stored
          delete [] result;
          delete [] triplet_nodes;
       }   // end of outer for loop where each triplet is tested        
      
       cout << "\n" << loop << " Pass Completed. " << steiner_at_this_level << " steiner nodes are added at this pass"; 
       
       // If maximum number of allowable steiner nodes are 
       // identified then stop
       if(steiners == MAX_STEINER_NODES_HEURISTIC)
           break;
       
       // If no new steiner node is identified at this stage then stop
       if(steiner_at_this_level == 0)
           break;       
      
   }  // end of outer most while(1)

   cout << "\n\nProgram is finished. Total nodes: " << tot_terminals+steiners <<". Total steiner nodes: " << steiners;
   cout << "\nWeight of the final tree: " << global_min << endl;
   
   // Finally copy the tree nodes and edges in the return storage array   
   for (int i = 0; i < tot_terminals+steiners-1; i++){
       mst_edge_store[i][0] = mst_edge_storage[i][0];
       mst_edge_store[i][1] = mst_edge_storage[i][1];       
   }   
   for (int i = 0; i < tot_terminals+steiners; i++){        
       for (int j = 0; j < probes; j++){           
           mst_node_store[i][j] = nodes[i][j];
       }           
   }
   
   delete [] nodes;
   delete [] mst_edge_storage;
   delete [] mst_edges;
   delete [] mst_nodes;

   return (tot_terminals + steiners);
  
}  

// Generate the distance matrix for a set of given terminals and steiner nodes
// weight stores the pairwise distance between the nodes
// terminals is the probe count of the records in the patient file
// tot_terminals is the total number of terminals
// probes is the total number of probes listed by the user
// start denotes the minimum index from which the distance calculation starts
// distance_option denotes whether to use L1 or genome doubling+L1 to compute distance
// weight is passed by reference
// calculated pairwise distance is stored in weight
// tot_scg_sets is number of sets of probes on the same chromosome
// scg is a matrix indicating which probes go together on the same chromosome
// probes_on_chromosome[i] indicates how many probes are on the same chromosome as probe i
void generate_distance_matrix(vector<vector<int> > &weight, int terminals[][MAX_PROBES], int tot_terminals, int probes, int start, int distance_option, int tot_scg_sets, int **scg, int *probes_on_chromosome)
{
    // Iterate through each pair of node
    for(int i = 0; i < tot_terminals; i++){
        for(int j = start; j < tot_terminals; j++){
            
            // Fill up the diagonal entries of the matrix with 0
            if(i == j)
                weight[i][j] = 0;
            
            // For non diagonal entries of the matrix, compute the 
            // rectilinear distance between the two nodes and store
            // it in the weight matrix
            else{
	      if (i < j) {
                int w = 0;
                for (int k = 0; k < probes; k++)
                    w = w + abs(terminals[i][k]-terminals[j][k]);   
		if(distance_option == PLOIDY_LESS_HEURISTIC)             
		  weight[i][j] = weight[j][i] = w;
		else{
		  // Find which copy number profile is lexicographically smaller
		  int smaller = i;
		  int other = j;
		  for (int k = 0; k < probes; k++){
		    if(terminals[i][k] == terminals[j][k])
		      continue;
		    if(terminals[i][k] < terminals[j][k])
		      break;
		    if(terminals[i][k] > terminals[j][k]){
		      smaller = j;
		      other = i;						
		      break;
		    }
		  }
		  // Invoke the distance function if the L1 distance is greater than 1
		  if(w > 1)
		    w = calculate_pairwise_distance(terminals[smaller],terminals[other],probes, tot_scg_sets, scg, probes_on_chromosome);		
		  weight[i][j] = weight[j][i] = w;
		} //else
	      } //if i < j
            } //else 
	} // inner for
    } // outer for        
}

// Identify and return index of the pair of nodes whose edge has minimal weight
// row and col holds the row and column indices of the minimal weight edge nodes
// distance stores the pairwise distance between the nodes
// tot_nodes is the total number of nodes in the tree
// component_index holds the index of the component to which each node belongs to
// row and col are passed by reference
// minimal weight edge nodes' indices are stored in row and col
void return_min_index(int &row, int &col, const vector<vector<int> > & distance, int tot_nodes, int component_index[])
{
    int min = INT_MAX;
    
    // Iterate through each pair of nodes
    for (int i = 0; i < tot_nodes; i++){
        for (int j = 0; j < tot_nodes; j++){
            
            // If the distance between the two nodes belonging to two
            // different components has minimum weight identified so
            // far, then save the nodes' identifiers
            if((distance[i][j] < min) && (component_index[i]!=component_index[j])){
                min = distance[i][j];
                row = i;
                col = j;
            }
        }
    }    
}

// Prune the steiner node index table to remove duplicate steiner nodes
// store stores the steiner nodes copy number count
// tot_record is the total number of records in the store array
// number_of_probes is the total number of probes listed by the user
// Returns total number of steiner nodes after pruning
int prune_table_local(vector<vector<int> > &store, int total_record, int number_of_probes)
{
    // stores the total number of unique steiner nodes identified so far
		int cur_total = 0;  

		// Check vector saves a representative decimal value for each
    // node which is calculated using the probe count values   
    vector<unsigned int> check_vector; 
   
		// Temporary storage for holding the unique steiner nodes probe count 
    vector<vector<int> > temp_store(total_record, 
                                    vector<int>(number_of_probes));
    
    // Iterate through each steiner node
    for (int i = 0; i< total_record; i++){ 
        unsigned int temp = 0;
        
        // Calculate the representative decimal value for the steiner
        // node using the probe count values
        for (int j = 0; j < number_of_probes; j++){
            temp += (store[i][j] * myPow(MAX_COPY + 1,number_of_probes-j-1));
        } 
        
        // Check if the selected steiner node has a match with the
        // already stored steiner nodes
        if (!(binary_search (check_vector.begin(), check_vector.end(), temp))){
            
            // If the selected steiner node is a unique one, then push
            // into the checking vector storage and sort the vector
            // to facilitate future search operations
            check_vector.push_back(temp);
            sort(check_vector.begin(),check_vector.end());
            
            // Store the steiner node in the temporary array
            for (int j = 0; j < number_of_probes; j++){
                temp_store[cur_total][j] = store[i][j];                
            }
            
            cur_total += 1;
        }        
    }
    
    // Copy the set of unique steiner nodes in the array 
    // to be returned from the method
    for (int i = 0; i < cur_total; i++){        
        for (int j = 0; j < number_of_probes; j++)
            store[i][j] = temp_store[i][j];
    }
    return cur_total;       
            
}





