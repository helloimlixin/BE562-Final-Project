#include <algorithm>
#include <iostream>
#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>

#include <cassert>

using namespace std;

#include "consensus_trees.h"

// Test that the child_parent_map is a tree -- that it contains no cycles,
// that each parent node that is not "nil" is also a child (the root has
// parent "nil"), and that exactly one node as "nil" as a parent.
static bool
is_valid_tree(const child_parent_map & tree)
{
  int num_root_nodes = 0;  // nodes with parent 'nil'
  node_set visited;
  child_parent_map::const_iterator p = tree.end();
  for (p = tree.begin();  p != tree.end();  ++p) {
    const string & descendant = p->first;
    string parent = p->second;

    if (parent == "nil" && ++num_root_nodes > 1)
      return false;

    while (parent != "nil" && visited.count(parent) == 0) {
      if (parent == descendant)
        return false; // We found a cycle.

      if (tree.count(parent) == 0)
        return false; // The alleged parent is not a node in the tree.

      visited.insert(parent);
      parent = tree.at(parent);
    }
    visited.insert(descendant);
  }
  return true;
}

// Return a subset of the nodes in 'wanted' that occur
// in 'trees' at least 'min_count_nodes' times.
node_set
find_targeted_nodes(const node_set & wanted,
                    const vec_child_parent_map & trees,
                    int min_count_nodes)
{
  map<string,int> node_count;

  for (size_t k = 0;  k < trees.size();  k++) {
    child_parent_map::const_iterator p;
    for (p = trees[k].begin();  p != trees[k].end();  ++p) {
      const string & child = p->first;
      // If these are valid trees, then the set of all nodes
      // in the tree is exactly the set of children (the root
      // node has parent 'nil).
      if (wanted.count(child))
        ++node_count[child];
    }
  }
  node_set nodes;
  map<string,int>::iterator nn;
  for (nn = node_count.begin();  nn != node_count.end();  ++nn) {
    const string & node = nn->first;
    int count = nn->second;
    if (count >= min_count_nodes)
      nodes.insert(node);
  }
  return nodes;
}

// Return nodes that occur in 'trees' at least 'min_count_nodes' times.
node_set
find_shared_nodes(const vec_child_parent_map & trees,
                  int min_count_nodes)
{
  map<string,int> node_count;

  for (size_t k = 0;  k < trees.size();  k++) {
    child_parent_map::const_iterator p;
    for (p = trees[k].begin();  p != trees[k].end();  ++p) {
      const string & child = p->first;
      // If these are valid trees, then the set of all nodes
      // in the tree is exactly the set of children (the root
      // node has parent 'nil).
      ++node_count[child];
    }
  }
  node_set nodes;
  map<string,int>::iterator nn;
  for (nn = node_count.begin();  nn != node_count.end();  ++nn) {
    const string & node = nn->first;
    int count = nn->second;
    if (count >= min_count_nodes)
      nodes.insert(node);
  }
  return nodes;
}


// Given a tree (or technically a collection of trees), produce a new
// tree (or collection of trees) containing only nodes in 'wanted'.
//
// Replace each path in the original tree that has endpoints in
// 'wanted' -- but intermediate points not in 'wanted' -- with an
// edge between the endpoints.
//
// If 'tree' has cycles -- i.e. is not a tree -- an infinite loop will
// occur.
//
// If the root node is not in 'wanted', an unusual situation, the
// output will be a collection of trees.
static child_parent_map
condense_tree(const node_set & wanted,
              const child_parent_map & tree)
{
  child_parent_map condensed_tree;

  node_set::const_iterator child, pend = wanted.end();

  int nnodes = tree.size();

  for (child = wanted.begin();  child != pend;  ++child) {
    if (tree.count(*child) == 0)
      continue; // 'child' is not in the tree
    string parent = tree.at(*child);
    int edge_count = 0;
    // While 'parent' is a node of tree (i.e. is not "nil"), but not
    // in 'wanted',...
    while (tree.count(parent) && 0 == wanted.count(parent)) {
      parent =  tree.at(parent);
      ++edge_count;
      assert(edge_count < nnodes); // Safety valve in case of a cycle
    }
    condensed_tree[*child] = parent;
  }
  assert(is_valid_tree(condensed_tree));
  return condensed_tree;
}

// Apply 'condense_tree' with the same set of wanted nodes to a
// vector of trees.
static vec_child_parent_map
condense_trees(const node_set & wanted, const vec_child_parent_map & trees_in)
{
  vec_child_parent_map condensed;
  vec_child_parent_map::const_iterator tree;
  for (tree = trees_in.begin();  tree != trees_in.end();  ++tree) {
    condensed.push_back( condense_tree(wanted, *tree) );
  }
  return condensed;
}

// Count the number of times each edge -- specifically a child -> parent
// pair, not an edge type -- occurs in a collection of trees.
static map<child_parent_edge,int>
count_edges(const vec_child_parent_map & trees)
{
  map<child_parent_edge, int> edge_counts;

  for (size_t k = 0;  k < trees.size();  k++) {
    child_parent_map::const_iterator p, pend = trees[k].end();
    for (p = trees[k].begin();  p != pend;  ++p) {
      const string & parent = p->second;
      // Drop edges to "nil".
      if (parent == "nil")
        continue;
      ++edge_counts[*p];
    }
  }
  return edge_counts;
}


// Find all edges occurring at least 'min_count' times within a set of
// trees.  Edges to "nil" (which mark root nodes in the input trees)
// are never included.
static vec_cp_edges
find_shared_edges(const vec_child_parent_map & trees, int min_count)
{
  vec_cp_edges shared_edges;
  map<child_parent_edge, int> edge_counts = count_edges(trees);

  map<child_parent_edge, int>::iterator q, qend = edge_counts.end();
  for (q = edge_counts.begin();  q != qend;  ++q) {
    const child_parent_edge & edge = q->first;
    int count = q->second;
    if (count >= min_count)
      shared_edges.push_back(edge);
  }
  return shared_edges;
}

// Find the root of the tree -- the node with parent 'nil'.
// If there is (in error) more than one root, return the first.
static string
find_tree_root(const child_parent_map & tree)
{
  child_parent_map::const_iterator p;
  for (p = tree.begin();  p != tree.end();  ++p) {
    if (p->second == "nil")
      return p->first;
  }
  assert(0 && "Could not find a root in tree");
  return "nil";
}


// Given a vector of (child => parent) edges, produce a mapping of
// each parent to all of its children (as a C++ STL multimap).
static multimap<string,string>
map_parent_to_children(const vec_cp_edges & edges)
{
  multimap<string,string> parent_to_children;
  vec_cp_edges::const_iterator p, pend = edges.end();
  for (p = edges.begin();  p != pend;  ++p) {

    const string & child = p->first;
    const string & parent = p->second;
    // Swap the order of nodes in the edge to be (parent => child).
    parent_to_children.insert( make_pair(parent, child) );
  }
  return parent_to_children;
}

// Find the collection of edges within 'distinct_edges' that are
// connected by some path to root.  The vector 'distinct_edges' should
// only contain each edge *once*.
//
// By definition, the result set can be empty.  This would happen
// if the component connected to root would be a singleton.
static vec_cp_edges
find_root_component(const vec_cp_edges & distinct_edges,
                    const string & root_name)
{
  vec_cp_edges root_component;
  node_set connected_to_root;

  typedef multimap<string,string>::iterator child_it;
  typedef pair<child_it, child_it> child_range;

  multimap<string,string> parent_to_children =
    map_parent_to_children(distinct_edges);

  vector<string> next_parent;
  next_parent.push_back(root_name);

  while(!next_parent.empty()) {
    string parent = next_parent.back();
    next_parent.pop_back();

    child_range range = parent_to_children.equal_range(parent);
    for (child_it p = range.first;  p != range.second;  ++p) {
      string & child = p->second;

      // Even if we have already seen child, we haven't yet
      // seen the edge from this parent.
      root_component.push_back(make_pair(child, parent));
      if (connected_to_root.count(child) == 0) {
         // This is the first time we have seen 'child'.
        connected_to_root.insert(child);
        next_parent.push_back(child);
      }
    }
  }
  return root_component;
}

// Find the directed graph (list of edges), such that
// a) all nodes are in 'wanted';
// b) all nodes occur in at least 'min_count_node' input trees;
// c) all edges represent a path connecting two elements of 'wanted'
//    in some tree, with all intermediate nodes in the path not in
//    'wanted'
// d) Each edge representing such a path in at least 'min_count_edges'
//    trees; and
// e) all nodes in the output graph are connected (in a directed sense) to
//    root
vec_cp_edges
find_consensus_graph(const vec_child_parent_map & trees_in,
                     const node_set & wanted,
                     int min_count_node, int min_count_edge)
{
  vec_cp_edges consensus_graph;

  if (trees_in.empty())
    return consensus_graph; // Ask a stupid question...

  node_set targeted_nodes =
    find_targeted_nodes(wanted, trees_in, min_count_node);
  vec_child_parent_map condensed_trees =
    condense_trees(targeted_nodes, trees_in);

  vec_cp_edges edges = find_shared_edges(condensed_trees, min_count_edge);
  string root_name = find_tree_root(trees_in[0]);

  return find_root_component(edges, root_name);
}


// Find the same graph created by find_consensus_graph(), but as a
// child_parent_map, rather than a list of edges, and containing a edge
// from root to 'nil'.  This child_parent_map *may* be a tree; it must
// be a tree if min_count_node == min_count_edge == trees_in.size().
child_parent_map
find_consensus_tree_fragment(const vec_child_parent_map & trees_in,
                             const node_set & wanted,
                             int min_count_node, int min_count_edge)
{
  vec_cp_edges edges = find_consensus_graph(trees_in, wanted, min_count_node,
                                            min_count_edge);
  sort(edges.begin(), edges.end(), greater<child_parent_edge>());
  string root_name = find_tree_root(trees_in[0]);

  child_parent_map tree(edges.begin(), edges.end());
  tree[root_name] = "nil";  // always at root
  return tree;
}

// Find all nodes mentioned in a list of edges -- the union of the set of
// child nodes and the set of parent nodes.
node_set
find_edge_nodes(const vec_cp_edges & edges)
{
  node_set nodes;
  vec_cp_edges::const_iterator edge;
  for (edge = edges.begin();  edge != edges.end();  ++edge) {
    nodes.insert(edge->first);
    if (edge->second != "nil")
      nodes.insert(edge->second);
  }
  return nodes;
}

// Edges, as they will be displayed by print_core_dot().
struct displayed_edge {
  int parent;
  int child;
  string style;
};

// Nodes, as they will be displayed by print_core_dot().
struct displayed_node {
  int index;
  string label;
  string style;
  string shape;
};

// Gather the node information that will be displayed by print_core_dot().
vector<displayed_node>
displayed_nodes(const vec_cp_edges & core_edges,
                const vec_child_parent_map & trees,
                const node_set & observed_nodes,
                bool core_only)
{
  enum { any_tree = 1 };
  node_set core_nodes = find_edge_nodes(core_edges);
  node_set tree_nodes;
  if (core_only) {
    tree_nodes = core_nodes;
  }
  else {
    tree_nodes = find_shared_nodes(trees, any_tree);
  }
  vector<displayed_node> nodes;
  int i = 0;
  node_set::iterator p, pend = tree_nodes.end();
  for (p = tree_nodes.begin();  p != pend;  ++p) {
    displayed_node dn;
    dn.index = i++;
    dn.label = *p;
    dn.style = observed_nodes.count(*p) ? "bold" : "dotted";
    dn.shape = core_nodes.count(*p) ? "ellipse" : "box";

    nodes.push_back(dn);
  }
  return nodes;
}

// Gather the node information that will be displayed by print_core_dot()
// when there are exactly two input trees.  (Node shapes change according
// to which tree(s) the node appears in).
vector<displayed_node>
displayed_alternating_nodes(const child_parent_map & tree_a,
                            const child_parent_map & tree_b,
                            const node_set & observations)
{
  enum { a = 0, b = 1, ab = 2, any_tree = 1 };
  const char * shapes[3] = { "box", "diamond", "ellipse" };

  vec_child_parent_map trees;
  trees.push_back(tree_a);
  trees.push_back(tree_b);

  node_set raw_nodes = find_shared_nodes(trees, any_tree);

  vector<displayed_node> nodes;
  int i = 0;
  node_set::iterator nn;
  for (nn = raw_nodes.begin();  nn != raw_nodes.end();  ++nn) {
    int membership;
    if (tree_a.count(*nn)) {
      membership = tree_b.count(*nn) ? ab : a;
    } else {
      membership = b;
    }
    displayed_node dn;
    dn.index = i++;
    dn.label = *nn;
    dn.style = observations.count(*nn) ? "bold" : "dotted";
    dn.shape = shapes[membership];

    nodes.push_back(dn);
  }
  return nodes;
}

// Gather the edge information that will be displayed by print_core_dot().
vector<displayed_edge>
find_displayed_edges(const vec_cp_edges & core_edges,
                     const vec_child_parent_map & trees,
                     bool core_only)
{
  vector<displayed_edge> edges_out;
  enum { kany_tree = 1 };
  set<child_parent_edge> core_edges_set(core_edges.begin(),
                                        core_edges.end());
  node_set tree_nodes;
  if (core_only) {
    tree_nodes = find_edge_nodes(core_edges);
  } else {
    tree_nodes = find_shared_nodes(trees, kany_tree);
  }
  node_set::iterator node;
  int i = 0;
  map<string, int> index_of;
  for (node = tree_nodes.begin();  node != tree_nodes.end();  ++node) {
    index_of[*node] = i++;
  }

  map<child_parent_edge, int> edge_counts = count_edges(trees);
  map<child_parent_edge, int>::iterator p;
  for (p = edge_counts.begin();  p != edge_counts.end();  ++p) {
    const child_parent_edge & edge = p->first;
    if (core_only && core_edges_set.count(edge) == 0)
      continue;
    displayed_edge de;
    de.child =  index_of[edge.first];
    de.parent = index_of[edge.second];
    de.style = core_edges_set.count(edge) ? "bold" : "dashed";
    edges_out.push_back(de);
  }
  return edges_out;
}

// Display a consensus graph in GraphViz dot format.  The parameter
// 'core_edges' is the part in consensus, 'observed_nodes' is the set of
// nodes observed in the patient data, 'trees' is the collection of trees
// from which the consensus graph was formed, 'title' is a title that will
// be displayed in the graph (this is part of the GraphViz format), and if
// 'core_only' is true display only 'core_edges', otherwise also display
// edges not in the consensus graph, but display them as dashed lines.
ostream &
print_core_dot(ostream & ff, const vec_cp_edges & core_edges,
               const node_set & observed_nodes,
               const vec_child_parent_map & trees,
               const string & title,
               bool core_only)
{
  vector<displayed_node> dot_nodes;
  if ( trees.size() == 2 ) {
    dot_nodes =
      displayed_alternating_nodes(trees[0], trees[1], observed_nodes);
  } else {
    dot_nodes =
      displayed_nodes(core_edges, trees, observed_nodes, core_only);
  }
  ff << "digraph tree {\n";
  ff << "    node [shape=record];\n";
  ff << "    graph[label=<" << title << ">, labelloc=top, fontsize=24];\n";

  vector<displayed_node>::iterator node;
  for (node = dot_nodes.begin();  node != dot_nodes.end();  ++node) {
    ff << "    "       << node->index
       << " [label=\"" << node->label
       << "\", style=" << node->style
       << ", shape="   << node->shape << "];\n";
  }

  vector<displayed_edge> dot_edges =
    find_displayed_edges(core_edges, trees, core_only);

  vector<displayed_edge>::iterator edge;
  for (edge = dot_edges.begin();  edge != dot_edges.end();  ++edge) {
    ff << "    "    << edge->parent
         << " -> "     << edge->child
         << " [style=" << edge->style << "];\n";
  }
  ff << "}" << endl;
  return ff;
}
