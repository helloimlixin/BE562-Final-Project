#include <climits>

#include "mst_prim.h"

#include "binary_heap.h"

using namespace std;

const int inf = INT_MAX;

// Generates a minimum weight spanning tree (MST) using Prim's algorithm and binary heap data structure
// total is the total number of nodes in the tree
// weight stores the pairwise distance values amongst the nodes
// edges stores indices of the two nodes of each edge in the MST
// terminals stores the copy number count of each probe in each record
// probes is the total number of probes selected by the user
// weight is passed by reference
// min_weight is the weight of minimum weighted steiner tree generated so far
// returns the weight of the MST
int mst_prim(int total, const vector<vector<int> > & weight, int edges[][2], int /* terminals */[][MAX_PROBES], int /* probes */, int min_weight)
{
  // queue is built on keys of nodes
  // parent[i] stores the parent of i in the MST
  vector<int> parent(total+1);

  // is_in_queue[i] indicates whether node i is currently in queue or not.
  // if is_in_queue[i] is false, that means it has been removed from the queue
  // added to the tree
  vector<char> is_in_queue(total+1);

  // index stores the index of each node whose value is stored in the key array
  vector<int> index(total + 1);

  // For each vertex v, key[v] is the minimum weight of any edge connecting v
  // to a vertex in the already grown partial MST
  vector<int> key(total+1);

  // Initialize the root of the tree arbritarily to the node with index 1.
  int root = 1;

  // Initialize the key, parent, index and is_in_queue arrays
  for (int i = 1; i <= total; i++){
    key[i] = inf;
    parent[i] = 0;
    index[i] = i;
    is_in_queue[i] = true;
  }

  // queue counter points to the total number of elements in the queue
  int queue_counter = total;
  key[root] = 0;
 // the root node is still in the queue at this point
 // root will get extracted as the first minimum and then
 // the nodes adjacent to the root in the input graph will
 // get non-infinity keys

  // Build the min heap on the elements of the key array
  build_min_heap(&key[0],&index[0],total);

  // Stores the weight of the MST
  int mst_weight = 0;

  // Iterate until the queue is empty
  while(queue_counter > 0){

    // As the queue is maintained as a binary heap, the first element
    // is the one with the minimum key. Remove this element from the
    // queue which adds it to the growing tree.
    int u = index[1];

    // Restructure the heap so that min heap property is maintained
    int w = extract_min(&key[0], &index[0], queue_counter);
    mst_weight += w;

    // queue size is reduced by 1
    queue_counter -= 1;

    // Indicate that recently extracted node is not in queue anymore
    is_in_queue[u] = false;

    // Update the key and parent fields of every vertex adjacent to the
    // recently added node to the tree which have not been included in
    // the tree. Membership of a node v in the tree is identified by
    // checking whether is_in_queue[v] is false. If a node's key value
    // is changed, decrease_key is called to maintain the heap property
    // of the queue
    for (int i = 1; i <= queue_counter; i++){
      int v = index[i];
      if((is_in_queue[v]==true) && (weight[u-1][v-1] < key[i])){
    parent[v] = u;
    decrase_key(&key[0], &index[0], i, weight[u-1][v-1]);
      }

    }

  }

  // The edges of the MST can be identified by traversing the parent array,
  // where for each node v, (v,parent[v]) forms an edges in the tree. Copy
  // the node indices of the edges in the edges array and calculate the
  // weight of the MST. Return the edges only if the newly generated tree
  // is of less weight than the minimum weighted tree generated so far
  if(mst_weight < min_weight){
    for (int i = 2; i <= total; i++){
      edges[i-2][0] = i-1;
      edges[i-2][1] = parent[i]-1;
    }
  }
  return mst_weight;
}
