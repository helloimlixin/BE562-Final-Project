// In "2.5. Identifying a global consensus network", "We then find a 
// global consensus network by identifying all pathways used in at least 
// some fraction t of all patients. Given the per-patient trees T_1, 
/// ..., T_n, we can identify consensus pathways by searching 
// depth-first through each tree individually and then, for each node, 
// counting how many other trees have the same node and exhibit the same 
// pathway from that node to the root. Those pathways occurring in a t 
// fraction of trees are added to the global consensus network. For the 
// present study, t = 5%. Note that this consensus network need not 
// itself be a tree, since a node may be reachable by more than one 
// common pathway in different individual trees."

// Implementation of consensus edge (used in consensus graph).

#include "edgeconsensus.h"

#include "fish.h"

using namespace std;

// Class constructor.
edgeconsensus::edgeconsensus()
{
  // Initialize reference to tail/source node of directed edge to be NULL.
  tail = NULL;

  // Initialize reference to head/target node of directed edge to be NULL.
  head = NULL;

  // Initialize mutation type to be INVALID.
  type = INVALID;

  // Initialize number of files to be -1.
  number_of_files = -1;

  // Initialize number of edges to be -1.
  number_of_trees_sharing_edge = -1;
}

// Class constructor given tail/source and head/target nodes and type.
edgeconsensus::edgeconsensus(nodeconsensus *in_tail, nodeconsensus *in_head, 
  int in_type, int in_number_of_files) :
  vector_of_edges(in_number_of_files, (edge*)0)
{
  // Initialize reference to tail/source node of directed edge to be in_tail.
  tail = in_tail;

  // Initialize reference of head/target node of directed edge to be in_head.
  head = in_head;

  // Initialize mutation type to be in_type.
  type = in_type;

  // Initialize number of files to be in_number_of_files.
  number_of_files = in_number_of_files;

  // Initialize number of edges to be 0.
  number_of_trees_sharing_edge = 0;
}

// Output label of tail/source node, type and label of head/target node.
ostream &operator<<(ostream &output, const edgeconsensus &edge0)
{
  // Write tail/source node, edge type and head/target node.
  output << *(edge0.head) << "<-" << edge0.type << "--" << *(edge0.tail);

  // Return output results.
  return output;
}

// Get tail/source node of this edge.
nodeconsensus *edgeconsensus::get_tail()
{
  // Return tail/source node of this edge.
  return tail;
}

// Get head/target node of this edge.
nodeconsensus *edgeconsensus::get_head()
{
  // Return head/target node of this edge.
  return head;
}

// Set the corresponding reference in vector_of_edges to the given
// index and joint edge.
void edgeconsensus::set_edge_in_vector(int index_file, edge *ref_edge)
{
  // Check if current corresponding reference is NULL.
  if (vector_of_edges[index_file] == NULL)
  {
    // Increase number of valid refernces to joint edges if this
    // assignment is not a replacement and hence the if test succeeded.
    number_of_trees_sharing_edge++;
  }

  // Copy the given reference to joint edge into vector_of_edges.
  vector_of_edges[index_file] = ref_edge;
}

// Get the corresponding reference to the joint edge in
// vector_of_edges by the given index.
edge *edgeconsensus::get_edge_in_vector(int index_file)
{
  // Return reference to joint edge.
  return vector_of_edges[index_file];
}

// Get ratio of this consensus edge among all joint edges.
double edgeconsensus::get_ratio()
{
  // Return ratio of number_of_trees_sharing_edge divided by 
  // number_of_files.
  return ((double)number_of_trees_sharing_edge / (double)number_of_files);
}

int edgeconsensus::get_type()
{
  return type;
}
