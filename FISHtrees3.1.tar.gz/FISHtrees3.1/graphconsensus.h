// In "2.5. Identifying a global consensus network", "We then find a 
// global consensus network by identifying all pathways used in at least 
// some fraction t of all patients. Given the per-patient trees T_1, 
/// ..., T_n, we can identify consensus pathways by searching 
// depth-first through each tree individually and then, for each node, 
// counting how many other trees have the same node and exhibit the same 
// pathway from that node to the root. Those pathways occurring in a t 
// fraction of trees are added to the global consensus network. For the 
// present study, t = 5%. Note that this consensus network need not 
// itself be a tree, since a node may be reachable by more than one 
// common pathway in different individual trees."

// Definition of consensus graph.

#ifndef GRAPHCONSENSUS_H
#define GRAPHCONSENSUS_H

#include <list>
#include <map>
#include <string>
#include <utility>

#include "consensus_trees.h"
#include "graph.h"
#include "edgeconsensus.h"
#include "nodeconsensus.h"

// Declare graph to represent consensus network.
class graphconsensus
{
  // Label of chromosome and gene names.
  std::string label;

  // Root consensus node to represent normal cell.
  nodeconsensus *root;

  // List of consensus nodes.
  std::list<nodeconsensus *> list_of_nodes;

  // Table of consensus edges.
  // table_of_edges[i][j] represents the reference to the consensus edge 
  // from the i-th consensus node to the j-th sonsensus node.
  // table_of_edges[i][j] is NULL if there is no consensus edge from the 
  // i-th consensus node to the j-th sonsensus node.
  edgeconsensus ***table_of_edges;

public:
  // Class constructor.
  graphconsensus(): root(), table_of_edges() {}

  ~graphconsensus();

  // Add reference to given consensus node at the end of list_of_nodes.
  void add_node(nodeconsensus *);

  // Set up table of references to consensus edges given a vector of 
  // joint trees and number of joint trees.
  void set_edges(graph *[], int);

  // Output number of nodes and the corresponding probabilities given a 
  // threshold for the frequency (as probability) with which a consensus 
  // node that occurs among all joint trees.
  void output_at_least_threshold_nodes(std::string, double);

  // Output number of nodes and the corresponding probabilities given a 
  // threshold for the frequency (as probability) with which a consensus 
  // node that occurs among all joint trees and is reachable from the 
  // root consensus node.
  void output_at_least_threshold_nodes_from_root(std::string, double);

  // Output number of nodes and the corresponding probabilities given a 
  // threshold for the frequency (as probability) with which a consensus 
  // node and incoming consensus path (as edges) that occurs among all 
  // joint trees and isreachable from the root consensus node.
  void
  output_at_least_threshold_nodes_and_edges_from_root(std::string, double);

  void
  output_at_least_threshold_nodes_and_paths_from_root(std::string, double);

  int number_of_files()
  {
    return list_of_nodes.empty() ? 0 : list_of_nodes.front()->number_of_files;
  }

  // Output whole or partial consensus graph given a threshold as the 
  // ratio of a corresponding consensus node or edge occurs among all 
  // joint trees in Graphviz DOT format as defined in:
  // http://www.graphviz.org/doc/info/lang.html
  void
  output_at_least_threshold_in_dot_format(std::string, std::string, double);

  typedef std::map<std::string, nodeconsensus*> count_to_node_map;

  typedef std::pair<nodeconsensus *, nodeconsensus*> consensus_pair;

  count_to_node_map map_counts_to_nodes();
  vec_child_parent_map
    find_constituent_trees(const count_to_node_map & name_nodes);

  node_set find_observed_subset(const count_to_node_map & name_nodes);

  std::vector<nodeconsensus*>
    find_named_nodes(const node_set & names,
                     const count_to_node_map & name_to_nodes);
  std::vector<consensus_pair>
    find_named_edges(const child_parent_map & named_edges,
                     const count_to_node_map & name_to_nodes);

  void display_named_nodes(std::ostream & ss,
                           const node_set & names,
                           const count_to_node_map & name_to_node);

  void display_tree_fragment(std::ostream & ss,
                             const child_parent_map & fragment,
                             double threshold,
                             const count_to_node_map & names_to_nodes);
};

#endif
