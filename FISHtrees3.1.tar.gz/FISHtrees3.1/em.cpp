// In "2.4. Parameter inference", "We initialize the method with
// Algorithm 2 assuming each prior probability is 0.25 and then perform
// successive Monte Carlo steps as follows:
// (i) Pick a node u from the tree uniformly at random from all non-root
//     nodes.
// (ii) For each possible parent v of u, excluding current descendants,
//     compute w(v,u) = f_v p(v,u), where f_v is v's node frequency and
//     p(v,u) is the prior probability of the edge type from v to u.
//     Note that v might be u's current parent.
// (iii) Pick some v among all possible parents of u with probability
//     p_v = w(v,u) / \sum_x w(x,u).
// (iv) Delete the edge from u's current parent to u and replace it with
//     edge (v,u).
// Repeatedly applying this move creates a Markov model we call H".

#include <string>
#include <algorithm>

#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cmath>

#include "em.h"

#include "output.h"
#include "branching.h"

using namespace std;

const double my_random =
         (double)(MAX_COPY * MAX_COPY) + 1.0 / (double)MUTATION_TYPES;

#ifndef VERBOSE
#define VERBOSE 0
#endif


// Initialize vector of mutation probabilities for EM uniformly summed
// up to a given real number.
// In "2.4. Parameter inference", "We initialize the method with
// Algorithm 2 assuming each prior probability is 0.25".
static void
initialize_em_mutation_probabilities(double_vector em_mutation_prob,
                                     double init_value)
{
  for (int index = 0; index < MUTATION_TYPES; index++)
    em_mutation_prob[index] = init_value / (double)MUTATION_TYPES;
}


// Copy mutation probabilities from one vector to another vector.
static void
copy_mutation_probabilities(double_vector to_mutation_prob,
                            const double_vector from_mutation_prob)
{
  for (int index = 0; index < MUTATION_TYPES; index++)
    to_mutation_prob[index] = from_mutation_prob[index];
}


// Update vector of mutation probabilties for EM by normalizing the
// vector of accumulated edge type counts.
// In "2.4. Parameter inference", "For the maximization stage of the
// algorithm, we use the fraction of edges assigned to each type in
// the expectation phase as a maximum likelihood estimate of that
// edge type's prior probability for the next EM round".
static
void update_em_mutation_probabilities(double_vector em_mutation_prob,
                                      const int_vector edge_count)
{
  int total = 0;   // Total of all edge counts.

  // Sum up edge counts.
  for (int index = 0; index < MUTATION_TYPES; index++)
    total += edge_count[index];

  // Normalize.
  for (int index = 0; index < MUTATION_TYPES; index++)
    em_mutation_prob[index] = (double)edge_count[index] / (double)total;
}


// Fill a sparse matrix full of weights, using the transpose of the
// edge matrix in 'graph'
//
// weights - the nonzero weights in 'graph'
// jcol_weights - the column indices of the elements of 'weights'
// krow_weights - the indices at which each nonzero row of 'weights'
//     starts and stops.  For row i, for each k such that
//     krow_weights[i] <= k < krow_weights[i+1], weights[k] is an
//     element of row i at jcol_weights[k].
//
// 'krow_weights' must be graph->size + 1 elements long.
// 'weights' and 'jcol_weights' must be as long as the number of
// nonzero weights in the graph; to be safe, graph->size * graph->size
// elements may be allocated.
static void
fill_sparse_weights_transposed(double * weights, int krow_weights[],
                               int jcol_weights[], const graph * graph)
{
  int n = graph->size;
  edge *** edges = graph->table_of_edges;
  int k = 0;
  krow_weights[0] = 0;
  for (int i = 0;  i < n;  i++) {
    for(int j = 0;  j < n;  j++) {
      if (edges[j][i]) {
        weights[k] = edges[j][i]->weight; // Edges is *transposed*.
        jcol_weights[k] = j;
        ++k;
      }
    }
    krow_weights[i+1] = k;
  }
}


// Fill a matrix, which is stored as one dimensional array in
// row-major order, that represents the edge types in 'graph'.  The
// matrix may be thought of as an adjacency matrix, with an edge type
// of INVALID when no such directed edge between the nodes exists.
static void fill_edge_type_matrix(mutation_type * types, const graph * graph)
{
  int n = graph->size;
  edge *** edges = graph->table_of_edges;
  mutation_type * elt = types;

  for (int i = 0;  i < n;  i++) {
    for(int j = 0;  j < n;  j++) {
      *elt++ = edges[i][j] ? (mutation_type) edges[i][j]->type : INVALID;
    }
  }
}


// In "2.4. Parameter inference", "(i) Pick a node u from the tree
// uniformly at random from all non-root nodes".
static int get_random_non_root_node(int size,  int root_index)
{
  int random_index;

  // Generate a random node index other than root node index.
  do
  {
    //  A random number between 0 and size - 1 (since random() returns
    //  an int, but the division and multiplication are done in double
    //  precision, random_index must be less than size.)
    random_index = (int) ((random() / ((double) RAND_MAX + 1)) * size);
  }
  while (random_index == root_index);

  return random_index;
}


// Return the index of the existing parent of 'child' in 'tree'.
inline int
find_existing_parent(const mutation_type * tree, int n, int child,
                     const int krow_weights[], const int jcol_weights[])
{
  for (int k = krow_weights[child];  k < krow_weights[child+1];  k++) {
    int parent = jcol_weights[k];
    if (tree[parent * n + child] != INVALID)
      return parent;
  }
  assert(0 && "Could not find existing parent (is this node root?)");
  return -1;
}


// In "2.4. Parameter inference", "(ii) For each possible parent v of u,
// excluding current descendants, compute w(v,u) = f_v p(v,u), where f_v
// is v's node frequency and p(v,u) is the prior probability of the edge
// type from v to u. Note that v might be u's current parent".
//
// Return a randomly chosen permissible parent of 'child', ignoring
// prospective parents that are already a direct child of 'child'.
inline int
get_random_replacement_parent(const mutation_type * tree, int n, int child,
                              const double * weights,
                              const int krow_weights[],
                              const int jcol_weights[])
{
  const mutation_type * tree_row = tree + child * n;

  double sum_prob = 0;
  for (int k = krow_weights[child];  k < krow_weights[child+1];  ++k) {
    if (tree_row[jcol_weights[k]] == INVALID) {
      // There is not already a reversed edge from child to j -- if
      // there were, then the prospective parent 'j' would be actually
      // a direct child of 'child'.
      sum_prob += weights[k];
    }
  }

  // In "2.4. Parameter inference", "(iii) Pick some v among all possible
  // parents of u with probability p_v = w(v,u) / \sum_x w(x,u).

  // Get a random double precision number between [0.0, sum_prob); since
  // random() returns int but the calculations are done as double precision,
  // the number cannot be exactly equal to sum_prob (which is what we want).
  double random_prob = (random() / ((double) RAND_MAX + 1)) * sum_prob;

  double sum = 0;
  for (int k = krow_weights[child];  k < krow_weights[child+1];  k++) {
    int j = jcol_weights[k];
    if (tree_row[j] == INVALID) {
      sum += weights[k];
      // There is not already a reversed edge from child to j.
      if (random_prob < sum) {
        return j;
      }
    }
  }
  assert(0 && "Could not pick an random parent");
  return -1;
}


// Move an edge by changing parent of a non-root node in given tree.
// In "2.4. Parameter inference", "perform successive Monte Carlo steps"
// Perform successive Monte Carlo steps".
static void
perform_monte_carlo_steps(mutation_type * tree, int n,
                          int root_index, const double * weights,
                          const int krow_weights[], const int jcol_weights[],
                          const mutation_type * graph)
{
  int child = get_random_non_root_node(n, root_index);

  int parent =
    find_existing_parent(tree, n, child, krow_weights, jcol_weights);
  int new_parent =
    get_random_replacement_parent(tree, n, child, weights,
                                  krow_weights, jcol_weights);

  // In "2.4. Parameter inference", "(iv) Delete the edge from u's current
  // parent to u and replace it with edge (v,u)".
  if (parent != new_parent) { // Replace parent edge.
    tree[parent * n + child] = INVALID;
    tree[new_parent * n + child] = graph[new_parent * n + child];
  }
}


// Add the counts of edges in the adjacency matrix 'tree_edge_types'
// to the vector edge_counts.
static void
accumulate_edge_counts(int_vector edge_counts,
                       const mutation_type * tree, int n)
{
  int nsquared = n * n;
  for (int k = 0;  k < nsquared;   k++) {
    if (tree[k] != INVALID) {
      ++edge_counts[tree[k]];
    }
  }
}


// Calculate change between two vectors of mutation frequencies if the
// change is lower than the pre-defined threshold.
static bool
convergence_test(const double_vector new_mutation_prob,
                 const double_vector old_mutation_prob,
                 double & resid)
{
  bool convergent = false;
  double diff_sqr = 0.0;
  double old_sqr = 0.0;

  for (int index = 0; index < MUTATION_TYPES; index++)
  {
    old_sqr += old_mutation_prob[index] * old_mutation_prob[index];
    diff_sqr += (new_mutation_prob[index] - old_mutation_prob[index]) *
      (new_mutation_prob[index] - old_mutation_prob[index]);
  }

  if ((diff_sqr / old_sqr) - (BOUND_P * BOUND_P) < 0.0)
  {
    convergent = true;
  }

  resid = sqrt(diff_sqr);

  return convergent;
}


// Perform parameter inference.
// In "2.4. Parameter inference", "We estimate the parameter set \theta
// by EM".
void
perform_parameter_inference(graph *ref_tree, graph *ref_graph,
                            const string & name_chr,
                            const string & name_gene,
                            const obs_graph & /* gr */,
                            double_vector mutation_prob)
{
  // In "2.4. Parameter inference", "where n is the number of distinct
  // cell states"
  int n = ref_graph->size;
  assert(n > 0);
  // Graph and tree should have the same number of nodes.
  assert(ref_tree->size == n);

  if (n == 1) {   // No mutations are possible; probabilites are zero.
    for (int index = 0; index < MUTATION_TYPES; index++)
      mutation_prob[index] = 0.0;

    return;
  }

  double resid = .1;
  int nsquared = n * n, ncubed = n * nsquared;

  // Sparse matrix of weights -- see fill_sparse_weights_transposed() for
  // a description of the format.
  double * weights = new double[nsquared];
  int * jcol_weights = new int[nsquared];
  int * krow_weights = new int[n + 1];

  // Adjacency matrices of edge types -- see fill_edge_type_matrix().
  // These are stored as one-dimensional arrays in row-major order.
  mutation_type * graph_edge_types = new mutation_type[nsquared];
  mutation_type * tree_edge_types = new mutation_type[nsquared];

  int_vector edge_count;        // edge counts for all mutation types

  double_vector em_mutation_prob; // mutation probabilities from EM

  // Initialize vector of mutation probabilties for EM uniformly summed
  // up to 1.0.
  // In "2.4. Parameter inference", "We initialize the method with
  // Algorithm 2 assuming each prior probability is 0.25".
  initialize_em_mutation_probabilities(em_mutation_prob, 1.0);

  if (VERBOSE) {
    // Output initial vector of mutation probabilities for EM that are
    // uniformly summed up to 1.0.
    cout << "Initial mutation types and probabilities for EM =" << endl;
    output_mutation_probabilities(em_mutation_prob, name_chr, name_gene);
  }

  // prior mutation probabilties before each EM round
  double_vector prior_mutation_prob;

  int em_rounds = 0;                // number of EM rounds

  // In "2.4. Parameter inference", "We repeat the above steps until all
  // parameters converge with an error of less than one percent".
  long count_moves = 0;
  do
  {
    em_rounds++;

    // Probabilities from the previous round are this round's priors.
    copy_mutation_probabilities(prior_mutation_prob, em_mutation_prob);

    fill_n(edge_count, MUTATION_TYPES, 1);

    // Set edge weight for Monte Carlo steps as node frequency times
    // edge probability.
    // In "2.4. Parameter inference", "compute w(v,u) = f_v p(v,u),
    // where f_v is v's node frequency and p(v,u) is the prior
    // probability of the edge type from v to u".
    ref_graph->set_edge_weight_probability(em_mutation_prob);
    ref_graph->take_log_of_weights_for_highweight_branching();

    // Perform branching to find maximum weight arborescence.
    // In "2.3. Optimal tree inference", "4: Find a minimum-cost
    // arborescence on G by the method of Chu and Liu".
    {
      graph *hw_tree = findHighWeightBranching(ref_graph, true);
      for (int index_outer = 0; index_outer < ref_tree->size; index_outer++)
      {
        for (int index_inner = 0; index_inner < ref_tree->size; index_inner++)
        {
          // Move the edge between trees.
          delete ref_tree->table_of_edges[index_outer][index_inner];

          ref_tree->table_of_edges[index_outer][index_inner] =
            hw_tree->table_of_edges[index_outer][index_inner];

          hw_tree->table_of_edges[index_outer][index_inner] = NULL;
        }
      }
      assignParents(ref_tree);
      hw_tree->list_of_nodes.clear();  // Because nodes are shared
      delete hw_tree;
    }

    ref_graph->set_edge_weight_probability(em_mutation_prob);
    ref_tree->set_edge_weight_probability(em_mutation_prob);

    fill_sparse_weights_transposed(weights, krow_weights, jcol_weights,
                                   ref_graph);

    fill_edge_type_matrix(graph_edge_types, ref_graph);
    fill_edge_type_matrix(tree_edge_types, ref_tree);

    int root_index = ref_tree->root->index;
    // In "2.4. Parameter inference", "To ensure adequate mixing, we
    // apply the Monte Carlo move 100n^3 times per patient".
    int scale_factor;
    if (resid < 0.01) {
      scale_factor = 100;
    } else if (resid > 0.1) {
      scale_factor = 10;
    } else  {
      scale_factor = 1 / resid;
    }

    int total_moves = scale_factor * 10 * ncubed;
    for (int index_move = 1;  index_move <= total_moves;  index_move++)
    {
      // Perform Monte Carlo steps to move an edge in the given tree.
      perform_monte_carlo_steps(tree_edge_types, n, root_index,
                                weights, krow_weights, jcol_weights,
                                graph_edge_types);

      // In "2.4. Parameter inference", "counting edge types every 10n^2
      // moves".
      if ((index_move % (10 * nsquared)) == 0)
      {
        // Count and record edge types in the given tree.
        accumulate_edge_counts(edge_count, tree_edge_types, n);
      }
    }

    // Update vector of mutation probabilties for EM by normalizing the
    // vector of accumulated edge type counts.
    // In "2.4. Parameter inference", "For the maximization stage of the
    // algorithm, we use the fraction of edges assigned to each type in
    // the expectation phase as a maximum likelihood estimate of that
    // edge type's prior probability for the next EM round".
    update_em_mutation_probabilities(em_mutation_prob, edge_count);

    if (VERBOSE) {
      // Output normalized vector of mutation probabilities for EM.
      cout << "Mutation types and probabilities by EM round #" << em_rounds <<
        " =" << endl;
      output_mutation_probabilities(em_mutation_prob, name_chr, name_gene);
    }

    // Set edge weight for branching as node frequency times edge
    // probability
    // In "2.3. Optimal tree inference", "Once we have ensured that
    // every node of G is reachable, we add a weight function
    // w(v,u) = f_v p(u,v) to G".
    ref_graph->set_edge_weight_probability(em_mutation_prob);
    ref_graph->take_log_of_weights_for_highweight_branching();

    // Perform branching to find maximum weight arborescence.
    // In "2.3. Optimal tree inference", "4: Find a minimum-cost
    // arborescence on G by the method of Chu and Liu".
    {
      graph *hw_tree = findHighWeightBranching(ref_graph, true);
      for (int index_outer = 0; index_outer < ref_tree->size; index_outer++)
      {
        for (int index_inner = 0; index_inner < ref_tree->size; index_inner++)
        {
          // Move the edge between trees.
          delete ref_tree->table_of_edges[index_outer][index_inner];

          ref_tree->table_of_edges[index_outer][index_inner] =
            hw_tree->table_of_edges[index_outer][index_inner];

          hw_tree->table_of_edges[index_outer][index_inner] = NULL;
        }
      }
      assignParents(ref_tree);
      hw_tree->list_of_nodes.clear();  // Because nodes are shared
      delete hw_tree;
    }
    ref_graph->set_edge_weight_probability(em_mutation_prob);
    ref_tree->set_edge_weight_probability(em_mutation_prob);

    if (VERBOSE) {
      // Output maximum weight arborescence in Newick tree format.
      cout << "Maximum weight arborescence in Newick tree format by EM round #"
        << em_rounds << " =" << endl;
      output_tree_in_newick_format(stdout, ref_tree);
      cout << endl;
    }

    // Check if the change between vectors of mutation probabilities
    // before and after each round of EM is lower than the pre-defined
    // constant real number.
    assert(em_rounds < 10000);
    count_moves += total_moves;
  }
  while (!convergence_test(em_mutation_prob, prior_mutation_prob, resid));

  if (VERBOSE) {
    cout << "Total EM rounds " << em_rounds << " " << count_moves << endl;
  }

  // Loop through every mutation type.
  for (int index = 0; index < MUTATION_TYPES; index++)
  {
    mutation_prob[index] = em_mutation_prob[index];
  }
  delete [] graph_edge_types;
  delete [] tree_edge_types;
  delete [] krow_weights;
  delete [] jcol_weights;
  delete [] weights;
}
