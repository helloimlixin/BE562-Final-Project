#ifndef PATIENT_DATA_H
#define PATIENT_DATA_H

#include <vector>
#include <list>
#include <map>
#include <string>

#include "fish.h"
#include "constants.h"

class patient_data {
private:
  void free_parts();

  // Disable copying of instances.
  // Copy operations could be defined, but the compiler-generated
  // defaults cannot be used (because they are unaware of allocated
  // arrays).
  patient_data(const patient_data & a);
  patient_data & operator=(const patient_data &);
public:
  typedef std::list<std::map<std::string,int> > list_counts_t;

  static const int max_terminals = MAX_TERMINALS;
  static const int max_probes = MAX_PROBES;

  static vec_names find_patient_files(const std::string & dir_name);
  static std::string basename(const std::string & path);

  // Total number of cell counts.
  int total_cells;

  // Number of given pairs of chromosome probes and gene probes.
  int number_of_pairs;

  // Copy numbers of each pair of chromosome probe and gene probe from
  // a data file for states as nodes.  In "2.3. Optimal tree
  // inference", "a matrix of cell counts S".
  int_matrix * cell_count;

  // List of symbol-to-count mappings nameparsed from patient data file.
  list_counts_t list_counts;

  // An array that holds the copy number counts of the given gene
  // probes
  int (*terminals)[max_probes];

  // Symbols of chromosome probes in file
  vec_names probe_chromosomes;

  enum { cell_counter_size = 300 };  // Constant size, why?
  // The cell count in the input data
  std::vector<int> cell_counter;

  // Total number of records in the patient file
  int total_record;

  std::vector<int> probes_on_same_chromosome;

  // Sets of genes on the same chromosomes.
  int tot_scg_sets;
  int **scg;

  patient_data();

  ~patient_data();

  // Parse a patient data file to record pairs of chromosomes/ploidies and
  // gene probes and their indices, number of cell types and cells, and
  // input cell counts.
  void parse_file(vec_names & name_chr, vec_names & name_gene,
                  const std::string & filepath);
};


#endif
