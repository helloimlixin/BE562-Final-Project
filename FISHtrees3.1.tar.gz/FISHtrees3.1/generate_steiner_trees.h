/*
 * File:   generate_steiner_trees.h
 * Author: Salim
 *
 * Created on October 26, 2011, 7:02 PM
 */
#ifndef GENERATE_STEINER_TREES_H
#define	GENERATE_STEINER_TREES_H

#include "graph.h"
#include "constants.h"
#include "fish.h"

int prune_identical_cells(int [][MAX_PROBES], int , int, std::vector<int> &);

int generate_candidate(int [], int [][MAX_PROBES], int [][MAX_PROBES],
                       int, int, std::vector<unsigned int> & );
graph *
convert_to_joint_tree(int **, int **, int , int, int, const vec_names &,
                      const std::vector<int> & ,int, int, int**, int*);

void print_graph_with_list(const std::list<graph *> &, int[]);

void print_graph(graph *);

graph *
generate_steiner_trees(int, const vec_names &, int [][MAX_PROBES],
                       std::vector<int> &, int , int, int, int**, int*);

int sort_nodes(int **, int **, int , int, std::vector<int> & );

void convert_to_directed_tree(int **, int , int );

int delete_redundant_steiner_nodes(int **, int **, int , int , int );

void check_and_reorganize(int **,int **, int , int, int, int, int**, int* );

int myPow(int , int );

#endif	/* GENERATE_STEINER_TREES_H */
