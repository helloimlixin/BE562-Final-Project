#include <iostream>

#include <cstring>
#include <cstdlib>
#include <cmath>
#include <cassert>

#include "fish.h"
#include "calculate_pairwise_distance.h"

//AAS: Can this upper limit be defined at run time as a function of total_cells?
//or can the arrays be expanded dynamically?
#define MAX_TOT_NODES 8000

//Initial upper bound on distance between source and destination
#define LARGE_DISTANCE 1000

#define GAIN_DIRECTION 1
#define LOSS_DIRECTION 2

using namespace std;

void check_num_nodes(int num_nodes)
{
  if (num_nodes >= MAX_TOT_NODES) {
    cerr << "\nIn procedure calculate_pairwise_distance, the number of nodes " << num_nodes << " equals or exceeds " << MAX_TOT_NODES <<  "; need to increase MAX_TOT_NODES in calculcate_pairwise_distance.cpp" << endl;
    exit(EXIT_FAILURE);
  }
}

//Returns the shortest distance between two points when single gene gain
//loss(l1), chromosomde duplicatin(CD) and genome duplication(GD) is taken into account.
//src and dest are the two copy number profiles between which distance is calculated
//probes is the total number of probes listed by the user
// tot_scg_sets is number of sets of probes on the same chromosome
// scg is a matrix indicating which probes go together on the same chromosome
// probes_on_chromosome[i] indicates how many probes are on the same chromosome as probe i
int calculate_pairwise_distance(int src[],int dest[],int probes, int tot_scg_sets, int **scg, int *probes_on_chromosome)
{

  //d_cum[i] stores the cumulative distance to the destination
  //from node indexed by i.
  //pred[i] stores the index of the predecessor node of node i.
  vector<int> d_cum(MAX_TOT_NODES);
  //int pred[MAX_TOT_NODES];

  //node_id stores the copy number profile of each node. Each copy
  //number profile is addressed by it's row index in the node_id array.
  int **node_id = new int*[MAX_TOT_NODES];

  for(int i = 0; i < MAX_TOT_NODES; ++i) {
    node_id[i] = new int[probes];
  }

  //copy dest and src in the node_id array.
  for(int i =0;i<probes;i++){
    node_id[1][i] = dest[i];
    node_id[2][i] = src[i];
  }

  //The following portion is hard coded, but will be supplied to this function
  //by the calling function later........

  //Stores total same chromosome gene sets
  //int tot_scg_sets = 2;
  //2D array for storing same chromosome gene sets.
  //Each row represents a set of genes located on the same chromosome
  //First entry in each row represents how many genes are located on that chromosome
  //The next entries store the probe id of the genes
  // int **scg = new int*[tot_scg_sets];

  // for(int i = 0; i < tot_scg_sets; ++i) {
  //  scg[i] = new int[probes];
  //}
  //Initialize scg for breast cancer dataset ...
  //scg[0][0] = 2;
  //scg[0][1] = 1;
  //scg[0][2] = 2;
  //scg[1][0] = 2;
  //scg[1][1] = 5;
  //scg[1][2] = 6;


  //prev_nei stores the copy number profiles of the neighbor nodes of the
  //odd configuratin nodes generated in the previous stage.
  vector<vector<int> > prev_nei;
  prev_nei.resize(MAX_TOT_NODES);
  for (int i = 0; i < MAX_TOT_NODES; ++i){
    prev_nei[i].resize(probes);
  }

  //prev stores the index of the nodes generated in the previous stage.
  vector<int> prev(MAX_TOT_NODES);
  //dest is the fixed as the starting node.
  prev[1] = 1;

  //prev_length stores how many nodes have been generated in the previous step.
  int prev_length = 1;

  //tot_nodes is the counter that stores how many total nodes have been generated so far.
  int tot_nodes = 2;

  //cumulative distance of dest to dest is assigned 0 and cumulative distance for src
  //is initialized to a large number.
  d_cum[1] = 0;
  d_cum[2] = LARGE_DISTANCE;

  //src_neighbor stores the node index of the current nearest neighbor of src.
  //int src_neighbor = 0;
  //predecessor of src and dest is assigned to 0 or null.
  // pred[1] = 0;
  // pred[2] = 0;

  //cur stores the index of the nodes generated at the current stage.
  vector<int> cur(LARGE_DISTANCE,0);
  //cur_total counts the total number of nodes generated at the current stage.
  int cur_total = 0;
  //prev_conf stores the copy number profile of a particular node generated in the previous stage.
  vector<int> prev_conf(probes);
  //even stores 1 if the copy number profile of a node is even and 0 otherwise.
  int even;
  //stores the half of all probes copy number values of a node with even configuration.
  vector<int> prev_half(probes);
  //temporary variable to store the calculated distance.
  int temp_d;
  //stores the distance between two nodes.
  int dist;
  //stores the result of a node search into an array of nodes.
  int res;
  //tot_prev_neighbor stores the total number of neighbor nodes of an odd configuration node.
  int tot_prev_neighbor = 0;
  //temporary storages to hold the neighboring copy number profile of a node.
  vector<int> temp_n(probes);
  //temporary storages to hold the half of neighboring copy number profile of a node.
  vector<int> temp_n_half(probes);

  while(1){
    cur_total = 0;

    //loop through each node generated in the previous stage.
    for (int i=1;i<=prev_length;i++){

      //store the copy number profile of the i'th previous node in prev_conf.
      for (int j = 0; j < probes; j++)
        prev_conf[j] = node_id[prev[i]][j];

      //test if prev_conf has an even configuration or and odd one.
      even = is_even_state(&prev_conf[0],probes);

      //even == 1 means the configuration is even.
      if(even == 1){

        //first take half of prev_conf and store it in prev_half.
        for (int j = 0; j < probes; j++)
          prev_half[j] = prev_conf[j]/2;

        //test if l1+CD distance between prev_half and src is 0.
        if(l1_CD(&prev_half[0],src,scg,tot_scg_sets,probes) == 0){

          //if it is 0, then calculate the distance from src to prev_conf.
          temp_d = d_cum[prev[i]] + 1;

          //if the distance is less than the nearest neighbor of src, then
          //make the current node the nearest neighbor and update the distance
          //and src_neighbor parameter.
          if (d_cum[2] > temp_d){
            d_cum[2] = temp_d;
            //src_neighbor = prev[i];
          }
        }

        //test if the l1+CD distance between src and prev_conf is shorter than
        //the l1+CD distance between src and prev_half.
        else if(l1_CD(src,&prev_conf[0],scg,tot_scg_sets,probes) <= (l1_CD(src,&prev_half[0],scg,tot_scg_sets,probes) + 1)){

          //l1+CD distance between src and prev_conf.
          dist = l1_CD(src,&prev_conf[0],scg,tot_scg_sets,probes);

          //cumulative distance from src to dest using prev_conf as immediate neighbor.
          temp_d = d_cum[prev[i]] + dist;

          //if the distance is less than the nearest neighbor of src, then
          //make prev_conf the nearest neighbor and update the distance
          //and src_neighbor parameter.
          if (d_cum[2] > temp_d){
            d_cum[2] = temp_d;
            //src_neighbor = prev[i];
          }
        }

        //if the two l1+CD tests fail, then prev_half is a candidate for a new node
        else{

          //first search if the candidate node has already been generated or not
          res = member(node_id,&prev_half[0],tot_nodes,probes);

          if(res == 0){

            //if the candidate node is a new one, then store its copy number profile.
            //increase the total node counter.
            tot_nodes = tot_nodes + 1;
            check_num_nodes(tot_nodes);

            //store the copy number profile in the node_id array.
            for(int j=0; j<probes; j++)
              node_id[tot_nodes][j] = prev_half[j];

            //calculate the cumulative distance of the new node to dest.
            d_cum[tot_nodes] = d_cum[prev[i]] + 1;

            //set predecessor of the new node to index of prev_conf
            //pred[tot_nodes] = prev[i];

            //increment the cur_total parameter store the index of the new
            //node in currently generated array
            cur_total += 1;
            cur[cur_total] = tot_nodes;
          }
          else{

            //if the candidate node has already been generated, then check if its cumulative
            //distance to dest can be reduced using the new path
            if(d_cum[res] > (d_cum[prev[i]] + 1)){

              //if so, then update d_cum and set its predecessor to prev_conf
              d_cum[res] = d_cum[prev[i]] + 1;
              //pred[res] = prev[i];
            }
          }

        }

      } // end of if(even == 1)


      //prev_conf has an odd configuration
      else{
        //generate the immediate neighbor nodes of prev_conf and store
        //the node indices in prev_nei
        gen_neighbor(prev_nei,&prev_conf[0],probes, probes_on_chromosome, tot_prev_neighbor);

        //loop through each neighbor of prev_conf
        for(int i2 = 0; i2 < tot_prev_neighbor;i2++){

          // Perform 2 L1+CD tests
          // First test to see if we need a neighbor or not
          //store the copy number profile of the current neighbor in temp_n
          for (int j = 0; j < probes; j++)
            temp_n[j] = prev_nei[i2][j];

          //store the half of the copy number profile of the current neighbor in temp_n_half

          for (int j = 0; j < probes; j++)
            temp_n_half[j] = temp_n[j]/2;


          //test if the l1+CD distance between src and temp_n_half is 0.
          if(l1_CD(src,&temp_n_half[0],scg,tot_scg_sets,probes) == 0){

            //temp_n becomes the new node. increase the tot_nodes counter and store the
            //new node's copy number profile in node_id.
            tot_nodes = tot_nodes + 1;
            check_num_nodes(tot_nodes);
            for (int j = 0; j < probes; j++)
              node_id[tot_nodes][j] = temp_n[j];

            //set predecessor of the new node to index of prev_conf and
            //calculate it's cumulative distance to the root.
            //pred[tot_nodes] = prev[i];
            d_cum[tot_nodes] = d_cum[prev[i]] + l1_CD(&prev_conf[0],&temp_n[0],scg,tot_scg_sets,probes);

            //cumulative distance from src to dest using temp_n as immediate neighbor.
            temp_d = d_cum[tot_nodes] + 1;

            //if the distance is less than the nearest neighbor of src, then
            //make the new node the nearest neighbor and update the distance
            //and src_neighbor parameter.
            if (d_cum[2] > temp_d){
              d_cum[2] = temp_d;
              //src_neighbor = tot_nodes;
            }
          }

          //this test determines if temp_n and temp_n_half is needed at all.
          else if(l1_CD(src,&prev_conf[0],scg,tot_scg_sets,probes) <= (l1_CD(&prev_conf[0],&temp_n[0],scg,tot_scg_sets,probes) + 1 + l1_CD(src,&temp_n_half[0],scg,tot_scg_sets,probes))){

            //l1+CD distance between src and prev_conf.
            dist = l1_CD(src,&prev_conf[0],scg,tot_scg_sets,probes);

            //cumulative distance from src to dest using prev_conf as immediate neighbor.
            temp_d = d_cum[prev[i]] + dist;

            //if the distance is less than the nearest neighbor of src, then
            //make prev_conf the nearest neighbor and update the distance
            //and src_neighbor parameter.
            if (d_cum[2] > temp_d){
              d_cum[2] = temp_d;
              //src_neighbor = prev[i];
            }

          }

          //this test determines if temp_n_half is needed or not.
          else if(l1_CD(src,&temp_n[0],scg,tot_scg_sets,probes) <= (l1_CD(src,&temp_n_half[0],scg,tot_scg_sets,probes) + 1)){

            //l1+CD distance between src and temp_n.
            dist = l1_CD(src,&temp_n[0],scg,tot_scg_sets,probes);

            //check if temp_n has already been generated or not.
            res = member(node_id,&temp_n[0],tot_nodes,probes);

            //res=0 means temp_n was not generated previously
            if(res == 0){

              //create temp_n as a new node,increase tot_nodes counter.
              tot_nodes = tot_nodes + 1;
              check_num_nodes(tot_nodes);

              //store temp_n's copy number profile in node_id.
              for (int j = 0; j < probes; j++)
                node_id[tot_nodes][j] = temp_n[j];

              //calculate temp_n's cumulative distance to dest.
              d_cum[tot_nodes] = d_cum[prev[i]] + l1_CD(&prev_conf[0],&temp_n[0],scg,tot_scg_sets,probes);

              //cumulative distance from src to dest using temp_n as immediate neighbor.
              temp_d = d_cum[tot_nodes] + dist;

              //set predecessor of the new node to index of prev_conf.
              //pred[tot_nodes] = prev[i];

            }

            else{
              //if temp_n has already been generated, then check if its cumulative
              //distance to dest can be reduced using the new path.

              if(d_cum[res] > (d_cum[prev[i]] + l1_CD(&temp_n[0],&prev_conf[0],scg,tot_scg_sets,probes))){

                //if so, then update d_cum and set its predecessor to prev_conf.
                d_cum[res] = d_cum[prev[i]] + l1_CD(&temp_n[0],&prev_conf[0],scg,tot_scg_sets,probes);
                //pred[res] = prev[i];
              }
              //cumulative distance from src to dest using temp_n as immediate neighbor.
              temp_d = d_cum[res] + dist;
            }



            //if the distance is less than the nearest neighbor of src, then
            //make temp_n the nearest neighbor and update the distance
            //and src_neighbor parameter.
            if (d_cum[2] > temp_d){
              d_cum[2] = temp_d;
              // if(res==0)
              //   src_neighbor = tot_nodes;
              // else
              //       src_neighbor = res;
            }



          }
          //if the above three tests fail, then make temp_n and temp_n_half the candidate new nodes.
          else{
            //check if temp_n has already been generated or not.
            res = member(node_id,&temp_n[0],tot_nodes,probes);
            //res=0 means temp_n was not generated previously
            if(res == 0){
              //increment the tot_node counter and store temp_n's copy number profile in node_id.
              tot_nodes = tot_nodes + 1;
              check_num_nodes(tot_nodes);
              for (int j = 0; j < probes; j++)
                node_id[tot_nodes][j] = temp_n[j];


              //set predecessor of the new node to index of prev_conf.
              //pred[tot_nodes] = prev[i];

              //calculate temp_n's cumulative distance to dest.
              d_cum[tot_nodes] = d_cum[prev[i]] + l1_CD(&temp_n[0],&prev_conf[0],scg,tot_scg_sets,probes);

            }

            else{

              //if temp_n has already been generated, then check if its cumulative
              //distance to dest can be reduced using the new path.

              if(d_cum[res] > (d_cum[prev[i]] + l1_CD(&temp_n[0],&prev_conf[0],scg,tot_scg_sets,probes))){

                //if so, then update d_cum and set its predecessor to prev_conf.
                d_cum[res] = d_cum[prev[i]] + l1_CD(&temp_n[0],&prev_conf[0],scg,tot_scg_sets,probes);
                //pred[res] = prev[i];
              }
            }

            //check if temp_n_half has already been generated or not.
            res = member(node_id,&temp_n_half[0],tot_nodes,probes);

            //res=0 means temp_n_half was not generated previously
            if(res == 0){

              //increment the tot_node counter and store temp_n_half's copy numebr profile in node_id.
              tot_nodes = tot_nodes + 1;
              check_num_nodes(tot_nodes);

              for (int j = 0; j < probes; j++)
                node_id[tot_nodes][j] = temp_n_half[j];

              //set predecessor of the new node to index of temp_n.
              //pred[tot_nodes] = tot_nodes-1;

              //calculate temp_n_half's cumulative distance to dest.
              d_cum[tot_nodes] = d_cum[tot_nodes-1] + 1;

              //increment cur_total counter and store temp_n_half's node index in
              //the currently generated node array
              cur_total += 1;
              cur[cur_total] = tot_nodes;

            }
            else{
              //if temp_n_half has already been generated, then check if its cumulative
              //distance to dest can be reduced using the new path.
              if(d_cum[res] > (d_cum[tot_nodes-1] + 1)){

                //if so, then update d_cum and set its predecessor to temp_n.
                d_cum[res] = d_cum[tot_nodes-1] + 1;
                //pred[res] = tot_nodes-1;
              }
            }

          }  // end of if


        }  // end of for(int i2 = 1; i2 <= pn_l,i2++)


      } // end of else (prev is odd)

    } // end of for (int i=1;i<=prev_length;i++){

    //store the nodes generated in the current iteration into the prev array to use
    //in the next iteration.
    for(int j = 1; j<= cur_total; j++)
      prev[j] = cur[j];
    prev_length = cur_total;


    //if no new node is generated in the current iteration then stop
    if(cur_total == 0)
      break;
  } // end of while(1)

  // free the allocated memory for node_id
  for (int i=0; i<MAX_TOT_NODES; i++)
    delete [] node_id[i];
  delete [] node_id;

  //return the cumulative distance of the src to dest as the shortest one

  return d_cum[2];


} // end of get_min_dist function



//Determines if a copy number profile is even or odd
//node stores the copy number profile
//returns 1 if the prfile is even and 0 otherwise
//probes is the total number of probes listed by the user
int is_even_state(int node[],int probes){
  int even = 1; // value to return

  //checks if copy number of each probe even or not.
  //if one or more probe have odd copy number, then the whole
  //profile is declared as odd. Otherwise it is even.
  for(int i=0; i<probes;i++){
    if((node[i]%2) > 0){
      even = 0;
      break;
    }
  }
  return even;
}

//Generate the neighbors of a node with odd copy number profile
//neighbors stores the copy number profiles of the generated neighbor nodes
//node stores the copy number profile of the node whose neighbors are calculated
//counter stores the total number of neighbors generated
// probes_on_chromosome[i] indicates how many probes are on the same chromosome as probe i
//neighbors and counter are passed by reference
void gen_neighbor(vector<vector<int> > &neighbors,int node[],int probes, int *probes_on_chromosome,  int& counter){

  //stores the number of candidate values for each probe that are within 1, or within 2 away
  vector<int> num_within1_candidates(probes);
  vector<int> num_all_candidates(probes);

  //candidate values for a neighbor node
  vector<int> cand_neighbor(probes);

  //indices of either within1_candidates or all_candidates while enumerating all possible combinations
  vector<int> cindex(probes);

  //stores the two neighboring copy numbers of a probe that are either within 1 or within 2.
  // there at most two candidates for odd nodes, by doing -1 and +1
  // there at most three candidates for even nodes, by doing +0, -2 and +2
  vector<vector<int> > within1_candidates(probes, vector<int>(2));
  vector<vector<int> > all_candidates(probes, vector<int>(3));;

  //do there exist candidates where at least one probe count differs by more than 1?
  bool exist_far_candidates = false;

  //used within two do-while loops that enumerate all candidates
  bool found_more_candidates = false;

  //does this candidate node differ from nodes by at least 2 on one probe count?
  bool is_far_neighbor = false;

  //upper bound on number of neighbors
  int neighbor_number_upper_bound;

  //initialize counter to 0
  counter = 0;

  for(int i = 0; i <probes; i++){
    num_within1_candidates[i] = 0;
    num_all_candidates[i] = 0;
    if((node[i] % 2) > 0){ // copy number is odd
      within1_candidates[i][0] = node[i] -1;
      num_within1_candidates[i]++;
      all_candidates[i][0] = node[i] -1;
      num_all_candidates[i]++;
      if (node[i] < MAX_COPY) {
        within1_candidates[i][1] = node[i]+1;
        num_within1_candidates[i]++;
        all_candidates[i][1] = node[i]+1;
        num_all_candidates[i]++;
      }
    }
    else { //copy number is even
      within1_candidates[i][0] = node[i];
      num_within1_candidates[i]++;
      all_candidates[i][0] = node[i];
      num_all_candidates[i]++;
      if (probes_on_chromosome[i] > 1) {
        if (node[i] > 0) {
          all_candidates[i][num_all_candidates[i]] = node[i] - 2;
          num_all_candidates[i] ++;
          exist_far_candidates = true;
        }
        if ((node[i] + 2) <= MAX_COPY) {
          all_candidates[i][num_all_candidates[i]] = node[i] + 2;
          num_all_candidates[i] ++;
          exist_far_candidates = true;
        }
      }
    }
  }

  neighbor_number_upper_bound = 1;
  for(int i = 0; i < probes; i++) {
    neighbor_number_upper_bound *= num_all_candidates[i];
  }
  if (neighbor_number_upper_bound >= MAX_TOT_NODES) {
    cerr << "\nIn procedure gen_neighbor, the number of neighbors " << neighbor_number_upper_bound << " exceeds " << MAX_TOT_NODES <<  "; need to increase MAX_TOT_NODES in calculcate_pairwise_distance.cpp" << endl;
    exit(EXIT_FAILURE);
  }



  for(int i = 0; i < probes; i++) {
    cand_neighbor[i] = 0;
    cindex[i] = 0;
  }

  do {
    //put in new neighbor here
    for(int i = 0; i < probes; i++) {
      cand_neighbor[i] = within1_candidates[i][cindex[i]];
      neighbors[counter][i] = cand_neighbor[i];
    }
    counter = counter+1;
    found_more_candidates = false;
    for (int j = (probes - 1); j >= 0; j--) {
      if ((cindex[j] + 1) < num_within1_candidates[j]) {
        cindex[j] = cindex[j] + 1;
        found_more_candidates = true;
        //reset counters for higher indices than j to 0
        for (int k = j+1; k < probes; k++) {
          cindex[k] = 0;
        }
        break; // out of for loop with new candidate
      }
    }
  } while (found_more_candidates);

  if (exist_far_candidates) {

    for(int i = 0; i < probes; i++) {
      cand_neighbor[i] = 0;
      cindex[i] = 0;
    }

    do {
      //test possible new neighbor here
      is_far_neighbor = false;
      for(int i = 0; i < probes; i++) {
        cand_neighbor[i] = all_candidates[i][cindex[i]];
        if (1 < abs(cand_neighbor[i] - node[i]))
          is_far_neighbor = true;
      }
      if (is_far_neighbor) {
        for(int i = 0; i < probes; i++) {
          neighbors[counter][i] = cand_neighbor[i];
        }
        counter = counter+1;
      }

      found_more_candidates = false;
      for (int j = (probes - 1); j >= 0; j--) {
        if ((cindex[j] + 1) < num_all_candidates[j]) {
          cindex[j] = cindex[j] + 1;
          found_more_candidates = true;
          //reset counters for higher indices than j to 0
          for (int k = j+1; k < probes; k++) {
            cindex[k] = 0;
          }
          break; // out of for loop with new candidate
        }
      }
    } while (found_more_candidates);
  } //if(exist_far_candidates
} // end of gen_neighbor function

//calculates distance between two vectors when CD and SD operations are considered
//src and dest are the two copy number profiles between which
//distance is calculated
//scg stores the index of the probes located on the same chromosomes
//tot_scg_sets stores the number of sets of genes located on the same chromosomes
//probes is the total number of probes listed by the user
int l1_CD(int src[],int dest[],int* scg[],int tot_scg_sets,int probes){

  //dist stores the resulting distance value
  int dist = 0;

  //total number of same chromosome genes
  int tot_scg = 0;

  //stores the same chromosome genes linearly in a one dimensional array
  vector<int> scg_set(probes);

  //loop through each gene set and copy them to scg_set
  for(int i=0; i<tot_scg_sets; i++){
    for(int j=1; j<=scg[i][0]; j++){
      scg_set[tot_scg] = scg[i][j];
      tot_scg = tot_scg + 1;
    }
  }

  //Indicator to check if a gene belongs to scg_set
  int skip = 0;

  //loop through each probe and calculate the absolute
  //difference between the copy numbers of src and dest
  //for that probe if it is not one of the same chromosome genes
  for(int i = 0; i<probes; i++){
    skip = 0;
    for(int j = 0; j<tot_scg;j++){
      if(i==scg_set[j]){
        skip = 1;
        break;
      }
    }
    if(skip == 0)
      dist = dist + abs(src[i]-dest[i]);
  }

  //Store src and dest configurations for each set of same chromosome genes
  vector<int> sc_src(probes);
  vector<int> sc_dest(probes);

  //Loop through each set of same chromosome genes and calculate the distance
  //between src and dest considering SD and CD operations.
  for(int i=0; i<tot_scg_sets; i++){
    for(int j=1; j<=scg[i][0]; j++){
      sc_src[j-1] = src[scg[i][j]];
      sc_dest[j-1] = dest[scg[i][j]];
    }
    dist = dist + dist_chromosome_doubling(&sc_src[0],&sc_dest[0],scg[i][0]);
  }

  return dist;
}

//search through a list of nodes to identify if a particular node is a member of the set or not.
//nodes stores the copy number profiles of a set of nodes.
//x stores the copy number profile of a node which is searched in nodes.
//tot_nodes stores the total number of nodes in nodes array
//probes is the total number of probes listed by the user
int member(int** nodes,int x[],int tot_nodes,int probes){
  //res stores the result of the search. 0 means x is not found, greater
  //than 0 means x is present in the array
  int res = 0;

  //loop through each entry in nodes and identify if it has a matching
  //copy number profile with x
  for(int i = 1; i <= tot_nodes; i++){
    if(l1(nodes[i],x,probes) == 0){
      res = i;
      break;
    }

  }
  return res;

}

//calculates distance between two vectors taking into account single
//gene duplication (SD) and chromosome duplication(CD) events
//src and dest are the two copy number profiles between which
//distance is calculated
//probes is the total number of probes listed by the user
int dist_chromosome_doubling(int src[],int dest[],int probes){

  //lower and upper bound of each gene probe
  int lb = 0;
  int ub = MAX_COPY;

  //l1 distance between src and dest
  int l1_dist = l1(src,dest,probes);

  //CL keeps count of CD operations
  int CL = 0;
  //gain_loss stores the gain and loss count of each
  //gene after the boundary-insensitive optimization is performed
  //First column stores the gain counters and second column stores the loss counters
  vector<vector<int> > gain_loss(probes, vector<int>(2));

  //initialize gain_loss array
  for(int i=0; i<probes; i++)
    for(int j=0; j<2;j++)
      gain_loss[i][j] = 0;

  //chromosomal gain/loss direction.dir=GAIN_DIRECTION means gain, LOSS_DIRECTION=loss.
  int dir = GAIN_DIRECTION;

  //temporary vector for holding the copy number profiles after
  //CD operation is performed
  vector<int> t_src(probes);

  //First we perform a whole chromosome gain operation
  for(int i=0; i < probes;i++)
    t_src[i] = src[i] + 1;


  //Calculates l1 distance between dest and t_src
  int g_dist = l1(dest,&t_src[0],probes); //gain chromosome l1 dist

  //Next we perform a whole chromosome loss operation
  for(int i=0; i < probes;i++)
    t_src[i] = src[i] - 1;


  //Calculates l1 distance between dest and t_src
  int l_dist = l1(dest,&t_src[0],probes);

  //If l1 distance between src and dest is lower than the l1 distance
  //between the intermediate configurations and dest after chromosome
  //gain and loss operations are performed, then no CD operation is needed
  //to be introduced.
  if((l1_dist <= g_dist) && (l1_dist <= l_dist)){
    return l1_dist;
  }

  //Check if the CD operation should be loss instead
  if(l_dist < g_dist)
    dir = LOSS_DIRECTION;

  //stores sequence of CD and SD operations in codewords for the boundary-insensitive optimization
  /*AAS: Constant 100 here; seems like s should be a resizeable array*/
  //int S[100] = {0};
  //keeps a count of CD and SD operations performed so far
  int S_counter = 0;
  //Stores intermediate configurations during the progress of the algorithm
  vector<int> intermediate(probes);

  //Initialize intermediate to src
  for(int i=0; i < probes;i++)
    intermediate[i] =src[i];

  //Stores distance between intermediate and destination after the previous operation
  int prev_d = l1_dist;

  //Temporary intermediate configuration holder
  // I would avoid "int" as part of a variable name, since int is a keyword
  vector<int> t_int(probes);

  //Temporary distance holder
  int t_dist = 0;

  //First we perform the CD operation as long as the l1 distance between
  //intermediate and dest is decreased
  while(1){

    //Perform a CD operation based on dir and store the result in t_int
    if(dir == 1){
      for(int i=0; i < probes;i++)
        t_int[i] = intermediate[i] + 1;
    }
    else{
      for(int i=0; i < probes;i++)
        t_int[i] = intermediate[i] - 1;
    }

    //Calculate l1 distance between t_int and dest
    t_dist = l1(&t_int[0],dest,probes);

    //If l1 distance is not decreased as a result of CD operation, then stop
    if(t_dist >= prev_d)
      break;
    else{
      //Otherwise, t_int becomes the new intermediate node
      prev_d = t_dist;
      for(int i=0; i < probes;i++)
        intermediate[i] = t_int[i];

      //Number of CD operations is increased
      CL = CL + 1;
      //Store the CD event. Codeword 100 means a chromosome gain event and 200 means
      //a chromosome loss event
      /*AAS: Constant 100 here*/
      //S[S_counter] = dir*100;
      S_counter = S_counter + 1;
    }


  } //end of while(1).. CD event

    //Individual gene gain loss direction indicator
  int g_dir;

  //Loop through each probe
  for(int i=0; i < probes; i++){

    //g_dir = 1 means gain operation is needed for this gene
    g_dir = GAIN_DIRECTION;

    //Check if loss operation should be performed instead
    if(intermediate[i] > dest[i])
      g_dir = LOSS_DIRECTION;

    //Diff represents how many SD operations are needed
    int diff = abs(intermediate[i] - dest[i]);

    //Do nothing if no SD operation is needed
    if(diff == 0)
      continue;

    //Peforms the required SD operations one after another
    for(int j=0; j< diff;j++){
      //Stores the 2 digit gain loss code for that gene. First digit
      //is gene index(ranges from 1 to probes) and second digit is gain/loss direction
      /*AAS: Constant 10 here*/
      //S[S_counter] = (i+1)*10 + g_dir;
      S_counter = S_counter + 1;

      //increase relevant gain loss counters
      gain_loss[i][g_dir-1] = gain_loss[i][g_dir-1] + 1;

    }

  }

  //Calculated distance between the two configurations when SD and CD operations are performed
  int final_dist = S_counter;

  //Now the re-ordering phase so that the lower and upper bound of each gene is considered
  //S_prime stores sequence of CD and SD operations in codewords for the boundary-sensitive optimization
  assert(S_counter>0);
  //int S_prime[S_counter];

  //keeps a count of CD and SD operations performed so far for S_prime
  int S_prime_counter = 0;

  //intermediate vector is reset to src
  for(int i=0; i < probes;i++)
    intermediate[i] =src[i];

  //gain loss direction of each gene in this phase is opposite to CD operation direction
  g_dir = GAIN_DIRECTION;
  if(dir == 1)
    g_dir = LOSS_DIRECTION;

  //Stores the set of genes that will be considered for gain and loss operations in the
  //next steps of the program
  vector<int> cand_genes(probes);
  int cand_gene_counter;
  int gene;

  //Interleave the CD and relevant SD operations so that boundary of each gene is respected
  while(1){
    if(CL == 0)
      break;

    cand_gene_counter = 0;
    //First identify which genes can be selected for gain or loss operations based
    //on chromosome gain loss direction.
    for(int i=0; i<probes; i++){
      if(gain_loss[i][g_dir-1] > 0){
        cand_genes[cand_gene_counter] = i;
        cand_gene_counter = cand_gene_counter + 1;
      }
    }
    //If no such gene is selected, then stop
    if(cand_gene_counter == 0)
      break;

    //Loop through each selected gene
    for(int i=0; i<cand_gene_counter; i++){

      //Gene index for the next selected gene
      gene = cand_genes[i];

      //If the CD operation was chromosome loss, then increase the copy number
      //of the selected genes by one.
      if(dir == LOSS_DIRECTION){

        //First check if gain operation of the gene is possible or not
        if(intermediate[gene] < ub){

          //If possible, then increase its copy number by one, decrease the gain
          //loss counter and store the operation in S_prime using the codeword.
          intermediate[gene] = intermediate[gene] + 1;
          gain_loss[gene][g_dir-1] = gain_loss[gene][g_dir-1] - 1;
          /*AAS: Constant 10 here*/
          //S_prime[S_prime_counter] = (gene+1)*10 + 1;
          S_prime_counter = S_prime_counter + 1;
        }
      }

      //If the CD operation was a chromosome gain, then decrease the copy number
      //of the selected genes by one.
      else{

        //First check if loss operation on the gene is possible or not
        if(intermediate[gene] > lb){

          //If possible, then decrease its copy number by one, decrease the gain
          //loss counter and store the operation in S_prime using the codeword.
          intermediate[gene] = intermediate[gene] - 1;
          gain_loss[gene][g_dir-1] = gain_loss[gene][g_dir-1] - 1;
          /*AAS: Constant 10 here*/
          // S_prime[S_prime_counter] = (gene+1)*10 + 2; //2 digit gain loss code for that gene
          S_prime_counter = S_prime_counter + 1;
        }
      }


    } // end for

    //Now perform the CD operation based on "dir" variable and update the copy number profile
    //of the intermediate configuration
    CL = CL - 1;
    if(dir == 1){
      for(int i=0; i< probes; i++)
        intermediate[i] = intermediate[i] + 1;
    }
    else{
      for(int i=0; i< probes; i++)
        intermediate[i] = intermediate[i] - 1;
    }

    //Store the CD operation in S_prime
    /*AAS: Constant 100 here*/
    //S_prime[S_prime_counter] = dir*100;
    S_prime_counter = S_prime_counter + 1;

  } // end while(1)

    //Now check if further CD or SD operations can be performed
    //Check if some CD operations are still left to be performed
  if(CL > 0){

    //Perform those CD operations one by one, update the copy
    //number profile of the intermediate configuration and store the operation in S_prime

    while(CL > 0){
      CL = CL - 1;
      if(dir == 1){
        for(int i=0; i<probes; i++)
          intermediate[i] = intermediate[i] + 1;
      }
      else{
        for(int i=0; i<probes; i++)
          intermediate[i] = intermediate[i] - 1;
      }
      /*AAS: Constant 100 here*/
      //S_prime[S_prime_counter] = dir*100;
      S_prime_counter = S_prime_counter + 1;
    }

  } //end if(CL>0)

    //Check if some SD operations are left instead
  else{

    //Perform those SD operations one by one
    while(1){

      cand_gene_counter = 0;

      //Select the genes on which SD operations will be performed
      for(int i=0; i<probes; i++){
        if(gain_loss[i][g_dir-1] > 0){
          cand_genes[cand_gene_counter] = i;
          cand_gene_counter = cand_gene_counter + 1;
        }
      }

      //If no gene left, then stop
      if(cand_gene_counter == 0)
        break;

      //Loop through each selected gene
      for(int i=0; i<cand_gene_counter; i++){

        //Gene index for the next selected gene
        gene = cand_genes[i];

        //If the CD operation was chromosome loss, then increase the copy number
        //of the selected gene by one if it is less than ub and store the operation
        //in S_prime
        if(dir == LOSS_DIRECTION){
          if(intermediate[gene] < ub){
            intermediate[gene] = intermediate[gene] + 1;
            gain_loss[gene][g_dir-1] = gain_loss[gene][g_dir-1] - 1;
            //S_prime[S_prime_counter] = (gene+1)*10 + 1;
            S_prime_counter = S_prime_counter + 1;
          }
        }

        //If the CD operation was chromosome gain, then decrease the copy number
        //of the selected gene by one if it is greater than lb and store the operation
        //in S_prime
        else{
          if(intermediate[gene] > lb){
            intermediate[gene] = intermediate[gene] - 1;
            gain_loss[gene][g_dir-1] = gain_loss[gene][g_dir-1] - 1;
            //S_prime[S_prime_counter] = (gene+1)*10 + 2;
            S_prime_counter = S_prime_counter + 1;
          }
        }


      } // end for

    }//end while(1)

  } //end else part of if(CL>0)

    //Now, we take care of the gene gain or loss operations that have not been
    //considered in the previous step. These operations have same direction as
    //the chromosome gain or loss direction
  while(1){

    cand_gene_counter = 0;

    //Select the genes on which SD operations will be performed
    for(int i=0; i<probes; i++){
      if(gain_loss[i][dir-1] > 0){
        cand_genes[cand_gene_counter] = i;
        cand_gene_counter = cand_gene_counter + 1;
      }
    }

    //If no gene left, then stop
    if(cand_gene_counter == 0)
      break;

    //Loop through each selected gene
    for(int i=0; i<cand_gene_counter; i++){

      //Loop through each selected gene
      gene = cand_genes[i];

      //If the CD operation was chromosome gain, then increase the copy number
      //of the selected gene by one and store the operation in S_prime
      /*AAS: Constant 1 here*/
      if(dir == GAIN_DIRECTION){

        intermediate[gene] = intermediate[gene] + 1;
        gain_loss[gene][dir-1] = gain_loss[gene][dir-1] - 1;
        //S_prime[S_prime_counter] = (gene+1)*10 + 1; //2 digit gain loss code for that gene
        S_prime_counter = S_prime_counter + 1;

      }
      //If the CD operation was chromosome loss, then decrease the copy number
      //of the selected gene by one and store the operation in S_prime
      else{

        intermediate[gene] = intermediate[gene] - 1;
        gain_loss[gene][dir-1] = gain_loss[gene][dir-1] - 1;
        //S_prime[S_prime_counter] = (gene+1)*10 + 2; //2 digit gain loss code for that gene
        S_prime_counter = S_prime_counter + 1;

      }


    } // end for

  } //end of while(1)

    //Returns the total distance between src and dest
  return final_dist;
}

//calculates rectilinear distance between two vectors
//src and dest are the two copy number profiles between which
//distance is calculated
//probes is the total number of probes listed by the user
int l1(int src[],int dest[],int probes){

  //dist stores the resulting distance value
  int dist = 0;
  //loop through each probe and calculate the absolute
  //difference between the copy numbers of that probe
  for(int i = 0; i<probes; i++){
    dist = dist + abs(src[i]-dest[i]);
  }
  return dist;
}
