// In "2.4. Parameter inference", "We initialize the method with
// Algorithm 2 assuming each prior probability is 0.25 and then perform
// successive Monte Carlo steps as follows:
// (i) Pick a node u from the tree uniformly at random from all non-root
//     nodes.
// (ii) For each possible parent v of u, excluding current descendants,
//     compute w(v,u) = f_v p(v,u), where f_v is v's node frequency and 
//     p(v,u) is the prior probability of the edge type from v to u. 
//     Note that v might be u's current parent.
// (iii) Pick some v among all possible parents of u with probability 
//     p_v = w(v,u) / \sum_x w(x,u).
// (iv) Delete the edge from u's current parent to u and replace it with
//     edge (v,u).
// Repeatedly applying this move creates a Markov model we call H".

#ifndef EM_H
#define EM_H

#include "graph.h"
#include "node.h"

// Perform parameter inference.
// In "2.4. Parameter inference", "We estimate the parameter set \theta
// by EM".
void perform_parameter_inference(graph *, graph *,
                                 const std::string &, const std::string &,
                                 const obs_graph & , double_vector);

#endif
