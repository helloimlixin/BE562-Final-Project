/* 
 * File:   mst_prim.h
 * Author: Salim
 *
 * Created on April 4, 2012, 9:14 PM
 */
#ifndef MST_PRIM_H
#define	MST_PRIM_H

#include <vector>
#include "constants.h"

// Generates a minimum weight spanning tree (MST) using Prim's algorithm and binary heap data structure
// total is the total number of nodes in the tree
// weight stores the pairwise distance values amongst the nodes
// edges stores indices of the two nodes of each edge in the MST
// terminals stores the copy number count of each probe in each record
// probes is the total number of probes selected by the user
// weight is passed by reference
// min_weight is the weight of minimum weighted steiner tree generated so far
// returns the weight of the MST
int
mst_prim(int total, const std::vector<std::vector<int> > & weight,
         int edges[][2], int terminals[][MAX_PROBES], int probes, int);

#endif	/* MST_PRIM_H */

