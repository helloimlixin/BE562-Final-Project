/* 
 * File:   generate_mst.h
 * Author: Salim
 *
 * Created on October 4, 2011, 3:16 AM
 */
#ifndef GENERATE_MST_H
#define	GENERATE_MST_H

#include <vector>
#include "constants.h"

//procedures are commented in generate_mst.cpp
int
generate_mst(int, int, int, int [][MAX_PROBES], int [][MAX_PROBES],
             int **, int **);

int generate_combination(int [], int, int);

void
generate_weight_matrix(std::vector<std::vector<int> > &,
                       int [][MAX_PROBES], int ,
                       std::vector<std::vector<int> > &,
                       int [][MAX_PROBES], int, int);


unsigned int total_candidate_trees(int);

#endif	/* GENERATE_MST_H */

