// In "2.5. Identifying a global consensus network", "We then find a 
// global consensus network by identifying all pathways used in at least 
// some fraction t of all patients. Given the per-patient trees T_1, 
/// ..., T_n, we can identify consensus pathways by searching 
// depth-first through each tree individually and then, for each node, 
// counting how many other trees have the same node and exhibit the same 
// pathway from that node to the root. Those pathways occurring in a t 
// fraction of trees are added to the global consensus network. For the 
// present study, t = 5%. Note that this consensus network need not 
// itself be a tree, since a node may be reachable by more than one 
// common pathway in different individual trees."

// Definition of consensus node (used in consensus edge and graph).

#ifndef NODECONSENSUS_H
#define NODECONSENSUS_H

#include <vector>
#include <string>

#include "node.h"

// Declare consensus node to represent a state of multiple patient data 
// files of multiple ploidies and gene probes.
class nodeconsensus
{
  private:
  // In possible graph G', class consturctor assigns index to -1.
  // In input graph G, index is used to identify a node in edges table 
  // in class subroutine graph::set_nodes_and_edges().
  int index;

  // In possible graph G', label is an empty string.
  // In input graph G, label is assigned to text of
  // (chromosome_name,gene_name)=(#_chromosome,#_gene)\n....
  // In merge graph and consensus graph, label is concatenated by labels 
  // from mtuliple input graph.
  std::string label;

  public:
  // In possible grapg G', node frequency is used as integer-value
  // frequency count read from patient data file or set as 1.0 on
  // unobserved root node or on a Steiner node (that un-normalized
  // weight is assigned to 1.0, a relatively small positive value; this 
  // weight will be normalized later to approximately
  // 1.0/number_of_cells_counted_in_patient_data_file).
  // In input graph G, node frequencies are normalized to real numbers 
  // as weights and summed up to 1.0.
  double frequency;

  //
  double observed;

  // Get index of this node.
  int get_index() const { return index; }

  // Get label of this node.
  std::string get_label() { return label; }

  // Get observed probability.
  double get_observed() const { return observed; }

  // Get modeled probability.
  double get_modeled() const { return frequency; }

  // Number of patient data files (as joint trees).
  // Will be used as the size of the vector_of_nodes.
  int number_of_files;

  // Number of patient data files (as joint trees) in which this node occurs.
  // Therefore has a valid reference to a joint node in the vector_of_nodes.
  int number_of_trees_sharing_node;

  // Array (as vector) of references (as C/C++ pointers) to joint nodes 
  // in joint trees.
  // vector_of_nodes[i] represents the reference to the joint node in 
  // the i-th joint tree.
  // vector_of_nodes[i] is NULL if this consensus node does not occur in 
  // the i-th joint tree.
  std::vector<node *> vector_of_nodes;

  // Unary operator for output.
  friend std::ostream &operator<<(std::ostream &, const nodeconsensus &);

  // Binary operators for comparison.
  // Sorting among consensus nodes is by string comparison on labels of 
  // consensus nodes.
  // The label of a consensus node can also be found via labels of joint 
  // nodes in the vector_of_nodes.
  // By definition, all joint nodes that are referred to by the same 
  // consensus node must have the same label.
  friend bool operator<(const nodeconsensus &, const nodeconsensus &);
  friend bool operator>(const nodeconsensus &, const nodeconsensus &);
  friend bool operator==(const nodeconsensus &, const nodeconsensus &);
  friend bool operator!=(const nodeconsensus &, const nodeconsensus &);

public:
  // Class constructor.
  nodeconsensus();

  // Class constructor given index of the consensus node among all nodes 
  // in the consensus graph, label of the consensus node, and number of 
  // patient data files.
  // The label is shared among all joint nodes in vector_of_nodes and 
  // this requirement is used in the constructor to identify all the 
  // joint nodes that should be referred to by this consensus node.
  nodeconsensus(int, std::string, int);

  // Set the corresponding reference in vector_of_nodes to the given 
  // index and joint node.
  void set_node_in_vector(int, node *);

  // Get the corresponding reference to the joint node in 
  // vector_of_nodes by the given index.
  node *get_node_in_vector(int);

  // Get ratio of this consensus node among all joint nodes.
  double get_ratio();

  bool is_a_root();
};

#endif
