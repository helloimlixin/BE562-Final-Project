// Merge two rooted trees with weighted nodes and directed edges
// across two distinct assays using a mixed integer linear programming
// (MIP) library. Earlier implementations used the glpk library. The
// current implementation uses the SCIP library from
// http://scip.zib.de/
// Achterberg T, SCIP: solving constraint integer programs,
// Mathematical Programming Computation, 1, pp. 1-41, 2009.
//
// The original description of the integer program to be solved
// in the paper is as follows:
// In "2.7. Merging trees across assays", "The input to our merging
// problem can thus be assumed to be two rooted trees, A = (V_A,E_A) and
// B = (V_B,E_B), with unlabeled, weighted nodes (the output of two runs
// of our inference algorithm above). Our desired output is a joint tree
// T whose states are drawn from the set of tuples V = V_A x V_B and
// whose edges are the union of edges of A and B. That is, for all
// (u_A,v_A) \in E_A there exists some ((u_A,w_B),(v_A,w_B)) \in E and
// for all (u_B,v_B) \in E_B there exists some ((w_A,u_B),(w_A,v_B)) \in
// E."
// In "2.7. Merging trees across assays", "The weight of each node a
// from tree A must be distributed among the states of the joint tree
// that contain a as a member of the tuple, and the weights from tree B
// must be similarly divided."
// In "2.7. Merging trees across assays", "We can define the error at a
// node of the joint tree to be the difference in weight assigned to
// that node by trees A and B. The cost of a joint tree is then defined
// to be this error summed over all the nodes. The optimal joint tree is
// the one with the minimum cost, assuming that weight from the input
// trees is assigned optimally."
//
// However, the above text does not take into account matching ploidy
// or the possibility of diagonal edges. In particular the statement
// that "...whose edges are the union of edges of A and B" is not
// general enough. The diagonal edges are encoded by variables with
// the name C, so that if C_ij is 1 that means that the edge into
// joint node (i,j) comes from the joint node (parent(i), parent (j)).
// Furthermore, there are now terms in the cost function to take into
// account the ploidies of the nodes in A and B that are combined.
//
//
// The C/C++ implementation using glpk was done by Adam Lee in years
// 2010-2011.  The current implementation using SCIP was done by
// E. Michael Gertz in 2014-2015.

#include <algorithm>
#include <fstream>
#include <iostream>
#include <sstream>
#include <set>
#include <vector>

#include <cmath>

#include "scip/cons_linear.h"
#include "scip/scip.h"
#include "scip/scipdefplugins.h"

#ifndef VERBOSE
#define VERBOSE 0
#endif

// If true, take configuration for merge_trees() from a file in
// the current directory named merge_trees.config.
#ifndef ALLOW_EXTERNAL_MERGE_CONFIG
#define ALLOW_EXTERNAL_MERGE_CONFIG 0
#endif

#include "merge.h"

//The value of PLOIDY_CHANGE_PENALTY determines whether the cost
//function in the integer program has extra terms for combining nodes
//that have different ploidies.
#ifndef PLOIDY_CHANGE_PENALTY
#define PLOIDY_CHANGE_PENALTY 0
#endif

using namespace std;

enum { k_invalid_change = -2, k_ambigous_change = 2 };
enum { kinvalid_edge = 0,
       kploidy_change_edge, kploidy_only_edge, kgene_change_edge };

//Two vector types to simplify subsequent declarations
typedef vector<node*> vec_nodes;
typedef vector<SCIP_Cons*> vec_rows;

// In "2.7. Merging trees across assays", "The program then uses two
// sets of 0-1 integer variables: a_ij , which will be 1 if state (i,j)
// was reached by an edge from tree A and b_ij , which will be 1 if
// state (i,j) was reached by an edge from tree B."
// In "2.7. Merging trees across assays", "It also uses three sets of
// real-valued variables: x^A_ij, the weight from tree A assigned to
// state (i,j), x^B_ij, the weight from tree B assigned to state (i,j),
// and \epsilon_ij, the difference in weight assigned to (i,j) by A and
// B."
// This formulation in the Pennington paper turned out to be a little too simple.
// To match numbers of chromosomes and ploidies between nodes from trees
// A and B, the program uses one set of 0-1 integer structural
// variables: c_ij, which will be 1 if state [i,j] was reach by a
// chromosome/ploidy matched and changed edge from both trees A and B.
// Therefore, the integer program has six types of variables, five from
// the paper and c_ij denoted by kind VAR_C.
// i is always the index in tree A and j is always the index in tree B.
enum lp_var_type
{
  VAR_A = 0, // a_i_j
  VAR_B,     // b_i_j
  VAR_C,     // c_i_j
  VAR_Q,    // q_i_j
  VAR_EP,    // \epsilon_i_j
  LP_VAR_TYPES = VAR_EP + 1
};

// Structure to define four characteristics of a variable
struct var_properties {
  const char * name;
  SCIP_VARTYPE kind;  // will be SCIP_VARTYPE_BINARY or SCIP_VARTYPE_CONTINUOUS
  double obj;         // coefficient for this variable in the objective function
  double upper_bound; // upper bound on the value of the variable; the
                      // lower bound is 0.0 for all variables
};

struct merge_trees_config_default {
  const char * name;
  double val;
};

merge_trees_config_default
merge_trees_config_defaults[] = {
  { "parsimony_penalty",     0 }, // penalty for existence of any node
  // Penalty on | q - p |.  Must be nonzero for the formulation to
  // make sense (otherwise some values of q could become underdetermined).
  {"mismatch_penalty",      100 },
  // Additional penalty on | q - p |, i.e. q, for unobserved nodes.
  // May be negative or zero, but mismatch_penalty + steiner_penalty
  // should be > 0.
  { "steiner_penalty",       0 },
  { "existence_penalty",     0 }, // extra penalty for mere existence of Steiner
  { "nonexistence_penalty", 50 },   // penalty for nonexistence of observed
  { "ploidy_penalty",  10000.0 },   // additional penalty for mismatched ploidy
  { "use_edge_weights",   true },   // if true minimize edge weights
};

typedef map<const string, double> merge_trees_settings;

// Return a copy of the default settings for merge_trees().
merge_trees_settings
get_merge_tree_default_settings()
{
  int n =
    sizeof(merge_trees_config_defaults)/sizeof(merge_trees_config_default);
  merge_trees_settings config;
  for (int i = 0;  i < n;  i++) {
    config[merge_trees_config_defaults[i].name] =
      merge_trees_config_defaults[i].val;
  }
  return config;
}

// Read the setting for merge_trees() from a file named 'merge_trees.config'.
// Used for testing different configurations.
void read_merge_trees_settings(merge_trees_settings & config)
{
  ifstream s("merge_trees.config");
  if (!s) {
    cerr << "Cannot open 'merge_trees.config', "
         << "using defaults (this is not an error)." << endl;
  } else {
    cerr << "Reading 'merge_trees.config'." << endl;
  }
  string k;
  double v;
  while (s >> k >> v) {
    cerr << "  Read '" << k << " " << v << "'." << endl;
    if (config.count(k)) {
      config[k] = v;
    } else {
      cerr << "    Unrecognized option " << k << " ignored." << endl;
    }
  }
}

// Print the configuration used for merge_trees().
void
print_merge_configuration(ostream & s,
                          const merge_trees_settings & config)
{
  merge_trees_settings::const_iterator p, pend = config.end();
  for (p = config.begin();  p != pend;  ++p) {
    s << p->first << " " << p->second << "\n";
  }
  s.flush();
}

//Initialize the four properties of each of the six types of variables.
var_properties lp_var_prop[LP_VAR_TYPES] =
  // name    kind                     obj  upper_bound
  { { "a",  SCIP_VARTYPE_BINARY,     0.0, 1.0 },
    { "b",  SCIP_VARTYPE_BINARY,     0.0, 1.0 },
    { "c",  SCIP_VARTYPE_BINARY,     0.0, 1.0 },
    { "q",  SCIP_VARTYPE_CONTINUOUS, 0.0, 1.0 },
    { "ep", SCIP_VARTYPE_CONTINUOUS, 0.0, 1.0 } };


// This is the critical template for organizing the data in the SCIP
// instance. This template is used for both the variables and their
// values as two separate instantiations.
template <class T>
class mip_columns {
  vector<T> vars;     // The variables in the instance or their values
  vector<T*> rows;    // Used to access what are naturally rectangular matrices of
                      // of variables/values by the rows.
  vector<T**> blocks; // The rectangular blocks (matrices) correspond
                      //  to sets of variables of which there are six
                      //  as indicated by enum lp_var_type
public:
  typedef T ** block;

  const int size_A, size_B;  //number of nodes in the tree A and in the tree B

  // For each type of variable, the number of variables of that type
  // is the product of the number of nodes in tree A and the number of
  // nodes in tree B.
  int size() { return size_A * size_B * LP_VAR_TYPES; }

  // The method data() looks up the variables in the SCIP instance.
  T * data() { return &vars[0]; }

  block operator[](int kind) { return blocks[kind]; }
  mip_columns(int sa, int sb) :
    vars(LP_VAR_TYPES * sa * sb, T()), rows(LP_VAR_TYPES * sa, (T*)0),
    blocks(LP_VAR_TYPES, (T**) 0), size_A(sa), size_B(sb)
  {
     rows[0] = &vars[0];
     for (int k = 1;  k < LP_VAR_TYPES * size_A;  k++)
        rows[k] = rows[k-1] + size_B;

     blocks[0] = &rows[0];
     for(int k = 1;  k < LP_VAR_TYPES;  k++)
       blocks[k] = blocks[k-1] + size_A;
  }
};


typedef mip_columns<SCIP_Var *> mip_vars;
typedef mip_columns<SCIP_Real> mip_vals;


// Construct a combined label for the instance of merging the tree
// associated with label_A and the tree associated with label_B or
// combining nodes from A and B.  The label concatenates the gene
// symbols with '+' signs in between each pair of consecutive gene
// symbols.
static string make_joint_label(const string & label_A, const string & label_B)
{
  return label_A + "+" + label_B.substr(label_B.find_last_of("+") + 1);
}

// Create a new joint node that combines node_a and node_b with
// frequency value freq.
static node *
new_joint_node(int k, double freq, node * node_a, node * node_b)
{
  node *joint_node = new node(node_a->index, node_b->index);

  joint_node->index = k;
  joint_node->label = make_joint_label(node_a->label, node_b->label);

  joint_node->joint_node = node_a;
  joint_node->single_node = node_b;

  joint_node->frequency = freq;

  return joint_node;
}


//The following procedure returns the ploidy of a node in tree A,
//which could be a joint node or a single node.
static int get_ploidy(node * a)
{
  return (a->single_node) ? a->get_single_node()->get_chr() : a->get_chr();
}

// The following procedure initializes the six kinds of variables
// within the SCIP instance scip.
static void
init_mip_vars(mip_vars & vars, SCIP * scip)
{
  int size_A = vars.size_A;
  int size_B = vars.size_B;

  for (int kind = 0;  kind < LP_VAR_TYPES;  kind++) {
    var_properties p = lp_var_prop[kind];
    mip_vars::block v = vars[kind];

    for (int i = 0; i < size_A; i++) {
      for (int j = 0; j < size_B; j++) {
        stringstream lp_col_name;
        // Give each variable (column) a name based on its kind and
        // its two indices.
        lp_col_name << p.name << "_" << i << "_" << j;

        // Creates the variables. The third argument is the lower bound.
        SCIP_CALL_ABORT( SCIPcreateVarBasic( scip, &v[i][j],
                                             lp_col_name.str().c_str(),
                                             0.0, p.upper_bound,
                                             p.obj, p.kind ) );

        SCIP_CALL_ABORT( SCIPaddVar(scip, v[i][j]) );
      }
    }
  }
}


// This procedure creates a new linear constraint for the SCIP
// instance as a row in the vector parameter rows.
// - scip -- the SCIP instance
// - base_name -- used for all rows of the same constraint set
// - lb, ub -- the lower and upper bound for the linear function in the row
static void
make_new_row(vec_rows & rows, SCIP * scip, const char * base_name,
             int size, SCIP_Var ** idx, SCIP_Real * coef,
             double lb, double ub)
{
    SCIP_Cons * row;

    stringstream lp_row_name;
    lp_row_name << base_name << rows.size() + 1;

    SCIP_CALL_ABORT( SCIPcreateConsBasicLinear(scip, &row,
                                               lp_row_name.str().c_str(),
                                               size, idx, coef,
                                               lb, ub) );
    rows.push_back(row);
}

////////////////////////////
// Convenience class for printing vectors/matrices as JSON (which are
// easily readable in Perl/Python/anything).
template <typename T> struct json_writer {
  const T & v;
  explicit json_writer(const T & v_) : v(v_) {};
};

template<typename T>
json_writer<T> as_json(const T & v)
{
  return json_writer<T>(v);
}

ostream & operator<<(ostream & s, const json_writer<vector<double> > & self)
{
  int n = self.v.size();
  s << "[";
  for (int i = 0;  i < n;  i++) {
    s << self.v[i];
    if (i == n - 1)
      continue;
    cout << ((i + 1) % 7 == 0 ? ",\n" : ", ");
  }
  s << "]";
  return s;
}

ostream &
operator<<(ostream & s,
           const json_writer<vector<vector<double> > > & self)
{
  int m = self.v.size();
  s << "[";
  for (int i = 0;  i < m;  i++) {
    s << as_json(self.v[i]);
    if (i != m - 1) {
      s << ",\n";
    }
  }
  s << "]";
  return s;
}
//
////////////////////////////

// Test whether the ploidy of nb, necessarily a single node, mismatches
// the ploidy of node na, possibly a joint node.  If the ploidy within
// na itself is inconsistent, return true.
static bool
pair_has_mismatched_ploidy(node * na, node * nb)
{
  int ploidy = nb->chr;
  while(na->single_node) {      // while this is a compound node
    if (na->single_node->chr != ploidy)
      return true;
    na = na->joint_node;
  }
  return na->chr != ploidy;
}

///////////////////

// Compute the observed probabilities of each node that is a candidate
// to be added to the joint tree.
//
// For node i in tree A and node j in tree B, the node (i,j) is a
// candidate for the joint tree.  The observed frequency of (i,j) is
// the number of cells observed with the same probe counts as (i,j),
// divided by the total number of cells observed.  Some combinations
// of (i,j) result in contradictory probe counts, because the ploidy
// probe has a different count in tree A node i than in tree B node j.
// In such a case, the observed probability is defined to be zero; the
// objective function contains a large penalty against using
// ploidy-mismatched nodes.
//
// probs_to_fill [output] -- the observed probabilities;
// row_sums [output] -- marginal sums for each node in tree A;
// col_sums [output] -- marginal sums for each node in tree B.

static void
count_probs(vector<vector<double> > & probs_to_fill,
            vector<double> & sum_row,
            vector<double> & sum_col,
            const vec_nodes & nodes_A,
            const vec_nodes & nodes_B,
            list<map<string,int> > *cnts)
{
  int size_A = nodes_A.size();
  int size_B = nodes_B.size();

  probs_to_fill.resize(size_A);
  for (int i = 0;  i < size_A;  i++) {
    probs_to_fill[i].resize(size_B);
  }
  double sum = 0;
  for (int i = 0;  i < size_A;  i++) {
    for (int j = 0;  j < size_B;  j++) {

      node * na = nodes_A[i];
      node * nb = nodes_B[j];
      if (pair_has_mismatched_ploidy(na, nb)) {
        probs_to_fill[i][j] = 0;
      } else {
        node * jn = new_joint_node(-1, 0.0, na, nb);
        jn->set_observed(cnts);
        probs_to_fill[i][j] = jn->observed;
        delete jn;
      }
      sum += probs_to_fill[i][j];
    }
  }
  for (int i = 0;  i < size_A;  i++) {
    for (int j = 0;  j < size_B;  j++) {
      probs_to_fill[i][j] /= sum;
    }
  }
  sum_row.assign(size_A, 0);
  sum_col.assign(size_B, 0);
  for (int i = 0;  i < size_A;  i++) {
    for (int j = 0;  j < size_B;  j++) {
      sum_row[i] += probs_to_fill[i][j];
      sum_col[j] += probs_to_fill[i][j];
    }
  }
  if (VERBOSE) {
    cout << "observed probabilities" << endl;
    cout << as_json(probs_to_fill) << endl;
    cout << "End observed probabilities" << endl;

    cout << "observed row sums\n";
    cout << as_json(sum_row) << endl;
    cout << "End observed row sums" << endl;

    cout << "observed col sums\n";
    cout << as_json(sum_col) << endl;
    cout << "End observed col sums" << endl;
  }
}

// Return the weight of the edges between each of the nodes in 'nodes',
// and its parent, with the weight of the nonexistent edge between the
// root and its parent set to -1.
vector<double>
parent_edge_weights(const vec_nodes & nodes, edge *** edges)
{
  vector<double> weights(nodes.size());
  for (size_t k = 0;  k < nodes.size();  k++) {
    node * n = nodes[k];
    if (n->parent == NULL) {
      weights[k] = -1;
    } else {
      int i = n->index;
      int j = n->parent->index;
      weights[k] = -log(edges[j][i]->weight);
    }
  }
  return weights;
}


// that a_{ij} + b_{ij} + c_{ij} <= 1, so there is
// at most one way into the combined node indexed by i,j.
//
// If (i,j) is the root node, then the values of a_{ij}, b_{ij} and
// c_{ij} are all fixed at zero when the variables are created.  Thus,
// it is correct to include this constraint on the root.  It is also
// likely insignificant with respect to running time, as the SCIP
// would tend to eliminate such a constraint in the presolve.
//
// 'size_left' and 'size_right' are the number of nodes in the two
// trees being merged.
static void
constraint_set_zero(vec_rows & rows, SCIP * scip,
                    int size_left, int size_right,
                    mip_vars & vars)
{
  SCIP_Real cc[3] = { 1, 1, 1 };
  mip_vars::block a = vars[VAR_A], b = vars[VAR_B], c = vars[VAR_C];
  for (int i = 0;  i < size_left;  i++) {
    for (int j = 0;  j < size_right;  j++) {
      SCIP_Var * ix[3] = { a[i][j], b[i][j], c[i][j] };
      make_new_row(rows, scip, "s0_", 3, ix, cc,  0.0, 1.0);
    }
  }
}


// that each edge found in one of the trees being merged appears at least
// once in the joint tree.
//
// 'size_left' and 'size_right' are the number of nodes in the
// two trees being merged.
static void
constraint_set_one(vec_rows & rows, SCIP * scip,
                   const vec_nodes & nodes_left, int size_right,
                   int kind, mip_vars & vars)
{
  // 1 <= \Sigma_j (a_i_j + c_i_j), for all node i in tree A.
  // 1 <= \Sigma_i (b_i_j + c_i_j), for all node j in tree B.

  assert(kind == VAR_A || kind == VAR_B);

  vector<SCIP_Var*> ix(2 * size_right);
  vector<SCIP_Real> cc(2 * size_right, 1.0);

  for (size_t i = 0;  i < nodes_left.size();  i++) {
    if (nodes_left[i]->parent != NULL) {
      for (int j = 0;  j < size_right;  j++) {
        if (kind == VAR_A) {
           ix[j] = vars[VAR_A][i][j];
           ix[j + size_right] = vars[VAR_C][i][j];
        } else {
          ix[j] = vars[VAR_B][j][i];
          ix[j + size_right] = vars[VAR_C][j][i];
        }
      }
      make_new_row(rows, scip, "s1_", 2 * size_right,
                   &ix[0], &cc[0], 1.0, SCIP_DEFAULT_INFINITY);
    }
  }
}


// This procedure finds whether there is a feasible parent in the
// joint tree is nodes na from tree A and nb from tree B are merged,
// depending on whether the SCIP variables used are for edges in tree
// A (kind == VAR_A), edges in tree B (kind == VAR_B) or diagonal
// edges (kind == VAR_C).
static int
find_joint_parent(node *& parent_A, node *& parent_B, int kind,
                  node * na, node * nb)
{
  parent_A = na;
  parent_B = nb;

  if (kind == VAR_A || kind == VAR_C) {
    if (na->parent == NULL)
      return false;
    parent_A = na->parent;
  }
  if (kind == VAR_B || kind == VAR_C) {
    if (nb->parent == NULL)
      return false;
    parent_B = nb->parent;
  }
  return true;
}


// that an edge is in the joint tree only if its parent node is
// present, ensuring the output is a tree.
static void
constraint_set_two(vec_rows & rows, SCIP * scip,
                   const vec_nodes & nodes_A, const vec_nodes & nodes_B,
                   int kind, mip_vars & mvars)
{
  // let \delta(i,j) = 1 if (i,j) is the root node, and a_i_j + b_i_j + c_i_j
  // otherwise
  //
  // a_i_j <= \delta(pa_A[i,j]), for all node i except the root node --
  // if i is the root node in A then a_i_j == 0
  // b_i_j <= \delta(pa_B[i,j]), for all node j except the root node
  // if j is the root node in B then b_i_j == 0
  // c_i_j <= \delta(pa_AB[i,j]), for all node (i, j) unless i or j is the
  // root node, in which case c_i_j == 0

  assert(kind == VAR_A || kind == VAR_B || kind == VAR_C);

  mip_vars::block v = mvars[kind];
  mip_vars::block a = mvars[VAR_A], b = mvars[VAR_B], c = mvars[VAR_C];

  const int len = 4;
  SCIP_Real cc[len] = {1.0, -1.0, -1.0, -1.0};

  for (size_t i = 0;  i < nodes_A.size();  i++) {
    node * na = nodes_A[i];
    for (size_t j = 0;  j < nodes_B.size();  j++) {

      node *parent_A, *parent_B;

      if (!find_joint_parent(parent_A, parent_B, kind, na, nodes_B[j])) {
        // Cannot enter the merge graph through this node (unless root)
        SCIP_CALL_ABORT(SCIPchgVarUb(scip, v[i][j], 0.0));
      } else if (parent_A->parent == NULL && parent_B->parent == NULL) {
        // (parent_A, parent_B) is the root node, no constraint
        continue;
      } else {
        int k = parent_A->index, ell = parent_B->index;

        SCIP_Var* ix[len] = { v[i][j], a[k][ell], b[k][ell], c[k][ell] };

        make_new_row(rows, scip, "s2_", len, ix, cc,
                     -SCIP_DEFAULT_INFINITY, 0.0);
      }
    } // end for j
  } // end for i
}


// prevents weight from being assigned to unused nodes in the tree.
static void
constraint_set_three(vec_rows & rows, SCIP * scip,
                     const vec_nodes & nodes_A, const vec_nodes & nodes_B,
                     int kind, mip_vars & mvars)
{
  // let delta(i,j) = 1 if (i,j) is the root node, and
  // a_i_j + b_i_j + c_i_j otherwise
  //
  // xa_i_j <= delta(i,j) and xb_i_j <= delta(i,j)

  assert(kind == VAR_Q);

  mip_vars::block q = mvars[VAR_Q];
  mip_vars::block a = mvars[VAR_A], b = mvars[VAR_B], c = mvars[VAR_C];

  for (size_t i = 0;  i < nodes_A.size();  i++) {
    node *node_a = nodes_A[i];

    for (size_t j = 0;  j < nodes_B.size();  j++) {
      node * node_b = nodes_B[j];

      if (node_a->parent == NULL && node_b->parent == NULL) {
        continue;               // No constraint is needed for the root.
      }
      const int len = 4;
      SCIP_Real cc[len] = { 1.0, -1.0, -1.0, -1.0 };
      SCIP_Var * ix[len] = { q[i][j], a[i][j], b[i][j], c[i][j] };

      make_new_row(rows, scip, "s3_", len, ix, cc,
                   -SCIP_DEFAULT_INFINITY, 0.0);
    }
  }
}


// ensures that weights assigned to nodes in the joint tree are
// consistent with the weights assigned to the nodes in the parent
// trees.
static void
constraint_set_four(vec_rows & rows, SCIP * scip,
                    int size_left, int size_right,
                    const vector<double> & marginal_sum,
                    int kind, mip_vars & mvars)
{
  // \Sigma_j xa_i_j = wa_i, for all node i in tree A.
  // \Sigma_i xb_i_j = wb_j, for all node j in tree B.
  assert(kind == VAR_A || kind == VAR_B);
  mip_vars::block q = mvars[VAR_Q];

  vector <SCIP_Real> val(size_right, 1.0);
  vector <SCIP_Var*> idx(size_right);

  for (int i = 0;  i < size_left;   i++) {
    double freq = marginal_sum[i];

    for (int j = 0;  j < size_right;  j++)
      idx[j] = (kind == VAR_A) ? q[i][j] : q[j][i];

    make_new_row(rows, scip, "s4_", size_right, &idx[0], &val[0], freq, freq);
  }
}


// defines the errors as the absolute values of the differences in
// weights assigned to nodes in the two trees.
static void constraint_set_five(vec_rows & rows, SCIP * scip, mip_vars & mvars,
                                const vector<vector<double> > & probs)
{
  // ep_i_j >= xa_i_j - xb_i_j
  // ep_i_j >= xb_i_j - xa_i_j
  mip_vars::block ep = mvars[VAR_EP], q = mvars[VAR_Q];

  SCIP_Real up[] = { 1.0, -1.0 }, dn[] = { 1.0, 1.0 };

  for (int i = 0;  i < mvars.size_A;  i++) {
    for (int j = 0;  j < mvars.size_B;  j++) {
      double p = probs[i][j];
      SCIP_Var * idx[] = { ep[i][j], q[i][j] };

      make_new_row(rows, scip, "s5_", 2, idx, up, -p, SCIP_DEFAULT_INFINITY);
      make_new_row(rows, scip, "s5_", 2, idx, dn, p, SCIP_DEFAULT_INFINITY);
    }
  }
}

// Add a penalty for mere existence of nodes.
static void
add_parsimony_penalty(SCIP * scip, mip_vars & vars,
              int size_A, int size_B,
              double penalty)
{
  if (penalty == 0)
    return;
  mip_vars::block a = vars[VAR_A], b = vars[VAR_B], c = vars[VAR_C];

  for (int i = 0;  i < size_A;  i++) {
    for (int j = 0;  j < size_B;  j++) {
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, a[i][j], penalty) );
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, b[i][j], penalty) );
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, c[i][j], penalty) );
    }
  }
}


// This procedure changes the objective function to add a penalty
// for using a joint node derived from nodes in trees A and B
// that have distinct ploidies.
// - scip -- the SCIP instance
// - vars -- the variables of the SCIP instance
// - nodes_A, nodes_B -- the nodes of the trees A and B, respectively
static void
set_ploidy_penalty(SCIP * scip, mip_vars & vars,
                   const vec_nodes & nodes_A, const vec_nodes & nodes_B,
                   double penalty)
{
  int size_A = nodes_A.size();
  int size_B = nodes_B.size();
  mip_vars::block a = vars[VAR_A], b = vars[VAR_B], c = vars[VAR_C];

  for (int i = 0;  i < size_A;  i++) {
    for (int j = 0;  j < size_B;  j++) {
      // Different methods for finding ploidy because the
      // semantics of the A and B graphs is different.  The A
      // graph may be a joint_tree, but the B graph is never a
      // joint_tree.  So the proper way of getting the ploidy of
      // nodes from the B graph is to look at the chr, but for
      // the nodes from A, a more complicated rule must be used.

      double pen = 0;
      node * na = nodes_A[i];
      int chrb = nodes_B[j]->get_chr();
      while(na->single_node) {
        if (na->single_node->get_chr() != chrb)
          pen += penalty;
        na = na->joint_node;
      }
      if (na->get_chr() != chrb)
        pen+= penalty;

      if (pen > 0) {
        // cerr << "Ploidy penalty for (" << i << ", " << j << ") > "
        //      << nodes_A[i]->chr << ":"
        //      << nodes_A[i]->gene << ":"
        //      << nodes_B[j]->chr << ":"
        //      << nodes_B[j]->gene << " > " << pen << endl;

        SCIP_CALL_ABORT( SCIPaddVarObj(scip, a[i][j], pen) );
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, b[i][j], pen) );
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, c[i][j], pen) );
      }
    }
  }
}

// Add two sets of terms to the objective function
// based on comparing the nodes in the joint tree and the observed states.
//
// One term adds a penalty for Steiner nodes that are in the joint
// tree, but have a counts of 0.
//
// The other term adds a reward (negative cost) for including observed
// states, with count > 0, as nodes in the merged tree.
//
// Currently the first coefficient is fixed by the global (within the
// file) variable steiner_penalty, while the second coefficient is
// partly passed in as the argument penalty.  The second coefficient
// is transformed from penalty to reward by multiplying by 0.5.
static void
set_mismatch_penalty(SCIP * scip, mip_vars & vars,
                     const vec_nodes & nodes_A, const vec_nodes & nodes_B,
                     double existence_penalty, double nonexistence_penalty,
                     double mismatch_penalty, double steiner_penalty,
                     const vector<vector<double> > &  counts)
{
  int size_A = nodes_A.size();
  int size_B = nodes_B.size();
  mip_vars::block q = vars[VAR_Q], ep = vars[VAR_EP];
  mip_vars::block a = vars[VAR_A], b = vars[VAR_B], c = vars[VAR_C];

  for (int i = 0;  i < size_A;  i++) {
    for (int j = 0;  j < size_B;  j++) {
      SCIP_CALL_ABORT( SCIPaddVarObj(scip, ep[i][j], mismatch_penalty) );
      if (counts[i][j] == 0) {
        /* Penalty for existence in the join tree of a node that
           did not occur in the observations (Steiner node) */
        // cerr << "Setting " << "(" << i << ", " << j << ") > "
        //      << nodes_A[i]->chr << ":"
        //      << nodes_A[i]->gene << ":"
        //      << nodes_B[j]->chr << ":"
        //      << nodes_B[j]->gene << endl;
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, a[i][j], existence_penalty) );
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, b[i][j], existence_penalty) );
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, c[i][j], existence_penalty) );
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, q[i][j], steiner_penalty) );
      } else {
        // cerr << "Skipping " << "(" << i << ", " << j << ") > "
        //      << nodes_A[i]->chr << ":"
        //      << nodes_A[i]->gene << ":"
        //      << nodes_B[j]->chr << ":"
        //      << nodes_B[j]->gene << endl;
        /* Penalty for non-existence in the join tree of a node that
           was actually observed; specified as an reward for existence
           The actual penalty is .5 * pen * (1 - a - b - c), but the
           constant term is omitted. */
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, a[i][j], -nonexistence_penalty) );
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, b[i][j], -nonexistence_penalty) );
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, c[i][j], -nonexistence_penalty) );
      }
    }
  }
}

// Add the log-odds edge weight cost to the objective function.
static void
add_edgeweight_cost(SCIP * scip, mip_vars & vars,
                    const vector<double> & weights_a,
                    const vector<double> & weights_b)
{
  int size_A = weights_a.size();
  int size_B = weights_b.size();
  mip_vars::block a = vars[VAR_A], b = vars[VAR_B], c = vars[VAR_C];

  for (int i = 0;  i < size_A;  i++) {
    for (int j = 0;  j < size_B;  j++) {
      if (weights_a[i] > 0) {
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, a[i][j], weights_a[i]) );
      }
      if (weights_b[j] > 0) {
        SCIP_CALL_ABORT( SCIPaddVarObj(scip, b[i][j], weights_b[j]) );
      }
      if (weights_a[i] >= 0 && weights_b[j] >= 0) {
        double w = weights_a[i] + weights_b[j];
        if (w > 0)
          SCIP_CALL_ABORT( SCIPaddVarObj(scip, c[i][j], w) );
      }
    }
  }
}

// This procedure changes the coefficients for the a_ij, b_ij, and
// c_ij variables in the objective function to penalize using joint
// edges that change the ploidy status from agreeing in both trees A
// and B at the tail of the edge to disagreeing at the head of the
// edge.  The parameter penalty is the amount of the penalty; the SCIP
// problem is formulated as a minimization, so the penalty should be
// positive.
// - scip -- the instance
// - vars -- the template class instance of variables in the integer
//           programming instance
// - nodes_A, nodes_B -- the nodes of the two trees to be merged.
static void
set_ploidy_change_penalty(SCIP * scip, mip_vars & vars,
                          const vec_nodes & nodes_A,
                          const vec_nodes & nodes_B,
                          double penalty)
{
  cout << "USING PLOIDY_CHANGE_PENALTY\n";

  int size_A = nodes_A.size();
  int size_B = nodes_B.size();

  // Find the blocks of a_ij, b_ij, and c_ij variables.
  mip_vars::block a = vars[VAR_A], b = vars[VAR_B], c = vars[VAR_C];

  for (int i = 0;  i < size_A;  i++) {
    int aploidy = get_ploidy(nodes_A[i]);

    for (int j = 0;  j < size_B;  j++) {
      int bploidy = nodes_B[j]->get_chr();

      if (aploidy == bploidy) // Ploidy is the same, no penalty
        continue;

      if (nodes_A[i]->parent != NULL) {
        // case where the ploidy of the parent node in A matches the
        // ploidy of the node in B, but the edge in A changes the
        // ploidy
        if (get_ploidy(nodes_A[i]->parent) == bploidy)
          SCIP_CALL_ABORT( SCIPchgVarObj(scip, a[i][j], penalty) );
      }

      // case where the ploidy of the parent node in B matches the
      // ploidy of the node in A, but the edge in B changes the ploidy
      if (nodes_B[j]->parent != NULL) {
        if (aploidy == nodes_B[j]->parent->get_chr())
          SCIP_CALL_ABORT( SCIPchgVarObj(scip, b[i][j], penalty) );
      }

      // case where the ploidies of the parent nodes agree but the
      // diagonal edge has the effect of changing the ploidy in one
      // tree but not the other
      if (nodes_A[i]->parent != NULL && nodes_B[j]->parent != NULL) {
        if (get_ploidy(nodes_A[i]->parent) == nodes_B[j]->parent->get_chr())
          SCIP_CALL_ABORT( SCIPchgVarObj(scip, c[i][j], penalty) );
      }
    }
  }
}


// This procedure sets up all the rows of the linear program and
// implements one of two sets of terms in the cost function to take
// ploidy or ploidy changes into account.
// - scip -- the container for the integer linear program
// - vars -- the container for all the variables
// - nodes_A, nodes_B -- the node sets of the two trees as vectors
//    the first node in each vector is the root
static void
create_mip_constraints(SCIP * scip, mip_vars & vars,
                       const vec_nodes & nodes_A, const vec_nodes & nodes_B,
                       const vector<vector<double> > & probs,
                       const vector<double> & marginal_rows,
                       const vector<double> & marginal_cols)
{
  vec_rows rows;

  constraint_set_zero(rows, scip, nodes_A.size(), nodes_B.size(), vars);

  constraint_set_one(rows, scip, nodes_A, nodes_B.size(), VAR_A, vars);
  constraint_set_one(rows, scip, nodes_B, nodes_A.size(), VAR_B, vars);

  constraint_set_two(rows, scip, nodes_A, nodes_B, VAR_A, vars);
  constraint_set_two(rows, scip, nodes_A, nodes_B, VAR_B, vars);
  constraint_set_two(rows, scip, nodes_A, nodes_B, VAR_C, vars);

  constraint_set_three(rows, scip, nodes_A, nodes_B, VAR_Q, vars);

  constraint_set_four(rows, scip, nodes_A.size(), nodes_B.size(),
                      marginal_rows, VAR_A, vars);
  constraint_set_four(rows, scip, nodes_B.size(), nodes_A.size(),
                      marginal_cols, VAR_B, vars);

  constraint_set_five(rows, scip, vars, probs);


  // In SCIP, constraints are copied when added to the problem, so the
  // originals need to be freed.  SCIPaddCons copies the constraint,
  // originally in rows[k], into the problem object, which is
  // implicitly in 'scip' but doesn't have another explicit name.
  // SCIPaddCons is a routine from SCIP and doesn't know anything
  // about the C++ standard vector rows.  SCIPreleaseCons releases the
  // resources associated with the object in rows[k], which has been
  // copied and so is no longer needed.  While it takes 'scip' as a
  // parameter, it does not remove the constraint from the problem
  // object.  The call to SCIPaddCons does not change rows.size.
  for (size_t k = 0;  k < rows.size();  k++)
    SCIP_CALL_ABORT( SCIPaddCons(scip, rows[k]) );

  for (size_t k = 0;  k < rows.size();  k++)
    SCIP_CALL_ABORT( SCIPreleaseCons( scip, &rows[k] ) );

}


// Prints the SCIP instance to a file.  The actual file name used
// concatenates the argument filename, the argument label, and the
// string ".cip".
static void
print_mip_to_file(SCIP * scip, const string & filename, const string & label)
{
  FILE * file = fopen((filename + "." + label + ".cip").c_str(), "w");
  if (!file) {
    perror(0);
    exit(EXIT_FAILURE);
  }
  SCIP_CALL_ABORT( SCIPprintOrigProblem(scip, file, "cip", false) );

  fclose(file);
}


// Prints the solution of the SCIP instance to a file the actual
// filename used concatenates the argument filename, the argument
// label, and the string ".mip".
static void write_sol(SCIP * scip, const string & fname, const string & label)
{
  FILE * solf = fopen((fname + "." + label + ".mip").c_str(), "w");
  if (!solf) {
    perror(0);
    exit(EXIT_FAILURE);
  }
  SCIP_CALL_ABORT( SCIPprintBestSol(scip, solf, false) );
  fclose(solf);
}


// This procedure prints out the value of one 'block' of variables in the
// mip solution as a sparse matrix; the size of each block in size_A * size_B
// Here 'name' is the name of this block of variables.
static void
write_matrix(mip_vals::block v, const char * name, int size_A, int size_B)
{
  int precision = cout.precision();

  cout.precision(17);

  int nnz = 0;
  for (int i = 0; i < size_A; i++) {
    for (int j = 0; j < size_B; j++) {
      if (v[i][j] >= DBL_EPSILON)
        nnz++;
    }
  }
  cout << "\n# name:  " << name << "\n";
  cout << "# type:  sparse matrix\n";
  cout << "# nnz:  " << nnz << "\n";
  cout << "# rows:  " << size_A << "\n";
  cout << "# columns:  " << size_B << "\n";

  for (int j = 0; j < size_B; j++) {
    for (int i = 0; i < size_A; i++) {
      if (v[i][j] >= DBL_EPSILON)
        cout << i + 1 << " " << j + 1 << " " << v[i][j] << "\n";
    }
  }
  cout << endl;

  cout.precision(precision);
}


// This procedure writes out the values of of all the variables and the
// objective function in the solution to the instance scip.
static void display_solution(SCIP * scip, mip_vals & vals)
{
  if (VERBOSE) {
    cout << "Minimum objective value =\t"
      << SCIPgetSolOrigObj(scip, SCIPgetBestSol(scip))
      << endl << endl;
  }
  cout << "begin solution" << endl;
  for (int kind = 0;  kind < LP_VAR_TYPES;  kind++)
    write_matrix(vals[kind], lp_var_prop[kind].name,
                 vals.size_A, vals.size_B);
  cout << "End solution" << endl;

}


// This procedure determines the parent->child edge structure of the
// joint tree from the values of the variables in the solution to the
// SCIP instance node_J is a vector of joint nodes.
// - parents -- a vector of pairs of parents in the original trees
// - nodes_A, nodes_B -- the sets of nodes in the original trees
// - vals -- the set of values from the SCIP solution
static void
scan_joint_tree(vec_nodes & node_J, vector<pair<int,int> > & parents,
                const vec_nodes & nodes_A, const vec_nodes & nodes_B,
                mip_vals & vals)
{
  const double min_yes = 0.99; //used to test if a variable
                               //intended as a binary variable has value 1

  mip_vals::block a  = vals[VAR_A],  b  = vals[VAR_B], c = vals[VAR_C];
  mip_vals::block q = vals[VAR_Q];

  for (size_t i = 0;  i < nodes_A.size();  i++) {
    node *node_a = nodes_A[i], *parent_A = node_a->parent;

    for (size_t j = 0;  j < nodes_B.size();  j++) {
      node *node_b = nodes_B[j], *parent_B = node_b->parent;

      int parent_i = i, parent_j = j;
      double freq = 0.0;

      // Find the parents based on the values of the a_ij, b_ij, and c_ij.
      if (parent_A == NULL && parent_B == NULL) {
        parent_i = parent_j = -1; // The root node
      } else if (a[i][j] >= min_yes) {
        assert(b[i][j] < min_yes && c[i][j] < min_yes && parent_A != NULL);

        parent_i = parent_A->index;
      } else if (b[i][j] >= min_yes) {
        assert(a[i][j] < min_yes && c[i][j] < min_yes && parent_B != NULL);

        parent_j = parent_B->index;
      } else if (c[i][j] >= min_yes) {
          assert(a[i][j] < min_yes && b[i][j] < min_yes);
          assert(parent_A != NULL && parent_B != NULL);

          parent_i = parent_A->index;
          parent_j = parent_B->index;

      } else {
        continue;               // Not in graph
      }
      // Create the new joint node and set its frequency.
      freq = q[i][j];
      node * joint_node = new_joint_node(node_J.size(), freq, node_a, node_b);

      // Find the ordered pair of parents for the joint node.
      node_J.push_back(joint_node);
      parents.push_back(pair<int,int>(parent_i, parent_j));
    }
  }
}

// This procedure determines the structure of the joint tree from the
// values of the variables in the solution to the SCIP instance and
// sets the values of the fields in each node.  It also finds the root
// of the tree and passes it back by reference.
// - node_J -- a vector of the nodes of the joint tree
// - root -- the root of the joint tree
// - nodes_A and nodes_B -- the nodes of the two original trees
// - vals -- the values of the variables in the solution to the SCIP instance
// - cnts -- a list of mappings from probes to counts for one file of patient
//           data
// The tree structure determination is done in the procedure scan_joint_tree().
static void
read_joint_nodes(vec_nodes & node_J, node *& root,
                 const vec_nodes & nodes_A, const vec_nodes & nodes_B,
                 mip_vals & vals, const vector<vector<double> > & probs)
{
  vector<pair<int,int> > parents; // maps a joint node to its parent via indices

  // Determine the parent of each non-root node.
  scan_joint_tree(node_J, parents, nodes_A, nodes_B, vals);

  // Set up a map from the pair (joint node index, single node index)
  // to new node index.
  map<pair<int, int>, int> nodes2index;

  double frequency_sum = 0.0, observed_sum = 0.0;
  for (size_t k = 0;  k < node_J.size();  k++) {
    node * nn = node_J[k];

    frequency_sum += nn->frequency;

    // Find the observed count for the combination of probe values
    // assigned to this joint node as its label.
    nn->observed = probs[nn->joint_node->index][nn->single_node->index];
    observed_sum += nn->observed;

    // Assign indices to the new joint nodes.
    pair<int,int> paired_index(nn->joint_node->index, nn->single_node->index);
    nodes2index[paired_index] = k;
  }
  root = NULL;
  for (size_t k = 0;  k < node_J.size();  k++) {
    node * nn = node_J[k];
    pair<int,int> parent = parents[k];

    nn->frequency /= frequency_sum; // Normalize frequencies
    nn->observed /= observed_sum;

    if (-1 == parent.first)
      root = nn;                // This is the root
    else // Assign the parent as an index in one dimension using the
         // mapping nodes2index.
      nn->parent = node_J.at(nodes2index.at(parent));
  }
  assert(root != NULL);
}

// Find the change in copy number for a given chr/gene pair.  Marks the
// gene change as k_ambiguous change if the chromosome changed, but the gene
// at 'sn' had copy number zero.  (This is ambiguous because either a
// change in the copy number of chromosome, or a change in the copy number
// of the chromosome *probe* may have occurred.)
static void
chr_gene_pair_change(int & change_chr, int & change_gene, node * sn, node * tn)
{
  change_chr = tn->chr - sn->chr;
  change_gene = tn->gene - sn->gene;

  if (change_chr != 0 && sn->gene == 0) {
     // The chromosome change suggests the gene should
     // have changed too, but could not because it had
     // zero copy number.
    change_gene = k_ambigous_change;
  }
}

// Find edge type
// Return a vector of ints representing an edge type. The numbers -1,0,1 represent
// changes in copy number.  The constant k_ambigous_change (2) marks positions in
// a tuple where a ploidy change suggests that the gene would have changed, but
// the gene could not because it had zero copy number.
static vector<int>
find_edge_type(node * source, node * target)
{
  vector<int> counts;
  int change_chr, change_gene;
  while(source->single_node) {
    chr_gene_pair_change(change_chr, change_gene, source->single_node,
                         target->single_node);

    // Push gene *first* because the list will be reversed (putting chr first).
    counts.push_back(change_gene);
    counts.push_back(change_chr);

    source = source->joint_node;
    target = target->joint_node;
  }
  chr_gene_pair_change(change_chr, change_gene, source, target);
  counts.push_back(change_gene);
  counts.push_back(change_chr);

  reverse(counts.begin(), counts.end());
  return counts;
}


// Make an edge type that represents a gene change.  This will have the form
// (0,..,0,+-1,0...,0), i.e. a +-1 in the appropriate position.
static vector<int>
make_gene_change_edge(size_t npairs, int k, int sense)
{
  vector<int> gene_change(2 * npairs, 0);
  gene_change[2 * k + 1] = sense;
  return gene_change;
}

// Make an edge type that represents a change only in the ploidy probe
// itself.   This will have the form (+-1,0,+-1,0,....),
static vector<int>
make_ploidy_only_edge(size_t npairs, int ploidy_change)
{
  vector<int> ploidy_probe_change(2 * npairs, 0);
  for (size_t k = 0;  k < npairs;  k++)
    ploidy_probe_change[2 * k] = ploidy_change;

  return ploidy_probe_change;
}


// Look at the change counts within an edge and classify the edge by
// overall type, one of
//
// enum { kinvalid_edge = 0,
//       kploidy_change_edge, kploidy_only_edge, kgene_change_edge };
static int
classify_edge(const vector<int> & edge)
{
  size_t npairs = edge.size() / 2;

  bool invalid_edge = false, any_gene_changed = false;
  bool has_unambiguous_gene = false;
  int ploidy_change = 0;

  for (size_t k = 0;  k < npairs;  k++) {
    int change_chr = edge[2 * k];
    int change_gene = edge[2 * k + 1];

    if (k == 0) {
      ploidy_change = change_chr;
    } else if (ploidy_change != change_chr) {
      invalid_edge = true;
      break;
    }
    if (change_gene != k_ambigous_change)
      has_unambiguous_gene = true;

    if (change_gene == -1 || change_gene == 1) {
      any_gene_changed = true;
      if (ploidy_change != 0 && change_gene != ploidy_change) {
        invalid_edge = true;
        break;
      }
    }
  }
  if (invalid_edge) {
    return kinvalid_edge;
  } else if (ploidy_change != 0 &&
             !any_gene_changed && has_unambiguous_gene) {
    return kploidy_only_edge;
  } else if (ploidy_change != 0) { // Just the ploidy probe changed
    return kploidy_change_edge;
  } else {
    return kgene_change_edge;
  }

}


// Split an edge into a list of mutations that could be applied to create
// the edge.  The permissible mutations are ploidy change, gene change, and
// ploidy-probe only change.
static vector<vector<int> >
split_edge(const vector<int> & edge)
{
  vector<vector<int> > split;

  int edge_type = classify_edge(edge);
  int ploidy_sense = edge[0];
  size_t npairs = edge.size() / 2;

  switch (edge_type) {
  case kinvalid_edge:
    split.push_back(vector<int>(2 * npairs, k_invalid_change));
    break;
  case kploidy_change_edge:
    split.push_back(vector<int>(2 * npairs, ploidy_sense));

    for (size_t k = 0;   k < npairs;  k++) {
      if (edge[2 * k + 1] == 0)
        split.push_back(make_gene_change_edge(npairs, k, -ploidy_sense));
    }
    break;
  case kploidy_only_edge:
    split.push_back(make_ploidy_only_edge(npairs, ploidy_sense));
    break;
  case kgene_change_edge:
    for (size_t k = 0;   k < npairs;  k++) {
      int delta_gene = edge[2 * k + 1];
      if (delta_gene == 1 || delta_gene == -1) {
        split.push_back(make_gene_change_edge(npairs, k, delta_gene));
      }
    }
    break;
  }
  return split;
}

// Given a set of edge counts, estimate the probabilities of permissible
// mutations.  The permissible mutations are ploidy change, gene change,
// and ploidy-probe only change.
static void
edge_counts_to_mutation_probs(edge_counts_type & probs,
                              const edge_counts_type & counts)
{
  probs.clear();
  if (counts.size() == 0)   // no edges, degenerate case
    return;

  edge_counts_type::const_iterator p = counts.begin(), pend = counts.end();

  size_t npairs = p->first.size() / 2;    // number of (chr, gene) pairs

  // Change counts representing ploidy gains/losses.
  vector<int> all_gain(2 * npairs, 1), all_loss(2 * npairs, -1);

  double total_count = 0;
  for ( ;  p != pend;  ++p) {
    const vector<int> & edge = p->first;
    double this_count = p->second;

    vector<vector<int> > split = split_edge(edge);
    size_t nsplit = split.size();
    for (size_t k = 0;  k < nsplit;  k++) {
      probs[ split[k] ] += this_count;
    }
    total_count += this_count * nsplit;
  }
  edge_counts_type::iterator q, qend = probs.end();
  for (q = probs.begin();  q != qend;  ++q) {
    q->second /= total_count;
  }
}

// This procedure sets up the edge table for the joint tree. At the
// time the procedure is called the edges are set implicitly by the
// values of the parent fields of the nodes in the joint tree, but edge
// properties such as the type of each edge are set in this procedure.
// - node_J -- a vector of nodes in the joint tree;
// - edges_A and edges_B -- the pointers to the edge tables of the
// trees A and B.
//
// A pointer to the edge table of the joint tree is returned.
static edge ***
make_joint_edges(edge_counts_type & edge_probs,
                 const vec_nodes & node_J, edge *** edges_A,
                 edge *** edges_B)
{
  edge_counts_type edge_counts;

  // Find the number of joint nodes.
  int size_J = node_J.size();

  // Declare the edge table to be returned
  edge *** joint_edges = new edge **[size_J];
  for (int k = 0;  k < size_J;  k++)
    joint_edges[k] = new edge*[size_J](); // Initializes to nil

  edge_counts.clear();;
  int total_edges = 0;
  for (int target_index = 0;  target_index < size_J;  target_index++) {
    // Find one edge implicitly as an ordered pair of (source, target).
    node *target = node_J[target_index], *source = target->parent;

    if (source == NULL)
      continue;                 // Target is the root node

    ++edge_counts[find_edge_type(source, target)];
    ++total_edges;

    // Find the corresponding source and target nodes in trees A and B.
    node *atarget = target->joint_node, *btarget = target->single_node;
    node *asource = source->joint_node, *bsource = source->single_node;

    // Assign the type of the edge and its weight based on the
    // corresponding edges in the trees A and B.  The main term in
    // weight is determined by calling either joint_edge weight() for
    // non-diagonal edges or diagonal_edge_weight() for diagonal edges
    // and then normalizing by multiplying by the frequency of the
    // joint source node frequency.
    int edge_type;
    if (asource != atarget && bsource != btarget) {
        // Diagonal move
        int edge_type_A = edges_A[asource->index][atarget->index]->type;
        int edge_type_B = edges_B[bsource->index][btarget->index]->type;

        if (edge_type_A == edge_type_B) {
          edge_type = edge_type_A;
        } else if (((edge_type_A == CHR_GENE_LOSS) &&
                    (edge_type_B == CHR_LOSS)) ||
                   ((edge_type_A == CHR_LOSS) &&
                    (edge_type_B == CHR_GENE_LOSS))) {
          // Compatible losses
          edge_type = CHR_GENE_LOSS;
        }
        else if (((edge_type_A == CHR_GAIN) &&
                  (edge_type_B == CHR_GENE_GAIN)) ||
                 ((edge_type_A == CHR_GENE_GAIN) &&
                  (edge_type_B == CHR_GAIN))) {
          // Compatible gain
          edge_type = CHR_GENE_GAIN;
        } else {
          edge_type = INVALID;
        }
    } else if (asource != atarget) {
      edge_type = edges_A[asource->index][atarget->index]->type;
    } else {
      assert(bsource != btarget);

      edge_type  = edges_B[bsource->index][btarget->index]->type;
    }
    edge * ee = new edge(source, target, edge_type);
    joint_edges[source->index][target_index] = ee;
  }
  edge_counts_to_mutation_probs(edge_probs, edge_counts);

  for (int i = 0;  i < size_J;  i++) {
    for (int j = 0;  j < size_J;  j++) {
      if (!joint_edges[i][j])
        continue;
      node * source = joint_edges[i][j]->tail;
      node * target = joint_edges[i][j]->head;
      vector<vector<int> > split = split_edge(find_edge_type(source, target));
      size_t nsplit = split.size();
      joint_edges[i][j]->weight = 1.0;
      for (size_t k = 0;  k < nsplit;  k++) {
        joint_edges[i][j]->weight *= edge_probs[ split[k] ];
      }
    }
  }
  return joint_edges;
}

// This is the high-level procedure to infer what is the merged tree
// based on the two trees A and B (passed in as nodes and edges) and
// the values of the variables from the solution to the SCIP instance,
// which are passed in as vals.
// - joint_label -- the name of the merged tree
// - cnts -- a list of maps from probes to observed counts of that probe
// for one patient sample
static graph *
read_joint_tree(edge_counts_type & edge_probs,
                const vec_nodes & nodes_A, edge *** edges_A,
                const vec_nodes & nodes_B, edge *** edges_B,
                mip_vals & vals,
                const vector<vector<double> > & probs,
                const string & joint_label)
{
  node * root; // special placeholder for the root node of the joint tree
  vec_nodes node_J; // holds the nodes of the joint tree

  // Call a procedure to find the nodes in the joint tree, using vals
  // and cnts.  This procedure also sets up the edges implicitly by
  // finding the parent of each non-root node in the joint tree
  read_joint_nodes(node_J, root, nodes_A, nodes_B, vals, probs);

  graph * joint_tree = new graph(joint_label);

  // Assign indices to the nodes.
  joint_tree->list_of_nodes.assign(node_J.begin(), node_J.end());
  joint_tree->size = node_J.size();
  joint_tree->root = root;

  // Set up the table of edges in the joint tree based on the values
  // of parent.
  joint_tree->table_of_edges = make_joint_edges(edge_probs,
                                                node_J, edges_A, edges_B);

  return joint_tree;
}


// Initialize one instance of an integer programming problem for SCIP
// to solve. The instance is always called "merge".
static SCIP * initialize_scip()
{
  SCIP * scip;

  SCIP_CALL_ABORT( SCIPcreate(&scip) );
  SCIP_CALL_ABORT( SCIPcreateProbBasic(scip, "merge") );
  SCIP_CALL_ABORT( SCIPincludeDefaultPlugins(scip) );

  return scip;
}


// This is the main procedure for calling the SCIP library to solve
// the integer programming instance scip; vals is the structure of
// values of variables and vars is the structure of variables.
//
// Returns 0 if found a primal feasible point, -1 otherwise.
// The output parameter is_optimal indicates whether the feasible
// point is optimal.
static int
solve_using_scip(mip_vals & vals, SCIP * scip, mip_vars & vars,
                 bool & is_optimal)
{
  is_optimal = false;
  // Set the time limit on SCIP; time units are seconds.
  SCIP_CALL_ABORT( SCIPsetRealParam(scip, "limits/time",
                                    60 * TIMEOUT) );

  SCIPinfoMessage(scip, NULL, "\n");
  SCIP_CALL_ABORT( SCIPpresolve(scip) );

  SCIPinfoMessage(scip, NULL, "\nSolving...\n");
  SCIP_CALL_ABORT( SCIPsolve(scip) );

  SCIP_SOL* sol = SCIPgetBestSol(scip);
  if (!sol) {
    return -1;
  } else {
    SCIP_CALL_ABORT( SCIPgetSolVals(scip, SCIPgetBestSol(scip),
                                    vars.size(),
                                    vars.data(), vals.data()));
    SCIP_STATUS scip_status = SCIPgetStatus(scip);

    is_optimal = scip_status == SCIP_STATUS_OPTIMAL;
    return 0;
  }
}

// This procedure frees the memory associated with the variables used
// in the SCIP instance.
static void free_mip_variables(SCIP * scip, mip_vars & mvars)
{
  SCIP_Var ** v = mvars.data();
  int size = mvars.size();
  for (int k = 0;  k < size; k++)
    SCIPreleaseVar(scip, &v[k]);
}

// This procedure prints one of the trees to be merged as diagnostic
// output for troubleshooting.
// - tree -- the input tree
// - name -- the label, which takes values 'a' or 'b'
static void display_tree(graph * tree, string name)
{
  int size = tree->list_of_nodes.size();
  list<node*>::iterator start = tree->list_of_nodes.begin();
  list<node*>::iterator finish = tree->list_of_nodes.end();

  int precision = cout.precision();
  cout.precision(17);

  cout << "\n";
  cout << "# name:  freq" << name << "\n";
  cout << "# type:  matrix\n";
  cout << "# rows:  " << size << "\n";
  cout << "# columns:  1\n";
  for ( ; start != finish;  ++start) {
    cout << (*start)->frequency << "\n";
  }
  cout << "\n" << endl;

  // 'nnz' is the number of edges.
  int nnz = 0;
  for (int j = 0;  j < size;  j++) {
    for (int i = 0;  i < size;  i++) {
      if(tree->table_of_edges[i][j] != NULL)
        ++nnz;
    }
  }
  cout << "# name:  weights" << name << "\n";
  cout << "# type:  sparse matrix\n";
  cout << "# nnz:  " << nnz << "\n";
  cout << "# rows:  " << size << "\n";
  cout << "# columns:  " << size << "\n";
  for (int j = 0;  j < size;  j++) {
    for (int i = 0;  i < size;  i++) {
      if(tree->table_of_edges[i][j] != NULL) {
    cout << i + 1 << " " << j + 1 << " "
             << tree->table_of_edges[i][j]->weight << "\n";
      }
    }
  }
  cout << "\n" << endl;

  cout.precision(precision);
}


// In "2.7. Merging trees across assays", "Let A and B be two trees
// given as input to the merging algorithm. We number the nodes of each
// tree in topological order and use the variable i to represent the ith
// node of A and j to represent the jth node of B."
// In "2.7. Merging trees across assays", "We first define a merge graph
// G = (V,E) where V = V_A x V_B and E =
// {((u_A,w_B),(v_A,w_B))|(u_A,v_A} \in E_A} \cup
// {((w_A,u_B),(w_A,v_B))|(u_B,v_B) \in E_B}."
// Parameters:
//   graph **ref_joint_tree : a reference to the rooted joint tree T as
//                            G = (V_A x V_B,E_A ^ E_B)
//   graph *tree_A : rooted tree A = (V_A,E_A)
//   graph *tree_B : rooted tree B = (V_B,E_B)
//   string filename : used to write out the integer program solution
//   list<map<string,int> > *ref_list_counts : a list of mappings from
//         probe symbols to probe counts for one sample (patient data file))
// In the corrected formulation, the edge set also includes
// diagonal edges
// {((u_A,v_B),(w_A,z_B))| (u_A, w_A) \in E_A and (v_B,z_B) \in E_B}
// The initial implementations used the glpk library to solve the
// mixed integer program. The current implementation uses SCIP
// (see reference at the top of the file).
// Return:
//   n/a
void merge_trees(graph **ref_joint_tree, edge_counts_type & edge_probs,
                 bool & is_optimal,
                 graph *tree_A, graph *tree_B,
                 string filename, list<map<string,int> > *ref_list_counts)
{
  merge_trees_settings config = get_merge_tree_default_settings();
  if (ALLOW_EXTERNAL_MERGE_CONFIG) {
    read_merge_trees_settings(config);
  }
  if (VERBOSE) {
    cout << "MERGE TREES diagnostics -- 8< --\n";
    cout << "==========\n\n";

    cout << "merge_trees configuration\n";
    print_merge_configuration(cout, config);
    cout << "End merge_trees configuration\n";
    if (0) {
      display_tree(tree_A, "a");
      display_tree(tree_B, "b");
    }
  }
  // Construct a string to label the instance of merging these trees
  string joint_label =
    make_joint_label(tree_A->get_label(), tree_B->get_label());

  // Put the nodes of A and of B into two vectors.
  vec_nodes nodes_A(tree_A->list_of_nodes.begin(),tree_A->list_of_nodes.end());
  vec_nodes nodes_B(tree_B->list_of_nodes.begin(),tree_B->list_of_nodes.end());

  // Initialize the SCIP instance.
  SCIP * scip = initialize_scip();
  if (VERBOSE) {
    SCIP_CALL_ABORT( SCIPsetIntParam(scip, "display/verblevel", 4) );
  } else {
    SCIP_CALL_ABORT( SCIPsetIntParam(scip, "display/verblevel", 0) );
  }
  
  // Construct and initialize the variables for the SCIP instance.
  mip_vars vars(nodes_A.size(), nodes_B.size());
  init_mip_vars(vars, scip);

  // Set up the constraints for the SCIP instance.
  vector<vector<double> > probs;
  vector<double> marginal_rows, marginal_cols;

  count_probs(probs, marginal_rows, marginal_cols, nodes_A, nodes_B,
              ref_list_counts);

  double ploidy_penalty = config.at("ploidy_penalty");
  if (false) {
    if (PLOIDY_CHANGE_PENALTY)
      set_ploidy_change_penalty(scip, vars, nodes_A, nodes_B, ploidy_penalty);
    else
      set_ploidy_penalty(scip, vars, nodes_A, nodes_B, ploidy_penalty);
  }
  double parsimony_penalty = config.at("parsimony_penalty");
  add_parsimony_penalty(scip, vars, nodes_A.size(), nodes_B.size(),
            parsimony_penalty);
  set_ploidy_penalty(scip, vars, nodes_A, nodes_B, ploidy_penalty);

  double nonexistence_penalty = config.at("nonexistence_penalty");
  double existence_penalty = config.at("existence_penalty");
  double mismatch_penalty = config.at("mismatch_penalty");
  double steiner_penalty = config.at("steiner_penalty");
  set_mismatch_penalty(scip, vars, nodes_A, nodes_B,
                       existence_penalty, nonexistence_penalty,
                       mismatch_penalty, steiner_penalty, probs);

  vector<double> weights_a =
    parent_edge_weights(nodes_A, tree_A->table_of_edges);
  vector<double> weights_b =
    parent_edge_weights(nodes_B, tree_B->table_of_edges);

  if (VERBOSE) {
    cout << "parent edge weights a\n";
    cout << as_json(weights_a) << endl;
    cout << "End parent edge weights a\n";
    
    cout << "parent edge weights b\n";
    cout << as_json(weights_b) << endl;
    cout << "End parent edge weights b\n";
  }
  bool use_edge_weights = config.at("use_edge_weights");
  if (use_edge_weights)
    add_edgeweight_cost(scip, vars, weights_a, weights_b);

  create_mip_constraints(scip, vars, nodes_A, nodes_B, probs,
                         marginal_rows, marginal_cols);

  if (VERBOSE) {
    print_mip_to_file(scip, filename, joint_label);
    //write_ploidy_matrices(nodes_A, nodes_B);

    cout << "Entering the MIP solver = will time out after "
         << TIMEOUT << " minutes" << endl << endl ;
  }

  // Call the constructor for the values of the variables.
  mip_vals vals(vars.size_A, vars.size_B);
  int status = solve_using_scip(vals, scip, vars, is_optimal);

  if (status == 0) {
    if (VERBOSE) {
      write_sol(scip, filename, joint_label);
      display_solution(scip, vals);

      cout << "\n==========\n";
      cout << "End MERGE TREES diagnostics -- >8 --\n";
    }

    // Extract the joint tree from the solution to the SCIP instance,
    *ref_joint_tree = read_joint_tree(edge_probs,
                                      nodes_A, tree_A->table_of_edges,
                                      nodes_B, tree_B->table_of_edges,
                                      vals, probs, joint_label);
  } else {
    cerr << "Could not merge the trees. Stopping.\n";
    exit(1);
  }

  free_mip_variables(scip, vars);

  SCIP_CALL_ABORT( SCIPfree(&scip) );
}

// Print a mutation frequency table, as computed by merge_trees().
ostream & operator<<(ostream & ss, const as_mutation_table & mt)
{
  set<string> distinct_chr;

  // Find how many genes participated in this merge.
  edge_counts_type::const_iterator p = mt.edge_counts.begin();
  size_t npairs = mt.edge_counts.size() > 0 ? p->first.size() / 2 : 0;

  // Print distinct gene and chromosome names
  for (size_t k = 0;  k < npairs;  k++) {
    if (k != 0)
      ss << ":";
    const string & chr_name = mt.chr_names[k];
    if (distinct_chr.count(chr_name) == 0) {
      ss << chr_name << ":";
      distinct_chr.insert(chr_name);
    }
    ss << mt.gene_names[k];
  }
  ss << "\tprobability";
  int invalid_count = 0;

  edge_counts_type::const_iterator pend = mt.edge_counts.end();
  for (p = mt.edge_counts.begin();  p != pend;  ++p) {
    const vector<int> & mutation = p->first;
    double count = p->second;
    map<string,int> chr_change;
    stringstream field;
    size_t k;
    for (k = 0;  k < npairs;  k++) {
      if (k != 0)
        field << ":";
      int delta_chr = mutation[2 * k];
      const string & chr_name = mt.chr_names[k];
      if (delta_chr == k_invalid_change) {
        invalid_count += p->second;
        break;
      }
      else if (chr_change.count(chr_name) == 0) {
        field << delta_chr << ":";
        chr_change[chr_name] = delta_chr;
      }
      else if(chr_change[chr_name] != delta_chr) {
        // The change for this chromosome mismatches an early change for the
        // same, chromosome: add these edges to the invalid edges
        invalid_count += p->second;
        break;
      }
      int delta_gene = mutation[2 * k + 1];
      if (delta_gene == k_ambigous_change) {
        field << "*";
      } else {
        field << delta_gene;
      }
    }
    if (k != npairs)            // these are invalid edges
      continue;
    ss << "\n" << field.str() << "\t\t" << count;
  }
  if (invalid_count > 0)
    ss << "\ninvalid\t\t" << invalid_count;
  return ss;
}

// Given a collection of edge counts, return the log2-based Shannon
// entropy of the edges.
static double edge_entropy2(const edge_counts_type & edge_counts)
{
  double entropy = 0.0;
  edge_counts_type::const_iterator q = edge_counts.begin();
  for ( ; q != edge_counts.end(); ++q) {
    double p = q->second;
    if (p != 0)
      entropy -= p * log2(p);
  }
  return entropy;
}

// A structure for representing gene-tree pairs, so that the pairs
// may be reordered together.
struct gene_tree {
  string gene;
  graph * tree;
  bool operator<(const gene_tree & b) const { return this->gene < b.gene; }
};

typedef vector<gene_tree> vec_gene_tree;

// Create a vector of 'struct gene_tree' from equally sized vectors of
// genes and of trees.
static vec_gene_tree
make_sorted_gene_tree_pairs(const vec_names & genes,
                            const vector<graph*> & trees)
{
  assert( genes.size() == trees.size() );
  vec_gene_tree gene_trees(genes.size());
  for (size_t k = 0;  k < gene_trees.size();  k++) {
    gene_trees[k].tree = trees[k];
    gene_trees[k].gene = genes[k];
  }
  sort(gene_trees.begin(), gene_trees.end());

  return gene_trees;
}

// Delete a tree and its nodes, without deleting the children of joint nodes.
static void shallow_delete_tree(graph * gr)
{
  if (gr) {
    gr->shallow_delete_nodes();
    delete gr;
  }
}


// Rotate the trees so that [*start, ..., *finish] becomes [*finish,
// *start, ..., *(finish - 1)].  Note that the range is *inclusive*
// (perhaps is shouldn't be...not sure).
static void rotate_gene_trees(vec_gene_tree::iterator start,
                              vec_gene_tree::iterator finish)
{
  if (finish != start) {
    gene_tree temp = *finish;
    copy_backward(start, finish, finish + 1);
    *start = temp;
  }
}


// Reorder genes so that top.first becomes gene 0 and top.second
// becomes gene 1.
static void
reorder_genes01(vec_gene_tree & gene_trees, pair<size_t, size_t> top)
{
  rotate_gene_trees(gene_trees.begin() + 0, gene_trees.begin() + top.first);
  rotate_gene_trees(gene_trees.begin() + 1, gene_trees.begin() + top.second);
}

// Join the tree 'left' with all the trees in the interval [right,
// end_right). Return a tree of smallest weight.
static size_t
find_best_merge_partner(graph *& joint_tree,
                        double & weight,
                        bool   & is_optimal,
                        graph * left,
                        vec_gene_tree::const_iterator right,
                        vec_gene_tree::const_iterator end_right,
                        const string & filename,
                        list<map<string,int> > *ref_list_counts)
{
  // Record the best weight, and the indices that produced it for
  // a) suboptimal and b) optimal merges;
  enum { suboptimal = 0, optimal = 1 };

  graph * best_joint_tree[2] = { 0, 0 };
  int     best_partner[2]    = { 0, 0 };
  double  best_weight[2]     = { -1.0, -1.0 };

  int num_right = end_right - right;
  for (int j = 0;  j < num_right;  j++) {
    graph * this_joint_tree = 0;
    edge_counts_type edge_counts;
    bool is_opt;

    merge_trees(&this_joint_tree,    edge_counts, is_opt,
                left, right[j].tree, filename,    ref_list_counts);

    int number_of_edges = this_joint_tree->get_number_of_nodes() - 1;
    double this_weight  = number_of_edges * edge_entropy2(edge_counts);

    if (best_weight[is_opt] < 0 || this_weight < best_weight[is_opt]) {
      std::swap(best_joint_tree[is_opt], this_joint_tree);

      best_weight[is_opt]  = this_weight;
      best_partner[is_opt] = j;
    }
    shallow_delete_tree(this_joint_tree);
  }
  is_optimal = best_weight[optimal] >= 0;
  weight     = best_weight[is_optimal];
  joint_tree = best_joint_tree[is_optimal];

  assert(best_weight[is_optimal] >= 0);
  shallow_delete_tree(best_joint_tree[!is_optimal]);

  return best_partner[is_optimal];
}


// Choose the pair of genes that, when merged, produce a
// minimum-weight tree.  All n * (n - 1) / 2 pairings are tried,
// although in only one of the two possible orders. (In theory the
// merge is symmetric, but a real-life MIP solver is used to do the
// merge.)
//
// To reduce dependence on the input order, the indices in the
// returned pair are given in *alphabetically by gene*, and in case of
// ties between pairs the lexicographically least is used.
static pair<size_t, size_t>
choose_optimal_merge_pair(const vec_gene_tree & gene_trees,
                          const string & filename,
                          list<map<string,int> > *ref_list_counts)
{
  // Record the best weight, and the indices that produced it for
  // a) suboptimal and b) optimal merges;
  enum { suboptimal = 0, optimal = 1 };

  pair<size_t,size_t> best[2]        = {};
  double              best_weight[2] = {-1.0, -1.0}; // treated as infinity

  for (size_t i = 0;  i < gene_trees.size() - 1;  i++) {
    graph * joint_tree = 0;
    double weight;
    bool is_optimal;
    size_t best_partner =
      find_best_merge_partner(joint_tree, weight, is_optimal,
                              gene_trees[i].tree,
                              gene_trees.begin() + i + 1,
                              gene_trees.end(),
                              filename, ref_list_counts);
    best_partner += i + 1;

    if (best_weight[is_optimal] < 0.0 || weight < best_weight[is_optimal]) {
      best[is_optimal].first  = i;
      best[is_optimal].second = best_partner;
      best_weight[is_optimal] = weight;
    }
    shallow_delete_tree(joint_tree);
  }
  if (best_weight[optimal] >= 0) {
    return best[optimal];
  }
  else {
    assert(best_weight[suboptimal] >= 0);
    return best[suboptimal];
  }
}


// Merge a vector of trees, reordering heuristically to get a
// low-weight tree.  Return the resulting merged tree.  The input
// parameters are *not* reordered; the correct order may/must be
// inferred from the merged tree.
graph *
reorder_and_merge_trees(const vec_names & genes_orig,
                        const vector<graph*> & trees_orig,
                        const string & filename,
                        list<map<string,int> > *cnts)
{
  vec_gene_tree gene_trees =
    make_sorted_gene_tree_pairs(genes_orig, trees_orig);

  reorder_genes01(gene_trees,
                  choose_optimal_merge_pair(gene_trees, filename, cnts));

  if (VERBOSE) {
    cout << "Choosing ";
    cout << gene_trees[0].gene << " and " << gene_trees[1].gene << endl;
  }

  // The first joint tree is gene_trees[0].tree.
  graph * joint_tree = gene_trees[0].tree;
  for (size_t i = 0;  i < gene_trees.size() - 1;  i++) {
    graph * old_joint_tree = joint_tree;
    double weight;
    bool is_optimal;
    size_t best =
      find_best_merge_partner(joint_tree, weight, is_optimal, old_joint_tree,
                              gene_trees.begin() + i + 1, gene_trees.end(),
                              filename, cnts);
    best += i + 1;

    if (VERBOSE) {
      cout << " and then " << gene_trees[best].gene
           << " for round " << i + 1
           << " weight " << weight
           << " optimal " << (int) is_optimal << endl;
    }
    if (i != 0)
      delete old_joint_tree;  // but *not* its nodes; these are shared

    rotate_gene_trees(gene_trees.begin() + i + 1, gene_trees.begin() + best);
  }
  if (VERBOSE) {
      cout << "Reordered genes:";
      for (size_t k = 0;  k < gene_trees.size();  k++)
        cout << " " << gene_trees[k].gene;
      cout << endl;
  }
  return joint_tree;
}
