#include <iomanip>

#include "obs_graph.h"

using namespace std;

// Set possible tumourigenesis states as nodes based on current copy
// numbers of chromosome (or ploidy) and gene probe.
void obs_graph::set_possible_children(int chr, int gene)
{
  obs_graph::children_t & kids = children[chr][gene];

  // Check if number of chromosome (or ploidy) is at least MIN_CHR_COPY.
  if (chr >= MIN_CHR_COPY)
  {
    // Check if number of chromosome (or ploidy) is more than MIN_CHR_COPY.
    if (chr > MIN_CHR_COPY)
    {
      // Check if monotonic change of number of chromosome (or ploidy)
      // is required.
      if ((MONO_CHR == 0) || ((MONO_CHR == 1) && (chr <= NORMAL_COPY)))
      {
        // Check if number of gene probe is more than 0.
        if (!GENE_PROBES_ONLY && (gene > 0))
        {
          // Chromosome (or ploidy) loss with gene loss (i.e. CHR_GENE_LOSS).
          kids[CHR_GENE_LOSS] = obs_graph::node(chr - 1, gene - 1);
        }

        // Chromosome (or ploidy) loss without gene loss (i.e. CHR_LOSS).
        kids[CHR_LOSS] = obs_graph::node(chr - 1, gene);
      }
    }

    // Check if number of gene probe is more than 0.
    if (gene > 0)
    {
      // Gene loss only (i.e. GENE_LOSS).
      kids[GENE_LOSS] = obs_graph::node(chr, gene - 1);

      // Check if number of gene probe is fewer than MAX_COPY.
      if (gene < MAX_COPY)
      {
        // Gene gain only (i.e. GENE_GAIN).
        kids[GENE_GAIN] = obs_graph::node(chr, gene + 1);
      }
    }

    // Check if number of chromosome (or ploidy) is fewer than MAX_COPY.
    if (chr < MAX_COPY)
    {
      // Check if monotonic change of number of chromosome (or ploidy)
      // is required.
      if ((MONO_CHR == 0) || ((MONO_CHR == 1) && (chr >= NORMAL_COPY)))
      {
        // Chromosome (or ploidy) gain without gene gain (i.e. CHR_GAIN).
        kids[CHR_GAIN] = obs_graph::node(chr + 1, gene);

        // Check if number of gene probe is more than 0 and fewer than MAX_COPY.
        if (!GENE_PROBES_ONLY && (gene > 0) && (gene < MAX_COPY))
        {
          // Chromosome (or ploidy) gain with gene gain (i.e. CHR_GENE_GAIN).
          kids[CHR_GENE_GAIN] = obs_graph::node(chr + 1, gene + 1);
        }
      }
    }

    // Check if duplication is permitted.
    if ((CHR_GENE_DUPL < MUTATION_TYPES) && ((chr > 1) || (gene > 1)) &&
      ((chr * 2) <= MAX_COPY) && ((gene * 2) <= MAX_COPY))
    {
      // Chromosome (or ploidy) with gene duplication (i.e. CHR_GENE_DUPL),
      // skipping equivalent cases for CHR_GAIN and CHR_GENE_GAIN.
      kids[CHR_GENE_DUPL] = obs_graph::node(chr * 2, gene * 2);
    }
  }
}


obs_graph::obs_graph(int_matrix cell_count) :
  frequencies(), children()
{
  // Loop through every copy number of chromosome probe.
  for (int chr = 0; chr <= MAX_COPY; chr++) {
    // Loop through every copy number of gene probe.
    for (int gene = 0; gene <= MAX_COPY; gene++) {
      set_possible_children(chr, gene);
    }
  }
  // Loop through every possible copy number of chromosome probe.
  for (int index_chr = 0; index_chr <= MAX_COPY; index_chr++) {
    // Loop through every possible copy number of gene probe.
    for (int index_gene = 0; index_gene <= MAX_COPY; index_gene++) {
      // Reset input node frequencies to cell counts.
      frequencies[index_chr][index_gene] =
        (double)cell_count[index_chr][index_gene];
    }
  }
}


std::ostream &operator<<(std::ostream &output, const obs_graph::node &node0)
{
  output << "(" << node0.chr << "," << node0.gene << ")";
  return output;
}


// Return all edges in possible_graph that start at an node in
// current_candidates but do not end in a node in visited.
obs_graph::vec_edge
obs_graph::find_frontier_edges(const node_set & current_candidates,
                               const node_set & visited) const
{
  vec_edge new_edges;

  node_set::iterator node = current_candidates.begin();
  for ( ; node != current_candidates.end(); ++node) {
    const children_t & children = this->get_children(*node);
    children_t::const_iterator chld;

    for (chld = children.begin();  chld != children.end();  ++chld) {
      if (!visited.count(chld->second)) {
        new_edges.push_back(edge(*node, chld->second, chld->first));
      }
    }
  }
  return new_edges;
}


// Return all target nodes reachable from root (unconditionally
// including root).
obs_graph::node_set
obs_graph::explore_island(const node & root,
                          const node_set & target_nodes) const
{
  node_set island;
  island.insert(root);

  vector<node> pending(1, root);

  // Do a depth first search to find the set of formerly target_nodes
  // nodes that will become reachable if this node is added.
  while (!pending.empty()) {
    node node = pending.back();
    pending.pop_back();

    const children_t & children = this->get_children(node);
    children_t::const_iterator chld;

    for (chld = children.begin();  chld != children.end();  ++chld) {

      if (target_nodes.count(chld->second) && !island.count(chld->second)) {
        // Node is a target_node, and not already part of the island
        pending.push_back(chld->second);
        island.insert(chld->second);
      }
    }
  }
  return island;
}


ostream &
operator<<(ostream & output, const obs_graph::path & path)
{
  if (path.size() == 0)
    return output << "<empty_path>";

  for (size_t j = 0;  j < path.size();  j++)
    output << path[j].tail << "<-";

  return output << path.back().head;
}


std::ostream &operator<<(std::ostream &output,
                         const obs_graph::vec_path & paths)
{
  for (size_t i = 0;  i < paths.size();  ++i) {
    if (i != 0)
      output << endl;

    output << setw(3) << i + 1 << " " << paths[i];
  }
  return output;
}
