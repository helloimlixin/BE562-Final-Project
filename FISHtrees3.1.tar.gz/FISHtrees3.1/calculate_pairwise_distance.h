#ifndef CALCULATE_PAIRWISE_DISTANCE_H
#define CALCULATE_PAIRWISE_DISTANCE_H

#include <vector>

// The purpose of the functions in this file is to generate
// the shortest distance between two points when the possible
// events are
// a) single gene gain or loss
// or
// b) genome duplication
void check_num_nodes(int );
void get_min_dist(int [],int [],int);
int is_even_state(int [],int);
void gen_neighbor(std::vector<std::vector<int> > &,int [],int,int*,int&);
int* dec2bin(int,int);
int l1(int [],int [],int);
int calculate_pairwise_distance(int [],int [],int, int, int**, int*);
int member(int**,int [],int ,int );
int dist_chromosome_doubling(int [],int [],int);
int l1_CD(int [],int [],int** ,int ,int );

#endif
