// In "2.3. Optimal tree inference", "In order to ensure that every
// state in G is reachable from the root (defined as the (2,2) state),
// we then add Steiner nodes with a heuristic method presented as
// Algorithm 1. These Steiner nodes are inferred to be states that were
// present at one point in the evolution of the tumor but either died
// off or were missed during data collection due to inadequate sampling".
// "Algorithm 1 Heuristic algorithm for Steiner node inference
// 1: Given G = (V,E). Let G' = (V',E') be a directed graph of all
//    possible states and edges, and let R \subseteq V be the set of
//    vertices of G reachable from the root.
// 2: while R \neq V do
// 3:   Perform a breadth-first traversal of G' starting from R and
//      stopping when we encounter a vertex v \in V - R. Let k be the
//      distance from R to v (the length of the path found by BFS).
// 4:   Consider all nodes in V - R at distance k from R, and let v* be
//      the one from which we can reach the most nodes in V - R (the
//      largest island).
// 5:   Solve the multiple source shortest path problem from R to v* in
//      G', where the weight of an edge e \in E' is equal to -log p_e
//      (minus the log of its probability).
// 6:   Add the nodes and edges on the shortest path from V to v* in G.
// 7: end while".

#include <algorithm>
#include <iomanip>
#include <queue>

#include <cfloat>
#include <cmath>
#include <cassert>

using namespace std;

#include "steiner.h"

static obs_graph::vec_edge
find_candidate_edges(const obs_graph &, obs_graph::node_set,
                     const obs_graph::node_set &);

static obs_graph::path
choose_optimal_path(const obs_graph::vec_edge & edges,
                    double_vector edge_weights,
                    const obs_graph::node_set & reachable);

static void
calc_edge_weights(double_vector edge_weights, double_vector mutation_prob);


// In "2.3. Optimal tree inference", "Algorithm 1 Heuristic algorithm
// for Steiner node inference".
// - graph corresponds to G in the paper
// - pg corresponds to G' in the paper
void
perform_steiner_node_inference(graph *graph,
                               const string & name_chr,
                               const string & name_gene,
                               obs_graph & pg,
                               double_vector mutation_prob,
                               list<map<string,int> > *list_counts)
{
  double_vector edge_weights;
  calc_edge_weights(edge_weights, mutation_prob);

  // Find nodes in G that are reachable from root (in R) or not reachable
  // from root (in V - R).
  obs_graph::node_set reachable, unreachable;
  for (graph->get_dual_nodes(reachable, unreachable);
       !unreachable.empty();
       graph->get_dual_nodes(reachable, unreachable)) {

    // Find edges in G' from a candidate Steiner node to a node in V - R.
    obs_graph::vec_edge candidate_edges =
      find_candidate_edges(pg, reachable, unreachable);

    // The lowest weight path from one of the candidate Steiner nodes
    // to V (the weight of the edge to the island is included).
    obs_graph::path lightest_path =
      choose_optimal_path(candidate_edges, edge_weights, reachable);

    cout << "Inserted Steiner node(s) =";

    // Set the frequency of each previously-unobserved (Steiner) node
    // on the lowest weight path to be 1.0, allowing *all* edges to the
    // new nodes to be used when the graph is rebuilt.
    obs_graph::vec_edge::iterator edge;
    for (edge = lightest_path.begin(); edge != lightest_path.end(); ++edge) {
      // Only the 'head' edges can be previously unobserved.
      assert(pg.get_freq(edge->head) < DBL_EPSILON);

      pg.set_freq(edge->head, 1.0);

      cout << " " << edge->head;
    }
    cout << endl;

    // Rebuild input graph.
    graph->deep_delete_nodes();
    graph->set_nodes_and_edges(name_chr, name_gene, pg, list_counts);
  }
}


// Calculate the weight of a step of the given type, i.e. -log(p),
// with very small p returning the large, but far less than
// infinite, value 'kbig_pathweight'.
static void
calc_edge_weights(double_vector edge_weights, double_vector mutation_prob)
{
  const double kbig_pathweight = 1e6;

  for (int k = 0;  k < MUTATION_TYPES;  k++) {
    double prob = mutation_prob[k];

    edge_weights[k] = prob >= DBL_EPSILON ? -log(prob) : kbig_pathweight;
  }
}


// Predicate that tests whether the tail of an edge is in a certain
// node set.
struct tail_not_in {
  const obs_graph::node_set & ns;

  explicit tail_not_in(const obs_graph::node_set & n) : ns(n) {}
  bool operator()(const obs_graph::edge & e) {
    return ns.count(e.tail) == 0;
  }
};


// In "2.3. Optimal tree inference", "Consider all nodes in V - R at
// distance k from R, and let v* be the one from which we can reach
// the most nodes in V - R (the largest island)".
//
// An island consists of an island root node, which is a candidate
// Steiner node, and all nodes in target_nodes (V - R) that are
// connected to the candidate Steiner node by a directed path with
// edges in G'.  In other words, all nodes that become reachable if
// the candidate Steiner node is added, including the Steiner node
// itself.
//
// On entry, parameter "island_edges" contain all edges leading from a
// candidate Steiner node into the set of nodes currently unreachable.
// On exit, it contains exactly those edges that lead to an island of
// largest size.  There is likely to be more than one largest island
// (because more than one candidate root node leads to the same
// connected set of target nodes) and more than one edge from any
// particular candidate Steiner node into an island.

static void
keep_largest_islands(obs_graph::vec_edge & island_edges,
                     const obs_graph & pg,
                     const obs_graph::node_set & target_nodes)
{
  obs_graph::vec_edge::const_iterator edge;

  // Determine the set of candidate root nodes of islands.
  obs_graph::node_set island_roots;
  for (edge = island_edges.begin();  edge != island_edges.end();  ++edge)
    island_roots.insert(edge->tail);

  size_t largest_island_size = 0;     // Size of the largest island seen
  // root nodes leading to islands of the largest size
  obs_graph::node_set largest_island_roots;

  obs_graph::node_set::const_iterator root;
  for (root = island_roots.begin();  root != island_roots.end();  ++root)  {
    // For each root, find the corresponding island.
    obs_graph::node_set island = pg.explore_island(*root, target_nodes);

    // Keep the root of all islands of largest size.
    if (island.size() > largest_island_size) {
      largest_island_size = island.size();
      largest_island_roots.clear();
      largest_island_roots.insert(*root);
    } else if (island.size() == largest_island_size) {
      largest_island_roots.insert(*root);
    }
  }
  // Keep all edges from island_edges into the islands of largest size.
  island_edges.erase(remove_if(island_edges.begin(), island_edges.end(),
                               tail_not_in(island_roots)),
                     island_edges.end());
}


// In "2.3. Optimal tree inference", "Perform a breadth-first traversal of
// G' starting from R and stopping when we encounter a vertex v \in V - R.
// Let k be the distance from R to v (the length of the path found by BFS)".
// - pg is G'
// - visited - the set of nodes already visited
// - targets is the nodes of V - R
obs_graph::vec_edge
find_candidate_edges(const obs_graph & pg, obs_graph::node_set visited,
                     const obs_graph::node_set & targets)
{
  obs_graph::vec_edge::const_iterator edge;
  obs_graph::vec_edge island_edges;

  obs_graph::node_set candidates = visited;
  do {
    obs_graph::vec_edge new_edges =
        pg.find_frontier_edges(candidates, visited);
    assert(!new_edges.empty());

    candidates.clear();  // Generate the next set of candidates.
    for (edge = new_edges.begin();  edge != new_edges.end(); ++edge) {
      candidates.insert(edge->head);
      visited.insert(edge->head);
      if (targets.count(edge->head)) {
        // This edge, if followed, allows us to reach a target node.
        island_edges.push_back(*edge);
      }
    }
  } while (island_edges.empty());

  keep_largest_islands(island_edges, pg, targets);

  return island_edges;
}


// Create the type traceback_map, mapping obs_graph::nodes to an
// object of type traceback_mapped_type, which will represent the
// weight of the lowest weight (yet found) path to the node and the
// parent node along the type.
//
// First define traceback_mapped_type (will be equivalent to
// traceback_map::mapped_type)
struct traceback_mapped_type {
  // Actual type of field 'node' will be traceback_map::value_type, but
  // as far as I know there is no way to forward-declare that type.
  void * node;
  double weight;
  mutation_type mtype;

  traceback_mapped_type() : node(), weight(), mtype() {}
  traceback_mapped_type(void * n, double w, mutation_type t) :
    node(n), weight(w), mtype(t) {}
};


typedef map<obs_graph::node, traceback_mapped_type> traceback_map;
typedef traceback_map::value_type traceback_node;

// Return the traceback_node that is the parent of this one along the
// (as yet) lowest weight path.
inline traceback_node * tb_node_parent(const traceback_node & tn)
{
  return static_cast<traceback_node*>(tn.second.node);
}


// Return the weight of the lowest weight (yet found) path terminating in
// the traceback_node 'tn'.
inline double tb_node_weight(const traceback_node & tn)
{
  return tn.second.weight;
}


// Return the type of the lowest weight (yet found) path terminating in
// the traceback_node 'tn'.
inline mutation_type tb_node_type(const traceback_node & tn)
{
  return tn.second.mtype;
}


// A node in the priority queue (to be typedef'd below) path_priority.
struct path_priority_node {
  traceback_node * tb_node;
  double weight;

  path_priority_node(): tb_node(), weight() {}
  explicit path_priority_node(traceback_map::iterator & w) :
    tb_node(&(*w)), weight(tb_node_weight(*w)) {}

  bool operator>(const path_priority_node & other) const
  {
    return
      other.weight < weight ||
        (other.weight == weight && other.tb_node->first < tb_node->first);
  }
};


// A priority queue representing the lowest weight paths seen so far.
typedef priority_queue<path_priority_node,
                       vector<path_priority_node>,
                       greater<path_priority_node> > path_priority;

// A node with an associated weight.
typedef pair<obs_graph::node, double> weighted_node;

// Insert the starting node (which has no parent and a necessarily
// INVALID edge to the nonexistant parent) into the traceback and
// path_priority queue.
static void
path_priority_insert_start(path_priority & pq, traceback_map & tb,
                           const weighted_node & wn)
{
  traceback_map::iterator ww =
    tb.insert(tb.end(),
              make_pair(wn.first,
                        traceback_mapped_type(NULL,
                                              wn.second, INVALID)));
  pq.push(path_priority_node(ww));
}


// If 'new_node' has not yet been seen (i.e. is not in 'tb'), or has
// been seen but found via a path with larger weight, add an entry to
// 'pq' representing the path of current best weight, and update 'tb'
// to reflect the new best path to 'new_node'.
//
// Inserting a node in 'pq' in this manner may result in multiple 'pq'
// entries for 'new_node', but only the lowest-weight entry will be used
// by find_optimal_path().

static void
path_pq_update_path(path_priority & pq, traceback_map & tb,
                    obs_graph::node & new_node,
                    traceback_mapped_type & new_path)
{
  traceback_map::iterator ww = tb.lower_bound(new_node);

  if (ww == tb.end() || ww->first != new_node) {
    // no previous path to new_node
    ww = tb.insert(ww, make_pair(new_node, new_path));
  } else if (new_path.weight < tb_node_weight(*ww)) {
    ww->second = new_path;      // previous path to new_node not optimal
  } else {                      // Keep previous (better) path.
    return;
  }
  pq.push(path_priority_node(ww));
}


// graph_step_table (to be defined below) is an array of 'GRAPH_STEP_TYPES'
// instances of 'struct graph_step', representing all possible directed
// edges between two nodes in the graph.
struct graph_step {
  mutation_type type;
  int dchr, dgene; // change in chromosome and gene count
};


#define GRAPH_STEP_TYPES  7
// Not all types of step need be used (indeed MUTATION_TYPES may be 6),
// but there must be a step type for every mutation type.
#if GRAPH_STEP_TYPES < MUTATION_TYPES
#error "Failed static assertion GRAPH_STEP_TYPES >= MUTATION_TYPES"
#endif

const graph_step graph_step_table[GRAPH_STEP_TYPES] = {
  { CHR_GENE_LOSS, -1,   -1 },  // chromosome with gene loss
  { CHR_LOSS,      -1,    0},   // chromosome loss
  { GENE_LOSS,      0,   -1},   // gene loss
  { GENE_GAIN,      0,    1},   // gene gain
  { CHR_GAIN,       1,    0},   // chromosome gain
  { CHR_GENE_GAIN,  1,    1},   // chromosome with gene gain
  { CHR_GENE_DUPL,  2,    2} }; // chromosome with gene duplication


// Try to take a step to a parent node by following the step
// graph_step_table[step_index].  Steps from *child* to *parent*, so
// parent to child gains become child to parent losses, and vice
// versa.
//
// Return true if the step can be taken, false if it is forbidden.
static bool
try_step_to_parent(obs_graph::node & new_node,
                   traceback_mapped_type & new_path,
                   traceback_node * old_path,
                   double_vector edge_weights, int step_index)
{
  mutation_type new_kind = graph_step_table[step_index].type;
  int dgene = graph_step_table[step_index].dgene;
  int dchr = graph_step_table[step_index].dchr;

  const obs_graph::node & old_node = old_path->first;
  // If MUTATION_TYPES < 7, the new_kind cannot equal CHR_GENE_DUPL,
  // so the compiler may optimize away this branch.
  int chr, gene;
  if (MUTATION_TYPES < 7 || new_kind != CHR_GENE_DUPL) {
    chr = old_node.chr - dchr;
    gene = old_node.gene - dgene;
  } else if (old_node.chr % 2 == 0 && old_node.gene % 2 == 0) {
    chr = old_node.chr / 2;
    gene = old_node.gene / 2;
  } else {                // requested a duplication, but odd copy number
    return false;
  }

  if (MONO_CHR && new_kind != CHR_GENE_DUPL &&
      ((chr > NORMAL_COPY && dchr < 0) || (chr < NORMAL_COPY && dchr > 0))) {
    return false; // nonmontonic chromosome change
  } else if (chr < 0 || chr > MAX_COPY || gene < 0 || gene > MAX_COPY) {
    return false; // impossible copy number
  } else if ((chr == 0 && dchr != 0) || (gene == 0 && dgene != 0)) {
    return false; // cannot gain or lose once count is zero
  } else {
    new_node.chr = chr;
    new_node.gene = gene;
    new_path.mtype = new_kind;
    new_path.weight = tb_node_weight(*old_path) + edge_weights[new_kind];
    new_path.node = old_path;

    return true;
  }
}


// Check all *backwards* edges (from child to parent) between
// best_path and another node in the graph.  If the result is a shorter
// path to the parent node, update the parent node's traceback entry
// and place in the path_priority queue.
static void
update_parent_paths(traceback_map & tb, path_priority & pq,
                    traceback_node * best_path,
                    double_vector edge_weights)
{
  // Loop over MUTATION_TYPES (not GRAPH_STEP_TYPES as not all step
  // types need be used).
  for (int type = 0;  type < MUTATION_TYPES;  type++) {
    obs_graph::node parent;
    traceback_mapped_type new_path;

    if (try_step_to_parent(parent, new_path, best_path, edge_weights, type))
      path_pq_update_path(pq, tb, parent, new_path);
  }
}


// Read an optimal path from a node in a traceback_map.
static obs_graph::path read_traceback(traceback_node * tb_node)
{
  obs_graph::path optimal_path;

  traceback_node * parent;
  while((parent = tb_node_parent(*tb_node))) {
    optimal_path.push_back(obs_graph::edge(tb_node->first, parent->first,
                                           tb_node_type(*tb_node)));
    tb_node = parent;
  }
  return optimal_path;
}

// Find the optimal path between 'start_node' and some node in 'targets'
// using Dijkstra's algorithm.  The path is traversed *backwards* from
// child to parent.
//
// best_weight [output] - the weight of the optimal path
// start_node - the start of the path
// start_weight - a constant added to the weight of the optimal path
//      (may be zero)
// edge_weights - weight associated with a mutation of the
//       specified type
// targets - admissible end points for the optimal path
// iterations - the number points considered by the Algorithm; used
//       for diagnostics in the calling code
static obs_graph::path
find_optimal_path(double & best_weight, const weighted_node & start,
                  double_vector edge_weights,
                  const obs_graph::node_set & targets, int & iterations)
{
  traceback_map tb;
  path_priority pq;

  iterations = 0;

  path_priority_insert_start(pq, tb, start);
  traceback_node * best_path = pq.top().tb_node;

  while (!pq.empty()) {
    traceback_node * path = pq.top().tb_node;
    double top_weight = pq.top().weight;

    pq.pop();

    if (tb_node_weight(*path) == top_weight) {
      // The weight of the entry in pq is the same as the weight of 'path'.
      // Otherwise, path was already visited when an item with lower
      // weight was the top of the pq, and we would skip this entry.
      best_path = path;

      iterations++;

      if (targets.count(best_path->first))
          break;

      update_parent_paths(tb, pq, best_path, edge_weights);
    }
  }
  best_weight = tb_node_weight(*best_path);

  return read_traceback(best_path);
}

// predicate that is true if weighted nodes are equal as unweighted nodes
struct same_unweighted_node {
  bool operator()(const weighted_node & a, const weighted_node & b)
  {
    return a.first == b.first;
  }
};


// Collect the candidate Steiner nodes and the weight of the lowest
// weighted *forward* edge between each candidate and a previously
// unreachable node.
static vector<weighted_node>
find_starting_nodes(const obs_graph::vec_edge & island_edges,
                    double_vector edge_weights)
{
  vector<weighted_node> vn;

  obs_graph::vec_edge::const_iterator edge;
  for (edge = island_edges.begin();  edge != island_edges.end();  ++edge) {
    vn.push_back(make_pair(edge->tail, edge_weights[edge->type]));
  }
  sort(vn.begin(), vn.end());

  // Remove all but the first (lowest weighted) reference to each node.
  vn.erase(unique(vn.begin(), vn.end(), same_unweighted_node()), vn.end());

  return vn;
}


// In "2.3. Optimal tree inference", "Solve the multiple source shortest
// path problem from R to v* in G', where the weight of an edge e \in E'
// is equal to -log p_e (minus the log of its probability)".
//
// In contrast to what is written in the paper, there may be (and in
// practice often are) several v*_i that are the same distance
// from R, and have an edge that connects them to a previously
// unreachable island of maximal size. There are also often several
// islands of maximal size.

static obs_graph::path
choose_optimal_path(const obs_graph::vec_edge & edges,
                    double_vector edge_weights,
                    const obs_graph::node_set & reachable)
{
  const bool verbose = false;

  assert(MUTATION_TYPES == 6 || MUTATION_TYPES == 7);

  vector<weighted_node> nodes = find_starting_nodes(edges, edge_weights);

  // Calculate the optimal path for each candidate Steiner node *backwards*
  // into the reachable set.  Save the best path (so far) in 'best_path'
  // and the best weight (so far) in 'best_weight'.
  obs_graph::path best_path;
  double best_weight = DBL_MAX;
  for (size_t k = 0;   k < nodes.size();  k++) {
    int iterations;
    double path_weight;
    obs_graph::path this_path =
      find_optimal_path(path_weight, nodes[k], edge_weights,
                        reachable, iterations);

    if (verbose) {
      cout << setw(3) << k + 1 << " " << this_path
           << " " << path_weight << "(-" << nodes[k].second << ")"
           << " __dijkstra_so_far(" << iterations
           << (path_weight < best_weight ? ")*" : ")") << endl;
    }
    if (k == 0 || path_weight < best_weight) {
      best_weight = path_weight;
      swap(this_path, best_path);
    }
  }
  return best_path;
}
