// In "2.3. Optimal tree inference", "finding minimum weight directed
// spanning trees (arborescences) due to Chu and Liu".
// This implementation is due to Karp and ported from the oncotrees
// package implemented by Alejandro A. Sch\"affer.
//
// Karp R. M.: A simple derivation of Edmonds' algorithm for optimum
// branchings. Networks 1972, 1:265-272.

#include <cstdio>
#include <cstdlib>
#include <cfloat>

#include "branching.h"
#include "output.h"

using namespace std;

static int entry_times = 0;

////#define WEIGHTS 2
static const bool verbose = false;
////bool verbose = true;
////FILE *ofile;
FILE *ofile = stdout;

/*Given an input graph G, makeGreedyGraph creates a subgraph by choosing,
  at each node, the edge coming into that node of maximum positive
  weight.  If no such edge exists, it leaves the node in question as a
  source.  The greedy graph will be the maximum weight branching whenever
  it is acyclic.*/
/// argument: top
graph *makeGreedyGraph(graph *this_graph)
{
  graph *greedyGraph;  /*graph to be returned */
  //node *v; /*loop variable*/
  edge *parentEdge; /*used in greedy step*/
  edge *newEdge; /*used to create edges of greedyGraph*/

  greedyGraph = new graph(this_graph->get_label());
  greedyGraph->size = this_graph->size;
  greedyGraph->root = this_graph->root;
  greedyGraph->list_of_nodes = this_graph->list_of_nodes;
  /*greedyGraph is on same set of nodes */

  initEdges(greedyGraph);  /*initialize the edges of greedyGraph*/

  // Iterate on list of nodes.
  list<node *>::iterator this_node;

  // Loop through every node as parent node.
  for (this_node = this_graph->list_of_nodes.begin();
       this_node != this_graph->list_of_nodes.end(); ++this_node)
  {
    parentEdge = findHeavyEdge(*this_node,this_graph);
    /*for each node, find highest weight edge*/
    if (parentEdge != NULL)
    {
      newEdge = copyEdge(parentEdge);
      greedyGraph->table_of_edges[newEdge->tail->index][newEdge->head->index] = newEdge;
    }
    /* if parentEdge == NULL, then v is an edge with no parent, so
       it adds no edges to the greedy graph */
  }
  assignParents(greedyGraph); /*sets parent fields to correspond with
                                the edges of the greedy graph*/
  return(greedyGraph);
}

/* weighCycle toggles the 'is_in_cycle' flags of all the vertices of G
   in the same cycle as v, and returns the minimum edgeweight of the cycle */

double weighCycle(node *v, graph *G)
{
  double minWeight, currentWeight; /*lowest edge weight so far, and current
                                     weight*/
  node *w; /*placeholder for a node in the cycle*/

  /*start with weight of edge from parent(v)--> v*/
  minWeight = flowIn(v->parent,v,G);
  ///  v->is_in_cycle = TRUE;
  v->is_in_cycle = true;
  w = v->parent;
  /*go around the cycle backwards, following parent links*/
  while (w != v)
  {
    ///      w->is_in_cycle = TRUE;
    w->is_in_cycle = true;
    currentWeight = flowIn(w->parent,w,G);
    if (currentWeight < minWeight)
      minWeight = currentWeight;
    w = w->parent;
  }
  return(minWeight);
}

/*ancestor returns TRUE if the parental path from v includes w. The
  parental paths are created in the greedy graph, and modified
  throughout the recoverGraph function.  Each cycle should be removed
  by the end of the recovery. numNodes will be passed the number of nodes of
  the graph being tested*/

bool ancestor(node *v, node *w, int numNodes)
{
  node *nptr; /*loop variable*/
  int counter = 1; /*counts number of nodes reached so far, see
                     comment below*/

  if ((v == NULL) || (w == NULL))
  {
    fprintf(stderr,"Ancestor function called on null vertex.\n");
    exit(EXIT_FAILURE);
  }
  if (v == w)
    ///    return(TRUE);
    return(true);
  nptr = v->parent;
  while ((nptr != NULL) && (counter < numNodes))
  {
    if (nptr == v)
      ///       return(FALSE);
      return(false);
    else if (nptr == w)
      ///       return(TRUE);
      return(true);
    nptr = nptr->parent;
    counter++;
  }
  /*If nptr = NULL, or if counter > numNodes, v is not in any cycle. */

  ///  return(FALSE);
  return(false);
}

/*sameCycle returns TRUE if v is an ancestor of w, and vice versa, i.e.
  if v and w are in the same cycle of the greedy graph */

bool sameCycle(node *v, node *w, int numNodes)
{
  return((ancestor(v,w,numNodes)) && (ancestor(w,v,numNodes)));
}

/**
 * The function collapseGraph is called by findHighWeightBranching on
 * the input graph G and the greedyGraph.  It creates a new set of
 * vertices -- including one node for each cycle in greedyGraph, and
 * one node for each vertex in G not in one of the cycles of
 * greedyGraph.
 *
 * For nodes resulting from the collapse of a cycle, we set the field
 * cycle_weight to the weight of the minimum edge on the cycle.  For
 * each new node x, let C_x be the cycle in G collapsing to x if x is
 * a collapsed node, or let C_x be x otherwise.  For each pair of
 * nodes of the collapsed graph, (x, y), collapseGraph adds an arc
 * from x to y if there is any arc from C_x to C_y.  The weight of the
 * new arc is determined by the formula
 *
 *     weight(x,y) = weight(C_x,C_y)  + cycle_weight(y) - flowIn(y).
 *
 * This value represents the increase in weight obtained by adding the
 * edge from C_x to C_y, deleting the edge going into y, and adding
 * the minimum weight edge of the cycle C_x.
 *
 * The function collapseGraph produces a graph which is passed to a
 * recursive call of findHighWeightBranching.  The edges of G fall
 * into three categories:
 *
 * 1) negative- and zero-weight edges are deleted,
 *
 * 2) edges between nodes not in the same cycle of greedyGraph are
 *    represented by an edge between collapsed nodes as described
 *    above, and
 *
 * 3) edges between nodes of the same greedyGraph cycle are collapsed.
 *
 * The minimum weight edge of the cycle has its weight assigned as the
 * 'cycle_weight' field of the collapsed node.
 */

graph *collapseGraph(graph *greedyGraph, graph *G)
{
  int i,j; /*loop indices over nodes in the collapsed graph*/
  node *newNode;
  graph *collapsedGraph;  /*will be collapsed graph*/
  edge *e,*f; /*loop variables*/
  edge *newEdge; /*used to make a new edge */
  double newWeight; /*used for weights of collapsed graph*/
  int counter; /*used to test cycle membership*/

  collapsedGraph = new graph(greedyGraph->get_label());

  // Decide which nodes to collapse -- every node of G must be
  // represented in collapsedGraph.

  // Map nodes in greedyGraph to nodes in collapsedGraph.
  map < node *, node * > cycles;

  // For each node in the greedy graph
  list<node *>::iterator this_node;
  for (this_node = greedyGraph->list_of_nodes.begin();
       this_node != greedyGraph->list_of_nodes.end(); ++this_node)
  {
    if (((*this_node)->is_in_cycle) || ((sink(G,(*this_node))) && (source(G,(*this_node)))))
    {
      /* Skip 'v' and move on to the next node.
       *
       * If v->is_in_cycle, then the current loop has already added a
       * node representing 'v' to 'collapsedGraph', and set the
       * 'is_in_cycle' flag as an effect of calling the weighCycle()
       * routine.  If v is a sink and a source, then it is an isolated
       * vertex, so there is no need to collapse v.
       */
    } else {
      // Add a vertex to collapsedGraph.
      newNode = new node((*this_node)->chr,(*this_node)->gene);
      newNode->old_node = *this_node;

      collapsedGraph->list_of_nodes.push_back(newNode);
      cycles[*this_node] = newNode;

      /* Look up the parent path from v.
       *
       * One of three things will happen:
       * 1) you will return to v;
       * 2) you will reach a node on a cycle; or
       * 3) the path will end at a NULL pointer without hitting 1 or 2.
       *
       * In all three cases, add 'v' to the graph.  If (1), then v is
       * added as the representative of the cycle.  If (2) or (3),
       * then v does not represent a new cycle, but must be added to
       * the graph as a singleton.
       *
       * Testing (1) and (3) is simple. To test (2), we look at
       * is_in_cycle flags, and run a counter to look at number of
       * steps taken along parental path.  If
       *
       *     counter > greedyGraph->size,
       *
       * then this path has a cycle in it (which does not include v).
       */

      node * w = (*this_node)->parent;
      counter = 1;
      // For clarity of the test (w!=(*this_node)), we start a step
      // away from v.
      while ((w != NULL) && (w != (*this_node)) && (!(w->is_in_cycle)) &&
             (counter < greedyGraph->size))
      {
        w = w->parent;
        counter++;
      }
      if (w == (*this_node)) {
        // Assign to newNode->cycle_weight the minimum weight among
        // edges of this cycle, and set the 'is_in_cycle' field of
        // nodes in same cycle as v.
        newNode->cycle_weight = weighCycle((*this_node),greedyGraph);
        // Add all the nodes in this cycle to 'cycles'.
        w = w->parent;
        while (w != (*this_node)) {
          cycles[w] = newNode;
          w = w->parent;
        }
      }
    }
  }

  if (verbose)
  {
    fprintf(ofile,"DEBUG> collapsedGraph size before countNodes = %d.\n",collapsedGraph->size);
  }
  collapsedGraph->size = countNodes(collapsedGraph);
  if (verbose)
  {
    fprintf(ofile,"DEBUG> collapsedGraph size before countNodes = %d.\n",collapsedGraph->size);
  }
  assignIndices(collapsedGraph);
  initEdges(collapsedGraph);
  if (verbose)
  {
    fprintf(ofile,"DEBUG> collapsedGraph after assignIndices and initEdges.\n");
    output_graph_with_node_frequency_and_edge_weight(collapsedGraph);
  }

  /* Add edges to the collapsed graph.
   *
   * Suppose B is the branching on the cycles created by deleting the
   * minimal edge of each cycle.  The weight of an edge e in the
   * collapsed graph represents the increase in the weight of B when e
   * is added, and any cycle at the head of e is altered to keep the
   * branching acyclic.
   *
   * If e = (x,y) Weights are calculated by this method for arc (x,y):
   * if neither x nor y is not in a cycle, the weight is inherited
   * from G.  If either is x or y is in a cycle, then
   *
   *     weight(x,y) = max_{v in C_1,w in C_2} weight(v,w)
   *
   * where
   *
   *     weight(v,w) = oldweight(v,w) - oldweight(w->parent,w) + minwt(C_2).
   */

  for(i = 0; i < G->size; i++) { // For all edges in G
    for( j = 0; j < G->size; j++)
    {
      f = G->table_of_edges[i][j];
      if (NULL != f)
      {
        if (f->weight > -DBL_MAX)
          // Edges with non-positive weights should be ignored.
        {
          node * w = cycles.at(f->tail);
          node * v = cycles.at(f->head);

          // Pointers w and v now reference the nodes in collapsedGraph
          // representing the tail and head of f, respectively.
          if (w != v) {
            // Add an edge in collapsedGraph representing f.
            newWeight = f->weight;
            /* The number 'newWeight' is the increase in the weight of the
             * branching which would be obtained by adding the edge f.
             *
             * To add f, we would be forced to delete the edge of the
             * greedyGraph with head at the head of f, but we would
             * then be able to add the minimum weight edge of the
             * cycle including v-q>old_node.  This adjustment will not
             * change the value of newWeight if the same edge is added
             * and deleted.
             */

            if (v->old_node->is_in_cycle) {
              newWeight += v->cycle_weight - flowIn(f->head->parent,f->head,G);
            }
            // If f already has a copy in the collapsed graph, point e
            // to this edge.  Otherwise, e is NULL.
            e = collapsedGraph->table_of_edges[w->index][v->index];
            if (NULL == e) {
              newEdge = makeEdge(w,v,f,0.0,newWeight,0.0,0);

              delete collapsedGraph->table_of_edges[w->index][v->index];
              collapsedGraph->table_of_edges[w->index][v->index] = newEdge;
            } else {
              /* As nodes collapse, we might see multi-edges.  Ensure
               * that only one edge is created, and that its weight is
               * set to the highest weight of all of the edges that it
               * represents.
               */
              if (newWeight > e->weight)
              {
                e->weight = newWeight;
                e->old_edge = f;
              }
            }
          }
        }
      }
    }
  }
  return(collapsedGraph);
}
/*end of collapseGraph*/

/* recover graph uses branching on collapsed graph and the cycle
   structure of the greedy graph to produce the maximum weight
   branching.  greedyGraph is the greedy graph of G, and
   collapsedBranching is the graph returned by recursive call to
   findHighWeightBranching.  The branching, recoveredGraph, will be on the same
   vertex set as G. For edges, it will have edges corresponding to the
   edges of H, and will have all of the edges of G except one edge
   from each cycle */

graph *recoverGraph(graph *greedyGraph, graph *collapsedBranching)
{
  int i,j; /*loop indices over nodes*/
  graph *recoveredGraph; /*output graph */
  edge *newEdge; /* for making edges of recovered graph */
  edge *e, *f; /* loop variables */
  edge *minEdge;  /* used to decide which edge of a cycle to delete */
  node *v; /* loop variables */
  double minWeight; /* used with minEdge in cycle reconstruction */
  /*bool noEdges = TRUE;  bool variable to distinguish
    beginnings of lists of nodes,
    edges of recovered graph */
  recoveredGraph = new graph(greedyGraph->get_label());

  /*recoveredGraph will be on the same vertex set as greedyGraph*/
  recoveredGraph->size = greedyGraph->size;
  recoveredGraph->root = greedyGraph->root;
  recoveredGraph->list_of_nodes = greedyGraph->list_of_nodes;
  initEdges(recoveredGraph);
  if (verbose)
  {
    fprintf(ofile,"DEBUG> recoveredGraph after initEdges.\n");
    output_graph_with_node_frequency_and_edge_weight(recoveredGraph);
  }

  /*first, we add edges to recovered graph corresponding to the edges of the
    branching on the collapsed graph*/
  for(i = 0; i < collapsedBranching->size; i++)
    for(j = 0; j < collapsedBranching->size; j++)
    {
      e = collapsedBranching->table_of_edges[i][j];
      if (NULL != e)
        /*we add the edge from the greedyGraph which made it to the
          collapsed Branching */
      {
        f = e->old_edge;  /*f is the edge we wish to add*/
        newEdge = copyEdge(f);
        delete recoveredGraph->table_of_edges[newEdge->tail->index][newEdge->head->index];
        recoveredGraph->table_of_edges[newEdge->tail->index][newEdge->head->index] = newEdge;
        /*creates a copy of f in the recovered graph*/
      }
    }
  if (verbose)
  {
    fprintf(ofile,"DEBUG> recoveredGraph after adding edges.\n");
    output_graph_with_node_frequency_and_edge_weight(recoveredGraph);
  }

  /*now we greedily add the edges of the greedy graph while making sure
    that we do not violate degree condition.  If an edge from the
    collapsed branching recovery and an edge from the greedyGraph share
    the same head, we take the one from the collapsed branching
    recovery. */
  for(i = 0; i < greedyGraph->size; i++)
    for(j = 0; j < greedyGraph->size; j++)
    {
      e = greedyGraph->table_of_edges[i][j];
      if (NULL != e)
      {
        v = e->head;
        if (source(recoveredGraph,v))
          /*the head of e is unoccupied, so we may add e to the graph*/
        {
          newEdge = copyEdge(e);
          newEdge->old_edge = e->old_edge;
          delete recoveredGraph->table_of_edges[newEdge->tail->index][newEdge->head->index];
          recoveredGraph->table_of_edges[newEdge->tail->index][newEdge->head->index] = newEdge;
        }
      }
    }
  if (verbose)
  {
    fprintf(ofile,"DEBUG> recoveredGraph after adding greedy edges.\n");
    output_graph_with_node_frequency_and_edge_weight(recoveredGraph);
  }

  /*finally we delete the minimum weight edge from each cycle in the
    recovered graph*/
  assignParents(recoveredGraph);  /*this resets parent fields to agree
                                    with the edges of the recovered graph*/
  for(i = 0; i < recoveredGraph->size; i++)
    for(j = 0; j < recoveredGraph->size; j++)
    {
      e = recoveredGraph->table_of_edges[i][j];
      if (NULL != e)
      {
        if (sameCycle(e->tail,e->head,recoveredGraph->size))
          /*if the edge e is in a cycle, we must remove an edge from that cycle*/
        {
          v = e->tail;
          minEdge = e;
          minWeight = e->weight;
          while (v != e->head)
          {
            f = recoveredGraph->table_of_edges[v->parent->index][v->index];
            if (f->weight < minWeight)
            {
              minEdge = f;
              minWeight = f->weight;
            }
            v = v->parent;
          }
          minEdge->head->parent = NULL;
          deleteEdge(minEdge,recoveredGraph);
        }
      }
    }
  if (verbose)
  {
    fprintf(ofile,"DEBUG> recoveredGraph after deleting minimum weight edge.\n");
    output_graph_with_node_frequency_and_edge_weight(recoveredGraph);
  }

  /* recoveredGraph is now our maximum weight branching */
  return(recoveredGraph);
}

/*refreshGraph is used to reinitialize the fields used by
  findHighWeightBranching*/
void refreshGraph(graph *this_graph)
{
  //node *v; /*placeholder for a node*/
  int i,j; /* loop indices on nodes*/
  edge *e; /*placeholder for an edge*/
  // Iterate on list of nodes.
  list<node *>::iterator this_node;

  // Loop through every node as parent node.
  for (this_node = this_graph->list_of_nodes.begin();
       this_node != this_graph->list_of_nodes.end(); ++this_node)
  {
    (*this_node)->is_in_cycle = false;
    (*this_node)->cycle_weight = 0.0;
    (*this_node)->parent = NULL;
    (*this_node)->old_node = NULL;
  }
  for(i = 0; i < this_graph->size; i++)
    for(j = 0; j < this_graph->size; j++)
    {
      e = this_graph->table_of_edges[i][j];
      if (NULL != e)
        e->old_edge = NULL;
    }
}

// In "2.3. Optimal tree inference", "finding minimum weight directed
// spanning trees (arborescences) due to Chu and Liu".
/*findHighWeightBranching is the primary recursive function of the
  program.  upon the input of the graph G it returns a pointer to a
  maximum weight branching of G.  First it calls makeGreedyGraph,
  which picks out the maximum weight edge going into each vertex.  If
  the greedy graph is acyclic, we are done.  Otherwise, we must break
  up cycles.  collapseGraph collapses each cycle to a single node, and
  adjusts edge weights via formula described elsewhere.
  findHighWeightBranching then calls itself recursively, to get a
  maximum weight branching on the collapsed graph.  it then calls
  recoverGraph, which expands each of the cycles of the collapsed
  graph, ensuring that for each cycle one edge is deleted.  This
  results in the maximum weight branching.  note that the maximum
  weight branching need not be a connected graph, even if the graph G
  is strongly connected.  However, if G is a complete digraph, the
  maximum weight branching will be connected.
  top indicates whether this is the top-level  call (TRUE)
  or a recursive call (FALSE) */


graph *findHighWeightBranching(graph *G, bool top)
{
  graph *greedyGraph; /*holds the greedy graph with highest weight
                        edges*/
  graph *collapsedGraph; /*holds the collapsed version of greedyGraph*/
  graph *collapsedBranching; /*holds the result of the recursive call
                               on collpasedGraph*/

  graph *recoveredGraph; /*holds the expanded version of collpasedBranching*/
  graph *H; /*H holds a subgraph of G of edges that may occur
              in the branching*/

  if (verbose)
  {
    fprintf(ofile,"DEBUG> Entering findHighWeightBranching #%d.\n", entry_times++);
    output_graph_with_node_frequency_and_edge_weight(G);
  }

  if (top)
  {
    H = G; ///// H = trimGraph(G);
    refreshGraph(H);
    for (int index = 0; index < H->size; index++)
    {
      delete H->table_of_edges[index][H->root->index];
      H->table_of_edges[index][H->root->index] = NULL;
    }
  }
  else
    H = G;

  if (verbose)
  {
    fprintf(ofile,"DEBUG> Printing refreshed or assigned graph.\n");
    output_graph_with_node_frequency_and_edge_weight(H);
  }

  greedyGraph = makeGreedyGraph(H);
  if (verbose)
  {
    fprintf(ofile,"Printing greedy graph.\n");
    ///      printGraph(greedyGraph,WEIGHTS);
    output_graph_with_node_frequency_and_edge_weight(greedyGraph);
  }
  ///  if (isAcyclic(greedyGraph,TRUE))
  if (isAcyclic(greedyGraph,true))
  {
    if (verbose)
    {
      fprintf(ofile,"DEBUG> Exiting findHighWeightBranching #%d.\n", --entry_times);
    }
    return(greedyGraph);
  }
  else
  {
    collapsedGraph = collapseGraph(greedyGraph,H);
    if (verbose)
    {
      fprintf(ofile,"Printing collapsed graph.\n");
      ///         printGraph(collapsedGraph,WEIGHTS);
      output_graph_with_node_frequency_and_edge_weight(collapsedGraph);
    }
    collapsedBranching = findHighWeightBranching(collapsedGraph, false);
    if (verbose)
    {
      fprintf(ofile,"DEBUG>Printing collapsed branching.\n");
      output_graph_with_node_frequency_and_edge_weight(collapsedBranching);
    }
    recoveredGraph = recoverGraph(greedyGraph,collapsedBranching);
    if (verbose)
    {
      fprintf(ofile,"Printing recovered branching.\n");
      ///         printGraph(recoveredGraph,WEIGHTS);
      output_graph_with_node_frequency_and_edge_weight(recoveredGraph);
    }
    {
      if (verbose)
      {
        fprintf(ofile,"DEBUG> Exiting findHighWeightBranching #%d.\n", --entry_times);
      }
      greedyGraph->list_of_nodes.clear();  // Nodes are shared and so
      // cannot be deleted
      collapsedBranching->list_of_nodes.clear();

      collapsedGraph->deep_delete_nodes();
      delete collapsedGraph;
      delete collapsedBranching;
      delete greedyGraph;

      return(recoveredGraph);
    }
  }
}
