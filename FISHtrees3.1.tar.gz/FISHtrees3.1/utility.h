// Utility subroutines for the main program.
#ifndef UTILITY_H
#define UTILITY_H

#include <string>

#include "fish.h"
#include "obs_graph.h"
#include "node.h"
#include "output.h"

#define BSIZE 1000 //buffer size

// Process and echo command line arguments.
void
process_command_line_arguments(int argc, char *argv[],
                               std::string & directory,
                               vec_names & name_chr, vec_names & name_gene,
                               int & model_ploidy,
                               int & ploidy_less_approach);

// Locate a low-frequency noisy state, whose frequency is less than f(%) 
// of the sum of frequencies of its neighbors.
void filter_low_frequency_states(obs_graph::freq_t & freq);

// Locate a low-frequency noisy state, whose frequency is less than e(%)
// of the total frequencies of all states or f(%) of the sum of
// frequencies of its neighbors.
void filter_low_frequency_states2(obs_graph::freq_t & freq, int);

#endif
