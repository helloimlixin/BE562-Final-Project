#ifndef OBS_GRAPH_H
#define OBS_GRAPH_H

#include <map>
#include <set>
#include <vector>
#include <utility>
#include <iostream>

#include "fish.h"

// A class that represents possible nodes and edges derived from
// observations in a patient data file
class obs_graph {
 public:
  // A obs_graph::node represents a specific copy number of chromosome and
  // gene probe.
  class node {
  public:
    int chr, gene;
    node(int c = -1, int g = -1) : chr(c), gene(g) {};
    bool operator<(const node & b) const {
      return chr < b.chr || (chr == b.chr && gene < b.gene);
    }
    bool operator!=(const node & b) const {
      return chr != b.chr || gene != b.gene;
    }
    bool operator==(const node & b) const {
      return chr == b.chr && gene == b.gene;
    }
  };
  typedef std::vector<node> vec_node;
  typedef std::set<node> node_set;

  // An obs_graph::edge represents a possible genetic event
  // (gain/loss) linking two instances of obs_graph::node
  class edge {
  public:
    node tail, head;

    // The enumerated mutation_type represented by inserting an edge
    // between the two specific nodes.
    mutation_type type;
    edge(const node & tail_, const node & head_, mutation_type type_) :
      tail(tail_), head(head_), type(type_) {}
    edge() : tail(), head(), type(INVALID) {}
    bool operator==(const edge & other) const {
      return tail == other.tail && head == other.head && type == other.type;
    }
  };

  // Node frequency of an obs_graph is an integer-value
  // count read from a patient data file or set as 1.0 on unobserved
  // root node or on a Steiner node (that un-normalized weight is
  // assigned to 1.0, a relatively small positive value; this weight
  // will be normalized later to approximately
  // 1.0/number_of_cells_counted_in_patient_data_file).
  typedef double freq_t[MAX_COPY+1][MAX_COPY+1];
  freq_t frequencies;

  // Mapping of possible tumorigenesis from enumerated mutation_type
  // to corresponding node
  typedef std::map<mutation_type, node> children_t;
  children_t children[MAX_COPY+1][MAX_COPY+1];

  typedef std::vector<edge> vec_edge;
  typedef std::vector<edge> path;
  typedef std::vector<path> vec_path;

  explicit obs_graph(int_matrix);

  // Return the observed frequency of the given node.
  double get_freq(const node &n) const { return frequencies[n.chr][n.gene]; }

  // Set the observed frequency of the given node.
  void set_freq(const node &n, double v) { frequencies[n.chr][n.gene] = v; }

  // Get a map between enumerated mutation_types and the child of the
  // current node implied by the mutation type
  const children_t & get_children(const node & n) const
  {
    return children[n.chr][n.gene];
  }

  // Return the chromosome and gene number of this node, packed into
  // an integer (type int).
  int get_state_index(const node & n) const
  {
    return (((MAX_COPY + 1) * n.chr) + n.gene);
  }

  // Set possible tumourigenesis states as nodes based on current copy
  // numbers of chromosome (or ploidy) and gene probe.
  void set_possible_children(int chr, int gene);

  // Return all edges that start at an node in current_candidates but
  // do not end in a node in visited.
  vec_edge find_frontier_edges(const node_set & current_candidates,
                               const node_set & visited) const;

  // Return all target nodes reachable from root (unconditionally
  // including root).
  node_set
    explore_island(const node & root, const node_set & target_nodes) const;
};


std::ostream & operator<<(std::ostream &output, const obs_graph::node &n);
std::ostream & operator<<(std::ostream &output,
                          const obs_graph::path & path);
std::ostream & operator<<(std::ostream &output,
                          const obs_graph::vec_path & path);

#endif
