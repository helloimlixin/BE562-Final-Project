#include <algorithm>
#include <fstream>
#include <iomanip>

#include <cassert>
#include <cmath>
#include <cstdlib>

#include "generate_steiner_trees.h"

#include "generate_mst.h"
#include "median_joining.h"
#include "calculate_pairwise_distance.h"
#include "weighted_distance.h"

#define LARGE_DISTANCE 1000

using namespace std;

// Generate and return minimal steiner trees using copy number data
// dirname is the directory containing filename
// patient_filename is the file cotaining data for one patient
// argc is the command line arguments from main
// name_gene is an array with the names of the gene probes
// steiner_node_generation_method is the method (exact,heuristic) to
// infer the steiner nodes
// tot_scg_sets and scg store the same chromosome groups
// probes_on_chromosome[i] indicates how many probes are on the same
// chromosome as probe i
// returns: graph representing the inferred steiner tree
graph *
generate_steiner_trees(int number_of_probes, const vec_names & name_gene,
                       int terminals[][MAX_PROBES],
                       vector<int> & cell_count, int total_record,
                       int steiner_node_generation_method,
                       int tot_scg_sets, int **scg,
                       int *probes_on_chromosome)
{

  // Prune the input arrays to eliminate records with similar copy
  // number counts total_now is the number of cells after pruning
  int total_now =
    prune_identical_cells(terminals, total_record, number_of_probes,
                          cell_count);
  //cout << "\nTable Pruned. Total node now: " << total_now << endl;
  // Print out the terminal nodes after pruning out the identical records

  //for (int i = 0; i < total_now; i++){
  //    for (int j = 0; j < number_of_probes;j++)
  //        cout << terminals[i][j] << "\t";
  //    cout << "\n";
  //}


  // indexing_array is allocated and initialized here and
  // then passed into the candidate generation method
  vector<int> indexing_array(number_of_probes);
  for (int i = 0; i < number_of_probes; i++)
    indexing_array[i] = 0;

  // Allocate array for holding the candidate steiner nodes' copy
  // number count
  int (*candidates)[MAX_PROBES] = new int[MAX_CANDIDATES][MAX_PROBES];

  // Allocate storage for holding the representative "decimal value" of
  // each record consisting of the given probe count
  vector<unsigned int> check_vector;

  // Calculate representative "decimal value" of copy number counts of
  // each record and store it
  unsigned int temp = 0;
  for (int i = 0; i< total_now; i++){
    temp = 0;
    for (int j = 0; j < number_of_probes; j++){
      temp += (terminals[i][j] * myPow(MAX_COPY+1,number_of_probes-j-1));
    }
    check_vector.push_back(temp);
  }

  // Declare storage for holding the copy number counts of each
  // node and node indexes for each edge in the MST
  int **mst_node_store;
  int **mst_edge_store;

  // Declare storage for maximum number of inferred steiner nodes
  int maximum_steiner_nodes = 0;

  // Set the value of maximum_steiner_nodes depending on whether the
  // user has selected exact or heuristic approach
  if(steiner_node_generation_method == PLOIDY_LESS_EXACT)
    maximum_steiner_nodes = MAX_STEINER_NODES_EXACT;
  else
    maximum_steiner_nodes = MAX_STEINER_NODES_HEURISTIC;

  // Allocate storage for holding the copy number counts of each
  // node and node indexes for each edge in the MST
  mst_node_store = new int*[total_now + maximum_steiner_nodes];
  for (int i = 0; i < total_now + maximum_steiner_nodes; i++){
    mst_node_store[i] = new int[number_of_probes];
  }

  mst_edge_store = new int*[total_now + maximum_steiner_nodes];
  for (int i = 0; i < total_now + maximum_steiner_nodes; i++){
    mst_edge_store[i] = new int[2];
  }

  // total_nodes is the total number of terminals and steiner nodes
  int total_nodes = 0;

  // Generate steiner trees using the exact or heuristic approach
  // selected by the user
  if(steiner_node_generation_method == PLOIDY_LESS_EXACT){

    // Generate steiner tree using the exact method
    // Generate the set of candidate steiner nodes first
    // tot_candidates is the total number of candidate steiner nodes
    // for the exact approach
    int tot_candidates =
      generate_candidate(&indexing_array[0], terminals, candidates,
                         total_now, number_of_probes,check_vector);
    cout << "\nNumber of candidate steiner nodes: " << tot_candidates;


    // Generate the minimum weighted steiner tree using the steiner
    // nodes infered by the exact approach total_nodes is the total
    // number of nodes in the steiner tree
    total_nodes =
      generate_mst(total_now, tot_candidates, number_of_probes,
                   terminals, candidates, mst_node_store,
                   mst_edge_store);
    //cout << "Number of steiner nodes inferred: " << total_nodes-total_now;
  }
  else if(steiner_node_generation_method == PLOIDY_LESS_HEURISTIC_WEIGHTED){
    graph *gr =
      generate_weighted_trees(number_of_probes, name_gene, terminals,
                              cell_count, total_now,tot_scg_sets,scg);

    for (int i = 0; i < total_now + maximum_steiner_nodes; i++)
      delete [] mst_node_store[i];

    for (int i = 0; i < total_now + maximum_steiner_nodes; i++)
      delete [] mst_edge_store[i];

    delete [] mst_node_store;
    delete [] mst_edge_store;
    delete [] candidates;

    return gr;
  }
  else if(steiner_node_generation_method != PLOIDY_LESS_EXACT){

    //Generate Steiner Tree using median joining approach
    total_nodes =
      median_joining(total_now, number_of_probes, terminals,
                     mst_node_store, mst_edge_store, 0,
                     steiner_node_generation_method, tot_scg_sets,
                     scg, probes_on_chromosome);
  }

  // Change the cell_count value of the steiner nodes to 0
  for (int i = total_now; i < total_nodes; i++)
    cell_count[i] = 0;

  // Delete Steiner nodes which have degree of 2. These nodes do not
  // contribute to reducing the weight of the steiner tree and are
  // thus redundant.  new_total_nodes is the updated number of nodes
  // after prunning out the degree two steiner nodes
  int new_total_nodes =
    delete_redundant_steiner_nodes(mst_node_store, mst_edge_store,
                                   total_now, total_nodes,
                                   number_of_probes);
  total_nodes = new_total_nodes;

  // Sort the nodes lexicographically based on the counts of the
  // probes. The root index is the index of the node with probe count
  // of all 2.
  int root_index =
    sort_nodes(mst_node_store, mst_edge_store, total_nodes,
               number_of_probes, cell_count);

  cout << "\nRoot node index is: " << root_index;
  // Print the directed tree
  /*
     cout << "\n Printing the Steiner tree nodes\n";
     for (int i = 0; i < total_nodes; i++){
     for (int j = 0; j < number_of_probes; j++){
     cout << mst_node_store[i][j] << "\t";
     }
     cout << cell_count[i];
     cout << endl;
     }
     cout << "\n Printing the Steiner tree edges\n";
     for (int i = 0; i < total_nodes-1; i++){
     for (int j = 0; j < 2; j++){
     cout << mst_edge_store[i][j] << "\t";

     }
  //cout << cell_count[i];
  cout << endl;
  } */
  // Convert the undirected tree to the directed one
  convert_to_directed_tree(mst_edge_store, total_nodes, root_index);
  cout << "\nDirected tree is created";

  // remove the halving edges
  if (steiner_node_generation_method ==
      PLOIDY_LESS_HEURISTIC_GENOME_DUPLICATION)
    check_and_reorganize(mst_node_store, mst_edge_store, total_nodes,
                         number_of_probes,steiner_node_generation_method,
                         tot_scg_sets, scg, probes_on_chromosome);
  // Print the directed tree
  /*
     cout << "\n Printing the Directed Tree\n";
     for (int i = 0; i < total_nodes; i++){
     for (int j = 0; j < 2; j++){
     cout << mst_edge_store[i][j] << "\t";
     }
  //cout << cell_count[i];
  cout << endl;
  } */

  // Convert the steiner tree into a joint tree
  graph *gr =
    convert_to_joint_tree(mst_node_store, mst_edge_store, total_nodes,
                          number_of_probes, root_index, name_gene,
                          cell_count,steiner_node_generation_method,
                          tot_scg_sets, scg, probes_on_chromosome);
  cout << "\nJoint tree is created\n";
  //print_graph(gr);
  // Deallocate the storage
  for (int i = 0; i < total_now + maximum_steiner_nodes; i++)
    delete [] mst_node_store[i];

  for (int i = 0; i < total_now + maximum_steiner_nodes; i++)
    delete [] mst_edge_store[i];

  delete [] mst_node_store;
  delete [] mst_edge_store;
  delete [] candidates;

  return gr;
}


// This method is used to get rid of the steiner nodes with degree two
// nodes stores the copy number counts of each node in the MST
// edges stores indices of the two nodes of each edge in the MST
// terminals stores the copy number count of each probe in each record
// total_nodes stores the toal number of nodes in the MST before deletion of redundant steiner nodes
// probes is the total number of probes selected by the user
// nodes and edges arrays are passed by references
// Returns the total number of nodes after deletion
int
delete_redundant_steiner_nodes(int **nodes, int **edges, int terminals,
                               int total_nodes, int probes)
{
  // First entry of each row of the adjacency list matrix contains the number
  // of nodes adjacent to the node represented by the index of that row. Then
  // the next entries in each row contain the index of the adjacent nodes to
  // that row node in the graph
  vector<vector<int> > adjacency_list(total_nodes,
                                      vector<int>(total_nodes));
  assert(total_nodes > 0);
  for (int i = 0; i < total_nodes; i++)
    for (int j = 0; j < total_nodes; j++)
      adjacency_list[i][j] = 0;
  // The total number of edges is total_nodes-1 as it is a tree
  for (int i = 0; i < total_nodes-1; i++){
    adjacency_list[edges[i][0]][0] += 1;
    adjacency_list[edges[i][1]][0] += 1;
    adjacency_list[edges[i][0]][adjacency_list[edges[i][0]][0]] = edges[i][1];
    adjacency_list[edges[i][1]][adjacency_list[edges[i][1]][0]] = edges[i][0];
  }

  // For each steiner node, first check whether any of its degree is 2 or not
  for (int j = terminals; j < total_nodes; j++ ){
    //index += 1;
    if(adjacency_list[j][0] == 2){

      // Record this particular steiner node's two neighbours
      int first_neighbour = adjacency_list[j][1];
      int second_neighbour = adjacency_list[j][2];

      // Records which row (node) is going to get deleted
      int deleting_row = -1;

      // deletion_identified indicates whether the node to be deleted
      // has already been identified or not
      bool deletion_identified = false;

      // Browse through the edge list to find the two edge entries
      // of the steiner node with degree two. In one edge entry, the
      // two neighbors of the steiner node will be connected together
      // and the other entry is deleted
      for (int k = 0; k < total_nodes-1; k++){
        if((edges[k][0] == j) || (edges[k][1] == j)) {
          if(deletion_identified == false){
            deletion_identified = true;
            // Replaces the index of the steiner node in the edge list
            // with the other neighbor to connect the two neighbors of
            // the steiner node
            if(edges[k][0] == j){
              if(edges[k][1] == first_neighbour)
                edges[k][0] = second_neighbour;
              else
                edges[k][0] = first_neighbour;

            }
            else{
              if(edges[k][0] == first_neighbour)
                edges[k][1] = second_neighbour;
              else
                edges[k][1] = first_neighbour;
            }

          }
          else
            // Record the edge list entry which will be deleted
            deleting_row = k;
        }
      }
      // Copy every node after the steiner node up the node list to
      // delete the steiner node
      for (int k = j ; k < total_nodes - 1; k++)
        for (int l = 0; l < probes; l++)
          nodes[k][l] = nodes[k+1][l];

      // Decrease the edge indices to reflect the above node copy
      // operation where some of the nodes edge index have decreased
      // due to the deletion of the steiner node
      for (int k = 0 ; k < total_nodes - 1; k++){
        if(edges[k][0] > j){
          edges[k][0] -= 1;
        }
        if(edges[k][1] > j)
          edges[k][1] -= 1;
      }

      // Now copy the edges up in the edge list to delete the recorded edge
      assert(deleting_row >= 0);
      for (int k = deleting_row; k < total_nodes-2; k++){
        edges[k][0] = edges[k+1][0];
        edges[k][1] = edges[k+1][1];
      }

      // Adjust the adjacency list to reflect the deletion of the
      // steiner node.  Fist update the first and second neighbour's
      // neighbor list by replacing the steiner node index with the
      // other neighbour's index
      for (int k = 1; k <= adjacency_list[first_neighbour][0]; k++){
        if(adjacency_list[first_neighbour][k] == j)
          adjacency_list[first_neighbour][k] = second_neighbour;
      }
      for (int k = 1; k <= adjacency_list[second_neighbour][0]; k++){
        if(adjacency_list[second_neighbour][k] == j)
          adjacency_list[second_neighbour][k] = first_neighbour;
      }

      // Now decrease the node indices of the nodes located below the
      // deleted steiner node in the adjacency list of every node
      for (int l = 0; l < total_nodes; l++){
        for (int k = 1; k <= adjacency_list[l][0]; k++){
          if(adjacency_list[l][k] > j)
            adjacency_list[l][k] -=1;
        }
      }
      // Now copy everything 1 step up for nodes located below the deleted
      // steiner node
      for (int k = j ; k < total_nodes - 1; k++)
        for (int l = 0; l < total_nodes; l++)
          adjacency_list[k][l] = adjacency_list[k+1][l];
      // Decrease the total node count and j
      total_nodes -= 1;
      j -= 1;
    }

  }
  return total_nodes;
}

// This method converts an undirected steiner tree to a directed one
// edges stores indices of the two nodes of each edge in the MST
// total_nodes stores the toal number of nodes in the MST
// root_index is the index of the root node
// edges array is passed by reference
// directed tree is stored in the edges array
void convert_to_directed_tree(int **edges, int total_nodes, int root_index)
{

  // edge_index variable keeps track of the count of the edges that have
  // been converted to directed ones. It is initialized to -1 rather than
  // 0 because it is incremented first and then used
  int edge_index = -1;

  // A queue is allocated to traverse the nodes in the graph in Breadth
  // first search manner
  int queue_head = 0;
  int queue_tail = 0;
  vector<int> queue(total_nodes+1);

  // Temporary edge list to store the directed edges node indices
  vector<vector<int> > new_edge_list(total_nodes-1,
                                     vector<int>(2));;

  // Indicator variable keeps track of the nodes whose all the
  // neighbors have been traversed
  vector<char> indicator(total_nodes);

  // Change the size to something related to the number of nodes
  int size_of_direction_assigned_vector = (total_nodes * (total_nodes + 2)) + 1;

  vector<char> direction_assigned(size_of_direction_assigned_vector);

  for (int i = 0; i < size_of_direction_assigned_vector; i++)
    direction_assigned[i] = false;

  // First entry of each row of the adjacency list matrix contains the number
  // of nodes adjacent to the node represented by the index of that row. Then
  // the next entries in each row contain the index of the adjacent nodes to
  // that row node in the graph
  vector<vector<int> > adjacency_list(total_nodes,
                                      vector<int>(total_nodes));

  // Initialize the indicators and adjacency list
  for (int i = 0; i < total_nodes; i++){

    indicator[i] = false;
    for (int j = 0; j < total_nodes; j++)
      adjacency_list[i][j] = 0;
  }
  for (int i = 0; i < total_nodes-1; i++){
    adjacency_list[edges[i][0]][0] += 1;
    adjacency_list[edges[i][1]][0] += 1;
    adjacency_list[edges[i][0]][adjacency_list[edges[i][0]][0]] = edges[i][1];
    adjacency_list[edges[i][1]][adjacency_list[edges[i][1]][0]] = edges[i][0];
  }


  // Start from the root node as the edges are directed outward from the root
  // Insert the root node in the queue first
  queue[queue_tail] = root_index;

  while(1){
    if(queue_head > queue_tail)
      break;

    // Tests whether each edge has beeen assigned a direction
    if(edge_index == total_nodes - 2)
      break;

    // Extract the node located in the front position of the queue
    int node = queue[queue_head];
    queue_head += 1;

    indicator[node] = true;

    // Iterate through all the neighbors of the extracted node
    for (int i = 1; i <= adjacency_list[node][0]; i++){
      // Calculate an identifier for the neighbor
      int temp = -1;

      if(node >= adjacency_list[node][i])
        temp = (node * (total_nodes + 1)) + adjacency_list[node][i];

      else
        temp = (adjacency_list[node][i]  * (total_nodes + 1)) + node;

      // Check to see if the particular edge that is being considered
      // has already been included or not in the edge list
      if(direction_assigned[temp] == false){
        direction_assigned[temp] = true;
        edge_index += 1;

        // If this particular edge has not already been included, then
        // include it as a directed edge
        new_edge_list[edge_index][0] = node;
        new_edge_list[edge_index][1] = adjacency_list[node][i];

        // If the neighbor's adjacency list has not been traversed previously
        // then insert it into the queue for later consideration
        if(indicator[adjacency_list[node][i]] == false){
          queue_tail += 1;
          queue[queue_tail] =  adjacency_list[node][i];
        }
      }
    }
  }

  // Copy the edges from the temporary storage to the final storage which is
  // returned by the method
  for (int i = 0; i < total_nodes-1; i++){
    edges[i][0] = new_edge_list[i][0];
    edges[i][1] = new_edge_list[i][1];

  }

}

// Sort the nodes in the steiner tree lexicographically based on the counts of the probes.
// mst_node_store stores the copy number counts of each node in the MST
// mst_edge_store stores indices of the two nodes of each edge in the MST
// total_nodes is the total number of nodes in the steiner tree
// number_of_probes is the total number of probes listed by the user
// cell_counter stores the total cell count of each probe combination in the patient file
// sorted nodes and edges with modified node indices are stored in mst_node_store and mst_edge_store respectively
// Return the index of the root node, the node with probe count of all 2.
int sort_nodes(int **mst_node_store, int **mst_edge_store, int total_nodes, int number_of_probes, vector<int> &cell_counter)
{
  // Declare arrays for holding the representative "decimal values" calculated
  // from the probe count of each node
  vector<unsigned int> int_value(total_nodes);
  vector<unsigned int> int_stores(total_nodes);

  // Declare variable to hold the nodes' new indices after the node array is sorted
  vector<int> new_index(total_nodes);

  // Declare temporary storage for holding the nodes in the tree
  vector<vector<int> > temp_node_store(total_nodes,
                                       vector<int>(number_of_probes));

  // Declare temporary storage for holding the node indices of the edges in the tree
  vector<vector<int> > temp_edge_store(total_nodes-1, vector<int>(2));
  vector<int> temp_cell_counter(total_nodes);

  // Declare variable to hold the decimal value for each node calculated
  // using the probe count
  unsigned int unique_node_identifier = 0;

  // Declare variable to hold the index of the root node
  int root_index = -1;

  // Calculate decimal value of each node based on the copy number
  // count of the individual probes and store them
  assert(total_nodes > 0);
  for (int i = 0; i< total_nodes; i++){
    unique_node_identifier = 0;
    int root_indicator = 0;

    // For each node, browse through each probe and calculate decimal
    // value of that node based on the copy number value of all the probes
    assert(number_of_probes > 0);
    for (int j = 0; j < number_of_probes; j++){
      unique_node_identifier += (mst_node_store[i][j] * myPow(MAX_COPY+1,number_of_probes-j-1));

      if(mst_node_store[i][j] == 2)
        root_indicator += 1;
    }

    // If this node has copy number count of 2 for each probe, then it
    // is the root node
    if(root_indicator == number_of_probes)
      root_index = i;
    int_value[i] = unique_node_identifier;
    int_stores[i] = unique_node_identifier;
  }

  unsigned int temp;

  // Sort the nodes based on their calculated decimal value
  // Iterate through the node list starting from the second node
  for(int i=1; i < total_nodes; i++){

    // Record the node's decimal value
    temp = int_value[i];
    int j = i-1;

    // For a particular node, compare it's value with the previous
    // set of nodes located in the node array and if it has a lower
    // value than its  predecessor in the array, then slide it to
    // the left until it is placed in a position where all the nodes
    // to it's left have a smaller decimal value. After performing this
    // rearrangements for each node in the storage array, the whole
    // array gets sorted

    while((j >= 0) && (temp < int_value[j])){
      int_value[j+1] = int_value[j];
      j = j-1;
    }
    int_value[j+1] = temp;
  }

  // Record the new index of each node after the node array is sorted
  for (int i = 0; i < total_nodes; i++){
    for (int j = 0; j < total_nodes; j++){
      if(int_stores[i] == int_value[j])
        new_index[i] = j;
    }
  }

  // Copy the cell counter, node and edge list to the temporary storages
  // based on the new indices of the sorted nodes
  for (int i = 0; i < total_nodes; i++){

    // Store the cell count of each node
    temp_cell_counter[new_index[i]] = cell_counter[i];

    // Store the node's copy number count
    for (int j = 0; j < number_of_probes; j++){
      temp_node_store[new_index[i]][j] = mst_node_store[i][j];
    }

    // Change and store the new edge list based on the new
    // indices of the nodes
    if(i < total_nodes - 1){
      for(int j = 0; j < 2; j++){
        temp_edge_store[i][j] = new_index[mst_edge_store[i][j]];
      }
    }
  }

  // Copy back the cell count, node and edge list to the original
  // storage arrays
  for (int i = 0; i < total_nodes; i++){
    cell_counter[i] = temp_cell_counter[i];
    for (int j = 0; j < number_of_probes; j++){
      mst_node_store[i][j] = temp_node_store[i][j];
    }
    if(i < total_nodes - 1){
      for(int j = 0; j < 2; j++){
        mst_edge_store[i][j] = temp_edge_store[i][j];
      }
    }
  }

  // Return the new index of the root node
  assert(root_index >= 0);
  return new_index[root_index];
}

// Eliminates records which have the same copy number count for each probe
// store stores the copy number counts of each user selected probe in the patient file
// total_record is the total number of records in the patient file
// number_of_probes is the total number of probes selected by the user
// cell_counter stores the total cell count of each probe combination in the patient file
// pruned cells are stored in the store array
// store is passed by reference
// Returns total number of unique cells
int prune_identical_cells(int store[][MAX_PROBES], int total_record, int number_of_probes, vector<int> &cell_counter)
{
  // cur_total is the current number of distinct cells
  int cur_total = 0;

  // Declare storages for storing the decimal values representing
  // the records present in the input data file
  vector<unsigned int> check_vector;
  vector<unsigned int> storage_vector(total_record);
  vector<vector<int> > temp_store(total_record,
                                  vector<int>(number_of_probes));
  vector<int> temp_cell_counter;

  vector<vector<unsigned int> > temp_checker(total_record,
                                             vector<unsigned int>(2));

  // For each cell, browse through each probe and calculate decimal
  // value of that cell based on the copy number value of all the probes
  for (int i = 0; i< total_record; i++){ // it was i = 1 here
    unsigned int temp = 0;
    for (int j = 0; j < number_of_probes; j++){
      temp += (store[i][j] * myPow(MAX_COPY + 1,number_of_probes-j-1));
    }

    // Store the decimal value representing that cell
    storage_vector[i] = temp;

    // Check to see if the calculated value is already present
    // or not in the check vector. If not, then store it and
    // sort the storage vector to facilitate future search procedure
    if (!(binary_search (check_vector.begin(), check_vector.end(), temp))){
      check_vector.push_back(temp);
      sort(check_vector.begin(),check_vector.end());

      // Copy the record in a temporary storage
      for (int j = 0; j < number_of_probes; j++){
        temp_store[cur_total][j] = store[i][j];
      }
      temp_checker[cur_total][0] = temp;
      temp_checker[cur_total][1] = 0;
      cur_total += 1;
    }
  }

  // Adjusts the cell count for the duplicated cells records. For two records with
  // same probe values, add the cell counts up.

  for (int i = 0; i< total_record; i++){
    unsigned int val;

    // Copy a particular record present in the patient file
    val = storage_vector[i];
    bool checker = false;

    // For each record present in the patient file, iterate through
    // all unique records
    for(int j = 0; j < cur_total; j++){

      // Check if a particular record in the unique list matches the
      // copied record,
      if(temp_checker[j][0] == val){

        // First check to see if that record has been
        // seen more than once or not
        if(temp_checker[j][1] == 1)
          checker = true;
        else
          temp_checker[j][1] = 1;
        break;
      }
    }

    // If a particular record has been observed more than once, ignore it
    // as its cell count is adjusted when it was observed the first time
    if(checker == true)
      continue;
    int total_count = 0;

    // Iterate through the input record list and adjust the total cell count for
    // a record that has been observed more than once. Otherwise, just copy its
    // cell count. Store the cell count in a temporary vector
    for(int j = 0; j < total_record; j++){
      if(storage_vector[j] == val){
        total_count += cell_counter[j];
      }
    }
    temp_cell_counter.push_back(total_count);
  }

  // Copy the cell count and unique records in the storage area
  // where the caller method will access them
  for (int i = 0; i < cur_total; i++){
    cell_counter[i] = temp_cell_counter[i];
    for (int j = 0; j < number_of_probes; j++)
      store[i][j] = temp_store[i][j];
  }
  return cur_total;

}

// Generate candidate steiner nodes for the exact approach.
// indexing_array holds the indices in unique probe count array
// store stores the copy number counts of each user selected probe in the patient file
// result stores the generated candidate steiner nodes
// total_record is the total number of records in the patient file
// probes is the total number of probes selected by the user
// check stores the representative decimal value of each cell
// check is passed by reference and modified because there can be multiple
// calls and we want to avoid generating the same candidates from
// one call to the next.
// generated candidates are stored in the result array
// result is passed by reference
// Returns total number of generated candidates
int generate_candidate(int indexing_array[], int store[][MAX_PROBES], int result[][MAX_PROBES], int total_records, int probes, vector<unsigned int> & check)
{
  // index is used for indexing purpose in indexing_array
  // total stores the total number of candidate steiner nodes generated so far
  int index = 0;
  int total = 0;

  // Sort the terminal nodes representative value first
  sort(check.begin(),check.end());

  // Stores the total number of unique count values for each probe
  vector<int> number_of_unique_records(probes);

  // Declare and initialize storages for holding the unique counts of each probe
  vector<vector<char> > unique_value_checker(MAX_COPY+1,
                                             vector<char>(probes));
  vector<vector<int> > unique_values(MAX_COPY + 1, vector<int>(probes));
  for (int i = 0; i < MAX_COPY + 1 ; i++){
    for (int j = 0; j < probes; j++){
      unique_value_checker[i][j] = 0;
      unique_values[i][j] = 0;
      number_of_unique_records[j] = 0;
    }
  }

  // For every record in the patient file, iterate through every probe value
  // and store the unique value for each probe across all the records
  for (int i = 0; i < total_records; i++){
    for (int j = 0; j < probes; j++){

      // Check if the current probe count for the particular record
      // has been observed before or not
      if (unique_value_checker[store[i][j]][j] == 0){

        // If the current value has not been observed before, then tag it as observed
        unique_value_checker[store[i][j]][j] = 1;

        // Store the unique probe count value
        unique_values[number_of_unique_records[j]][j] = store[i][j];

        // Increase the number of unique probe count for the current probe by 1
        number_of_unique_records[j] += 1;
      }
    }

  }

  // Generate the candidate steiner node by taking combination of
  // the unique probe count values across all the probes
  while(1){

    // Holds the representative decimal value computed for each cell
    unsigned int unique_node_identifier = 0;

    // For a particular combination of the probes,
    // calculate the decimal values using the probes counts
    for (int j = 0; j < probes; j++){
      unique_node_identifier += (unique_values[indexing_array[j]][j] * myPow(MAX_COPY+1,probes-j-1));
    }

    // Check if the steiner node represented by the current combination
    // of probes has already been generated or not. If not, then store it and
    // sort the storage vector to facilitate future search procedure
    if(!(binary_search (check.begin(), check.end(), unique_node_identifier))){
      check.push_back(unique_node_identifier);
      sort(check.begin(),check.end());

      // Copy the probe count for the currently generated steiner node
      // in the storage array
      for (int j = 0; j < probes; j++){
        result[total][j] = unique_values[indexing_array[j]][j];
      }

      // Increase the total number of candidate steiner nodes generated
      total = total + 1;

      // If the total candidate steiner nodes generated so far exceeds
      // the maximum number of candidates allowed, then stop
      // Prints a message to standard error identifying which
      // function and what test failed
      if(total > MAX_CANDIDATES){
        cerr << "Maximum number of candidate steiner nodes generated in the generate_candidate function" << endl;
        break;
      }

    }

    // index points to the last probe now
    index = probes - 1;

    // Check if the last probe's total number of unique record count
    // has been reached or not
    if(indexing_array[index] == (number_of_unique_records[index]-1)){

      index = index - 1;

      // If the last probes total number of unique record count has
      // been reached, then do this similar check for the previous
      // set of probes one by one
      while((index >= 0) && (indexing_array[index] == number_of_unique_records[index]-1))
        index = index - 1;

      // If all the probes maximum number of unique record count is
      // reached, then stop generating the combination
      if(index == -1)
        break;

      // Otherwise, if probe i has reached maximum unique record,
      // increase probe (i-1)'s index count by 1 and reset probe i's
      // index count to 0 for generating the combination for the
      // next steiner node
      else{
        indexing_array[index] = indexing_array[index] + 1;
        for (int i = index + 1; i < probes; i++)
          indexing_array[i] = 0;

      }
    }

    // If the last probes index count has not reached maximum unique
    // record value, then just increase its count by 1
    else{
      indexing_array[probes - 1] = indexing_array[probes - 1]  + 1;
    }

  }

  // Return the total number of candidate steiner node generated
  return total;


}


// Converts individual record into a tree and combines the trees in graph structure
// nodes stores the copy number counts of each node in the steiner tree
// edges stores indices of the two nodes of each edge in the steiner tree
// total_nodes is the total number of nodes in the steiner tree
// probes is the total number of probes listed by the user
// root_index stores the index of the root in the steiner tree
// name_gene stores the name of the genes selected by the users
// cell_count stores the total cell count of each record in the patient file
// steiner_node_generation_method denotes whether to use L1 or genome doubling+L1 to compute distance
// Returns the graph whcih combines the trees representing records in the steiner tree
graph *convert_to_joint_tree(int **nodes, int **edges, int total_nodes, int probes, int root_index, const vec_names & name_gene, const vector<int> & cell_count, int steiner_node_generation_method, int tot_scg_sets, int **tot_scg, int *probes_on_chromosome){

  // single_nodes stores individual probe count values in each record
  node ***single_nodes;
  single_nodes = new node**[total_nodes];

  // joint_nodes stores combined probe count values in each record
  node ***joint_nodes;
  joint_nodes = new node**[total_nodes];

  // total_cells holds the total cell counts in the patient file
  int total_cells = 0;

  // count total number of cells and initialize single_nodes and joint_nodes
  for (int i = 0; i < total_nodes; i++){
    total_cells += cell_count[i];
    single_nodes[i] = new node*[probes];
    joint_nodes[i] = new node*[probes];
    for (int j = 0;  j < probes;  j++) {
      single_nodes[i][j] = new node;
      joint_nodes[i][j] = new node;
    }
  }

  // Set the label of each node in the tree based on the gene probes
  for (int i = 0; i < total_nodes; i++){

    // Declare single and joint node labels
    string single_node_label;
    // Set the label of the joint nodes.
    // If a joint node points to single node that represents the
    // lowest level probe, then set its label by the gene name of that probe
    string joint_node_label(name_gene[0]);


    string probe_list, count_list;
    // For each probe, we have a single node and a joint node
    for (int j = 0; j < probes; j++){

      // Set the probe count values of each single node
      single_nodes[i][j]->set_values(-1, nodes[i][j]);
      single_nodes[i][j]->index = -1;


      // Otherwise concatenate the gene name of the lower level
      // probes to the current probe to attain the label of the
      // current level joint node
      if(j > 0){
        joint_node_label += "+";
        joint_node_label += name_gene[j];
      }

      // Put the probe count value in a parenthesis just after the
      // gene name in the label for each probe

      joint_node_label += "(";
      char buffer[2];
      sprintf(buffer,"%d",nodes[i][j]);
      joint_node_label += buffer;
      joint_node_label += ")";

      // Set the label of the single nodes.
      // A single node represents a single probe. For each node's label,
      // first put the probe's gene name, then under parenthesis,
      // put the probes copy number count
      single_node_label = name_gene[j];
      single_node_label += "(";
      single_node_label += buffer;
      single_node_label += ")";
      single_node_label += "\0";
      single_nodes[i][j]->label = single_node_label;

      // Set value field of the joint node and make the single node pointer
      // points to the proper single node
      // -1 is used here because the ploidy is irrelevant
      joint_nodes[i][j]->set_values(-1,j); //j
      joint_nodes[i][j]->single_node = single_nodes[i][j];
      joint_nodes[i][j]->index = -1;

      // For the top level joint node, set the observed frequency
      // as fraction of the cell count of the corresponding steiner tree node
      if(j == probes-1){
        joint_nodes[i][j]->observed = ((double)cell_count[i] / (double)total_cells);
      }

      // Set the joint node pointers of the joint nodes point to the lower
      // level joint nodes
      if(j > 0){
        joint_nodes[i][j]->joint_node = joint_nodes[i][j-1];
        joint_nodes[i][j-1] = NULL;  // Transfer ownership
        joint_nodes[i][j]->label = joint_node_label;
        if(j == probes-1){
          joint_nodes[i][j]->index = i;
        }

        //strcpy(joint_nodes[i][j].label,labels);
        //strcat(joint_nodes[i][j].label,"\0");
      }

      // Set the lowest level joint nodes joint node pointer NULL
      else{
        joint_nodes[i][j]->joint_node = NULL;
        joint_nodes[i][j]->label = single_nodes[i][j]->label;
      }
      single_nodes[i][j] = NULL;  // transfer ownership to the joint node
    }
  }

  // Assemble the nodes into the graph structure
  graph *joint_graph = new graph();

  // Add the joint nodes to the graph

  for (int i = 0; i < total_nodes; i++){
    joint_graph->addnode(joint_nodes[i][probes-1]);
  }

  // Set the edges of the graph using the set of edges present
  // in the steiner tree
  joint_graph->initialize_table_of_edges(nodes,edges,total_nodes,joint_nodes,probes,root_index,steiner_node_generation_method,
                                         tot_scg_sets, tot_scg, probes_on_chromosome);

  // Set the size and root of the graph
  joint_graph -> size = total_nodes;
  joint_graph -> root = joint_nodes[root_index][probes-1];

  for (int i = 0;  i < total_nodes;  i++) {
    for (int j = 0;  j < probes - 1;  j++) {
      delete joint_nodes[i][j];
    }
    delete [] joint_nodes[i];
    delete [] single_nodes[i];
  }
  delete [] joint_nodes;
  delete [] single_nodes;

  return joint_graph;
}


vector<int>
read_joint_node_counts(const node * n)
{
  vector<int> counts;
  while( n != NULL){
    counts.push_back(n->single_node->gene);
    n = n->joint_node;
  }
  reverse(counts.begin(), counts.end());
  return counts;
}

vector<int>
reconstruct_parents_from_edges(edge *** edges, int nnodes)
{
  vector<int> parents(nnodes, -1);
  for (int jchild = 0;  jchild < nnodes;  jchild++) {
    for (int iparent = 0;  iparent < nnodes;  iparent++) {
      if (edges[iparent][jchild]) {
        parents[jchild] = iparent;
        break;
      }
    }
  }
  return parents;
}

struct as_abbrev_node {
  const node * n;
  as_abbrev_node(node * nn) : n(nn) {}
};

ostream & operator<<(ostream & ss, const as_abbrev_node & nn)
{
  int jchild = nn.n->index;
  vector<int> counts = read_joint_node_counts(nn.n);

  ss << jchild << "(";
  for (size_t k = 0;  k < counts.size();  k++) {
    if (k != 0)
      ss << ",";
    ss << counts[k];
  }
  return ss << ")";
}

// Method for printing the nodes and edges of the graph
void print_graph(graph *gr)
{
  vector<node *> nodes(gr->list_of_nodes.begin(), gr->list_of_nodes.end());

  edge *** edges = gr->table_of_edges;
  int nnodes = nodes.size();

  vector<int> parents = reconstruct_parents_from_edges(edges, nnodes);

  streamsize precision = cout.precision();
  ios_base::fmtflags flags = cout.flags();

  cout << setprecision(5) << fixed;
  cout << "\nPrinting graph in list format:\n";

  for (int jchild = 0;  jchild < nnodes;  jchild++) {
    node * child  = nodes[jchild];
    int iparent = parents[jchild];

    node * parent = iparent != -1 ? nodes[iparent] : 0;

    cout << as_abbrev_node(child)
         << ":" << child->observed << ":" << child->label;
    if (parent) {
      double prob = exp2(-edges[iparent][jchild]->weight);
      cout << "<-" << prob << "--" << as_abbrev_node(parent);
    }
    cout << endl;
  }
  cout.precision(precision);
  cout.flags(flags);
}

void print_graph_with_list(const list<graph *> & store_list, int total_nodes[])
{
  list<node *>::iterator ref_node;
  int k = -1;
  for (list<graph *>::const_iterator it=store_list.begin(); it!=store_list.end() ; ++it){
    graph *gr = *it;
    k += 1;
    for (ref_node = gr->list_of_nodes.begin(); ref_node != gr->list_of_nodes.end(); ++ref_node)
      cout << (*ref_node)->joint_node->single_node->gene <<"\n";

    for (int i = 0; i < total_nodes[k]; i++){
      for (int j = 0; j < total_nodes[k]; j++){
        if(gr->table_of_edges[i][j] != NULL){
          cout << i <<"\t" << j << endl;
        }
      }
    }
  }

}

// Calculates base raised to the power exponent
// x is the base
// p is power
// Returns x raised to the power p
int myPow(int x, int p) {
  int i = 1;
  for (int j = 1; j <= p; j++)  i *= x;
  return i;
}

//This function finds edges where genome halvings are inferred from the
//head node to the tail node and replaces those edges using subtree pruning and
//regrafting approach
// nodes stores the copy number counts of each node in the directed tree
// edges stores indices of the two nodes of each edge in the tree
// total_nodes stores the toal number of nodes in the directed tree
// probes is the total number of probes selected by the user
// steiner_node_generation_method is the method (exact,heuristic) to infer the steiner nodes
// nodes and edges arrays are passed by reference
// tot_scg_sets and scg store the same chromosome groups
// probes_on_chromosome[i] indicates how many probes are on the same chromosome as probe i
// Returns the resulting tree in edges
void check_and_reorganize(int **nodes,int **edges, int total_nodes, int probes, int steiner_node_generation_method, int tot_scg_sets, int **scg, int *probes_on_chromosome)
{

  //stores pairwise distances among the nodes in the tree
  vector<vector<int> > distance;
  distance.resize(total_nodes);
  for (int i = 0; i < total_nodes; ++i){
    distance[i].resize(total_nodes);
  }

  //stores the copy number profiles of the nodes to supply to
  //generate_distance_matrix function
  int (*node_array)[MAX_PROBES] = new int[total_nodes][MAX_PROBES];
  for (int i = 0; i < total_nodes; ++i){
    for (int j = 0; j < probes; j++)
      node_array[i][j] = nodes[i][j];
  }

  //The following portion is hard coded, but will be supplied to this function
  //by the calling function later........

  //Stores total same chromosome gene sets
  // int tot_scg_sets = 0;  //0 for CC and 2 for BC datasets

  //2D array for storing same chromosome gene sets.
  //Each row represents a set of genes located on the same chromosome
  //First entry in each row represents how many genes are located on that chromosome
  //The next entries store the probe id of the genes



  //calculate and store the pairwise distance among the nodes in distance matrix
  generate_distance_matrix(distance, node_array, total_nodes, probes,0,steiner_node_generation_method,
                           tot_scg_sets, scg, probes_on_chromosome);

  //total halving events inferred in the tree
  int halving_counter = 0;
  //stores the indices of the edges along which a genome halving event is inferred
  vector<int> bad_edge_index(total_nodes);

  //store the copy number profile of the head node along an edge
  vector<int> n1(probes);
  //store the copy number profile of the tail node along an edge
  vector<int> n2(probes);

  //stores the SD+CD distance between the nodes along an edge
  int l1_dist = 0;

  //Loop through each edge to check if a genome halving event is inferred or not
  for (int i = 0; i < total_nodes-1; i++){

    //records the copy number profile of the head and tail nodes
    for (int j=0; j<probes; j++)
      n1[j] = nodes[edges[i][0]][j];
    for (int j=0; j<probes; j++)
      n2[j] = nodes[edges[i][1]][j];

    //stores the SD+CD distance between the two nodes
    if(tot_scg_sets == 0)
      l1_dist = l1(&n1[0],&n2[0],probes);
    else
      l1_dist = l1_CD(&n1[0],&n2[0],scg,tot_scg_sets,probes);

    //stores the inferred distance in the tree
    int real_dist = distance[edges[i][0]][edges[i][1]];

    //check if a whole genome duplication event is inferred
    //along that edge or not
    if(l1_dist > real_dist){

      //now check if the direction of the edge indicates a
      //halving event instead. If the head node's configuration
      //is lexicographically greater than the tail node's configuration
      //then a genome halving event is present.
      for (int j=0; j<probes; j++){
        if(n1[j] < n2[j]){
          break;
        }
        //head node's configuration lexicographically greater than
        //tail node's configuration. Increase the halving_counter variable
        //and store the edge index in bad_edge_index
        if(n1[j] > n2[j]){
          bad_edge_index[halving_counter] = i;
          halving_counter = halving_counter + 1;
          break;
        }
      }

    }
  }

  //Now loop through each of the halving edges
  for(int i = 0; i < halving_counter; i++){

    //store the halving edge index
    int k = bad_edge_index[i];
    //stores indices of the head and tail nodes respectively
    int nind1 = edges[k][0];
    int nind2 = edges[k][1];


    //naln(not allowed node) stores the indices of the descendants
    //of the tail node. The subtree rooted at the tail node cannot
    //be attached to any of these nodes
    vector<int> naln(total_nodes);

    //start and finish are used to populate naln
    int start = 0;
    int finish = 1;

    //first insert the tail node in naln
    naln[start] = nind2;

    //Use BFS to populate naln starting from the tail node
    while(1){
      //check if a new node has been found in this iteration or not
      int newnode = 0;

      //temp holds the last entry index in naln
      int temp = finish;

      //loop through each set of node inserted in the previous iteration
      for(int jj=start; jj<temp; jj++){

        //loop through the whole edge list
        for(int j = 0; j < total_nodes-1; j++){

          //if the head node of this edge matches the current node under
          //consideration, then insert the tail node in naln and update
          //the necessary variables
          if(edges[j][0] == naln[jj]){
            newnode = 1;
            naln[finish] = edges[j][1];
            finish = finish + 1;
          }
        }
      }
      //start index in the next iteration for naln
      start = temp;
      //if no new node is added to the list, then stop
      if(newnode == 0)
        break;
    } //end of while

    //now assign the distance between each node in naln and the
    //head node to LARGE_DISTANCE for subsequent manipulation
    for(int jj =0; jj < finish; jj++)
      distance[nind2][naln[jj]] = LARGE_DISTANCE;


    //distance between head and tail are also assigned to LARGE_DISTANCE
    distance[nind1][nind2] = distance[nind2][nind1] = LARGE_DISTANCE;
    distance[nind2][nind2] = LARGE_DISTANCE;

    //index of the nondescendant node that has minimum distance to tail
    int minind = 0;
    //corresponding minimum value
    int minvalue = LARGE_DISTANCE;

    //Go through each nondescendant node of tail and find the node
    //which is nearest and do not infer a genome halving event
    for(int j = 0; j < total_nodes; j++){

      //check if the distance is minimum so far
      if(distance[nind2][j] < minvalue){

        //Extra check to see if a whole genome halving event
        //is inferred from the new candidate node and the tail node.
        //store the configurations of the candidate node and the tail node
        for (int jj=0; jj<probes; jj++)
          n1[jj] = nodes[j][jj];
        for (int jj=0; jj<probes; jj++)
          n2[jj] = nodes[nind2][jj];

        //stores the SD+CD distance between the two nodes
        int l1_dist2 = 0;
        if(tot_scg_sets == 0)
          l1_dist2 = l1(&n1[0],&n2[0],probes);
        else
          l1_dist2 = l1_CD(&n1[0],&n2[0],scg,tot_scg_sets,probes);

        //checker is used to indicate if the candidate node
        //is lexicographically greater than the tail node
        int checker = 0;
        for(int jj=0; jj < probes; jj++){
          if(n1[jj] < n2[jj]){
            break;
          }
          if(n1[jj] > n2[jj]){
            checker = 1;
            break;
          }
        }
        //If a halving event is inferred, then ignore this
        //candidate node
        if((l1_dist2 > distance[nind2][j]) && (checker==1))
          continue;
        //store the current candidate node index and the distance value
        minvalue = distance[nind2][j];
        minind = j;
      }

    } //end of for(int j = 0; j < total_nodes; j++)

    //now change the node indices of the halving edge to include the new edge
    edges[k][0] = minind;
    edges[k][1] = nind2;

  } // end of outer for loop -- for(int i = 0; i < halving_counter; i++){

  delete [] node_array;
}
