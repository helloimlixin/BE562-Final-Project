#include <iostream>
#include <vector>

#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <climits>

#include "generate_mst.h"
#include "generate_steiner_trees.h"
#include "mst_prim.h"

using namespace std;

// Generates the minimum steiner tree using the exact approach
// tot_terminals is the total number of terminal nodes in the initial graph;
// the terminals are non-steiner nodes
// tot_candidates is the total number of candidate steiner nodes
// probes is the total number of probes selected by the user
// terminals stores the copy number count of each probe in each record
// candidates stores the copy number count of each probe in the infered steiner nodes
// mst_node_store stores the copy number counts of each node in the infered steiner tree
// mst_edge_store stores indices of the two nodes of each edge in the infered steiner tree
// mst_node_store and mst_edge_store are passed by reference
// The inferred steiner tree is stored in mst_node_store and mst_edge_store
// Returns the total number of nodes in the steiner tree
int generate_mst(int tot_terminals, int tot_candidates, int probes, int terminals[][MAX_PROBES], int candidates[][MAX_PROBES], int **mst_node_store, int **mst_edge_store)
{

  // Declare weight matrix for storing the rectilinear
  // distance among the nodes
  //AAS: Do you want resize or reserve here?
  vector<vector<int> > weight;
  weight.resize(tot_terminals + MAX_STEINER_NODES_EXACT);
  for (int i = 0; i < tot_terminals + MAX_STEINER_NODES_EXACT; ++i){
    weight[i].resize(tot_terminals + MAX_STEINER_NODES_EXACT);
  }

  // Declare weight matrix for storing the rectilinear distance among the nodes
  // steiner node themselves and among the steiner and terminal nodes
  vector<vector<int> > cand_weight;
  cand_weight.resize(tot_candidates);
  for (int i = 0; i < tot_candidates; ++i){
    cand_weight[i].resize(tot_terminals + tot_candidates);
  }

  // Generate and store the weight matrix for the terminal nodes and candidate steiner nodes
  generate_weight_matrix(weight, terminals, tot_terminals, cand_weight, candidates, tot_candidates, probes);
  // Store the minimum weight value for each node across all other nodes
  //int min_vector[tot_terminals];
  // Store maximum of the minimum weight values across all nodes
  int max_min = 0;
  // Store the node index at which maximum of minimum weight values are observed
  //int max_min_index = 0;

  // Store the node indices for which minimum weight entry is greater than 1.
  // Minimum weight of these nodes can be reduced by introducing a steiner node.
  vector<int> potential_indices(tot_terminals);
  // Store the minimum weight entries which are greater than 1.
  vector<int> potential_value(tot_terminals);
  // Total number of nodes whose minimum weight entry > 1
  int total_potentials = 0;
  // Store the total number of nodes whose minimum weight entry = 1
  int total_one_weight = 0;


  for (int i = 0; i < tot_terminals; i++){
    // Store the minimum weight entry for this node
    int min_weight = INT_MAX;
    // Iterate through each node's weight entries and identify the minimum weight entry.
    for (int j = 0; j < tot_terminals; j++){
      if((weight[i][j]) < min_weight && (i!=j))
        min_weight = weight[i][j];
    }

    // If the minimum at this stage is greater than the maximum of the minimums
    // identified so far, then store it
    if(min_weight > max_min){
      max_min = min_weight;
    }
    // If the minimum weight is 1, then increase the total_one_weight counter
    if(min_weight == 1)
      total_one_weight += 1;
    //min_vector[i] = min_weight;

    // If the minimum weight is greater than 1, then store this weight value
    // and corresponding node's index. Also increase the total_potential counter
    if(min_weight > 1){
      potential_indices[total_potentials] = i;
      potential_value[total_potentials] = min_weight;
      total_potentials += 1;
    }
  }
  // Stores the total number of steiner nodes included in the minimally
  // weighted steiner tree generated so far
  int steiner = 0;

  // min_weight_sofar stores the minimum weight of steiner trees generated so far
  int min_weight_sofar;

  // edges holds the node indices of each edge of the MST generated
  // at a particular iteration of the algorithm
  int (*edges)[2] = new int[tot_terminals + MAX_STEINER_NODES_EXACT][2];

  // Calculate cardinality of the solution set
  unsigned int total_trees = total_candidate_trees(tot_candidates);
  cout << "\nTotal " << total_trees << " trees will be tested using the exact approach" << flush;

  // Generate the 0-steiner node MST using the terminal nodes and
  // store its weight as the minimum one
  int mst_weight = mst_prim(tot_terminals,weight,edges, terminals, probes, INT_MAX);
  min_weight_sofar = mst_weight;

  // tot_nodes holds the copy number count of the probes of the terminals
  // and candidate steiner nodes
  int (*tot_nodes)[MAX_PROBES] =
    new int [tot_terminals + MAX_STEINER_NODES_EXACT][MAX_PROBES];

  // Store the 0-steiner node MST's node and edges
  for (int i = 0; i < tot_terminals + MAX_STEINER_NODES_EXACT; i ++){
    if(i < tot_terminals){
      for (int j = 0; j < probes; j++){
        mst_node_store[i][j] = tot_nodes[i][j] = terminals[i][j];
        if((i < (tot_terminals - 1)) && (j < 2))
          mst_edge_store[i][j] = edges[i][j];
      }
    }
  }

  // stores the precomputed number of trees to give user feedback
  vector<unsigned int> ratio_storage(10);

  // variable to compute total running time. Total running time
  // is computed based on time needed to generate 2% of the total trees
  unsigned int two_percent_trees = total_trees / 50;

  // compute and store the x% of trees generated so far, where x = 10,20,30 ... 100
  for (int i = 0; i < 10; i++){
    ratio_storage[i] = ((total_trees/10) * (i+1));
  }

  // Index into the ratio_storage array
  int next_ratio = 0;

  // keeps track of the number of trees tested so far
  unsigned int total_tree_generated = 0;

  // time variable to compute total tree generation time
  time_t begin,end;

  // start the stopwatch
  time(&begin);

  int loop_upper_bound;

  if (tot_candidates < MAX_STEINER_NODES_EXACT)
    loop_upper_bound = tot_candidates;
  else
    loop_upper_bound = MAX_STEINER_NODES_EXACT;

  // Consider subset of the candidate steiner nodes in building the MST.
  // Increase number of potential steiner nodes by 1 at each iteration.
  for (int tot_st = 1; tot_st <= loop_upper_bound; tot_st++){

    // Declare variable to hold the index of the candidate steiner nodes
    // to be considered at the current iteration; comb holds a set
    // of steiner nodes in ascending order
    vector<int> comb(tot_st);
    for (int i = 0; i < tot_st; i++)
      comb[i] = i;

    // cur_weight holds the minimum weight of the steiner trees generated
    // considering certain number and combinations of candidate steiner nodes
    int cur_weight = INT_MAX;

    while(1){
      total_tree_generated += 1;

      // if total tree generated so far equals to 2% of the total number of
      // trees, stop the stopwatch and report the total required running time
      if(total_tree_generated == two_percent_trees){
        time(&end);
        cout << "\nApproximate time required for generating " << total_trees << " trees: " << (end-begin)*50 << " seconds" << endl;
        cout << "\n0-steiner MST Weight: " << mst_weight << endl << flush;
      }

      // Gives feedback to the user what portion of search space has been explored
      if(next_ratio < 10 && total_tree_generated == ratio_storage[next_ratio]) {
        cout << "Percentage of the total trees generated: " << (next_ratio + 1) * 10 << ". Weight of minimum weighted tree generated so far: " << min_weight_sofar << "\r" << flush;
        next_ratio += 1;
      }

      // Store the maximum of the minimum weight entries at this iteration
      int biggest_min_here = max_min;
      // Store the lower bound on the weight of the mst
      int lower_bound_weight = total_one_weight;

      // Iterate through the list of potential nodes whose minimum weight
      // might get decreased after introduction of steiner nodes
      for (int i = 0; i < total_potentials; i++){
        // Store the index of the node with minimum weight > 1
        int index = potential_indices[i];
        // Store the updated min value
        int new_min_weight = potential_value[i];

        // Iterate through all the steiner nodes to see if this nodes minimum
        // weight has been decreased
        for (int j = 0; j < tot_st; j++){
          if(cand_weight[comb[j]][index] < new_min_weight)
            new_min_weight = cand_weight[comb[j]][index];

          // If lowest minimum has been achieved, then do not continue
          if(new_min_weight == 1)
            break;
        }

        // Add the new min weight to the lower bound weight
        lower_bound_weight += new_min_weight;
      }

      // Now iterate through the newly added steiner nodes to
      // identify their minimum weight matrix entries
      for (int i = 0; i < tot_st; i++){
        // Stores the min value for a particular steiner node
        int steiner_min = INT_MAX;
        // First iterate through all the terminal nodes to
        // identify the minimum weight value
        for(int j = 0; j < tot_terminals; j++){
          if(steiner_min > cand_weight[comb[i]][j])
            steiner_min = cand_weight[comb[i]][j];
          // If lowest minimum has been achieved, then do not continue
          if(steiner_min == 1)
            break;
        }

        // Now iterate through all the steiner nodes to
        // update the minimum weight value
        for(int j = 0; j < tot_st; j++){
          // If lowest minimum has been achieved, then do not continue
          if(steiner_min == 1)
            break;
          if((steiner_min > cand_weight[comb[i]][tot_terminals+comb[j]]) && (comb[i]!=comb[j]))
            steiner_min = cand_weight[comb[i]][tot_terminals+comb[j]];
        }
        // Check if the minimum weight identified in this stage
        // is the max of min
        if(biggest_min_here < steiner_min)
          biggest_min_here = steiner_min;
        // Add the min at this stage to the lower bound weight
        lower_bound_weight += steiner_min;
      }

      // Deduct the max of min from the lower bound weight
      lower_bound_weight -= biggest_min_here;

      // If the lower bound weight is less than the minimum weight identified
      // so far, then generate the mst and calculate the real mst weight
      if ( lower_bound_weight < min_weight_sofar) {
        // For a particular combination of the candidate steiner nodes,
        // include the corresponding steiner nodes in building the MST.
        // Also, update the weight matrix using the precomputed cand_weight matrix

        for (int i = 0; i < tot_st; i++){
          for (int j = 0; j < probes; j++){
            tot_nodes[tot_terminals+i][j] = candidates[comb[i]][j];
          }
          for(int k = 0; k < tot_terminals; k++)
            weight[tot_terminals+i][k] = weight[k][tot_terminals+i] = cand_weight[comb[i]][k];

          for(int j = 0; j <= i; j++)
            weight[tot_terminals+j][tot_terminals+i] = weight[tot_terminals+i][tot_terminals+j] =  cand_weight[comb[i]][tot_terminals+comb[j]];
        }

        // Generate the MST using the terminal nodes and a particular
        // combination of the steiner nodes
        int now_weight = mst_prim(tot_terminals+tot_st,weight,edges,tot_nodes,probes,min_weight_sofar);
        //cout << now_weight << "(" << total_tree_generated << ")" << "\t";

        // If the weight of the steiner tree generated at the current iteration
        // is of minimum weight so far, save the steiner tree, its weight
        // and the number of steiner nodes included
        // We may want to do something to break ties here
        if(now_weight < min_weight_sofar){
          steiner = tot_st;
          min_weight_sofar = now_weight;

          for (int i = 0; i < tot_terminals + tot_st; i++)
            for (int j = 0; j < probes; j++){
              mst_node_store[i][j] = tot_nodes[i][j];
              if((i < (tot_terminals + tot_st - 1)) && (j < 2))
                mst_edge_store[i][j] = edges[i][j];
            }
        }
        // Update the minimum weight of the trees generated at the current stage
        if(cur_weight > now_weight)
          cur_weight = now_weight;
      } // end if ( lower_bound_weight < min_weight_sofar)
      // Generate the combination of steiner nodes to be considered
      // for the next iteration
      int ret = generate_combination(&comb[0], tot_st, tot_candidates);

      // If all the possible combinations have been considered, then break
      if(ret == 0)
        break;
    }
    //cout << "\n" <<tot_st << "-steiner MST generated. Minimum tree weight at this stage: " << cur_weight;

  }

  cout << "\nSteiner Tree Generated.";
  cout << "\nNumber of inferred Steiner nodes:: " << steiner << ". Steiner Tree weight:: " << min_weight_sofar;

  delete [] edges;
  delete [] tot_nodes;

  return (tot_terminals + steiner);
}

// Generate the matrix whose entries are the pairwise distances amongst
// the nodes which constitutes the candidate steiner tree
// weight stores the pairwise distance values amongst the terminal nodes
// terminals stores the copy number count of each probe in each record
// tot_terminals is the total number of terminals
// cand weight stores the pairwise distance values amongst 1)candidate steiner nodes
// themselves and 2)candidate steiner nodes and non-steiner terminal nodes
// For category 2), the first index is the steiner node and the second index is
// the non-steiner terminal
// tot_cand is the total number of candidate steiner nodes
// probes is the total number of probes selected by the user
// weight and cand_weight are passed by reference
// Updated weight matrixes are stored in weight and cand_weight
void generate_weight_matrix(vector<vector<int> > &weight, int terminals[][MAX_PROBES], int tot_terminals, vector<vector<int> > &cand_weight, int cand[][MAX_PROBES], int tot_cand,int probes)
{

  // First calculate the pairwise distance amongst the terminal nodes and store them in weight matrix
  // Iterate through each pair of node
  for(int i = 0; i < tot_terminals; i++){
    for(int j = 0; j < tot_terminals; j++){

      // Fill the diagonal entries of the weight matrix with 0
      if(i == j)
        weight[i][j] = 0;

      // For non-diagonal entries, calculate the rectilinear distances
      // amongst the corresponding nodes
      else {
        int w = 0;
        for (int k = 0; k < probes; k++)
          w = w + abs(terminals[i][k]-terminals[j][k]);
        weight[i][j] = weight[j][i] = w;
      }
    }
  }

  // Calculate the pairwise distance values amongst 1)candidate steiner nodes
  // themselves and 2)candidate steiner nodes and terminal nodes and store them in cand_weight
  // For each candidate steiner node, iterate through the terminal nodes first
  for (int i = 0; i < tot_cand; i++){
    for (int j = 0; j < tot_terminals; j++){
      int w = 0;
      for (int k = 0; k < probes; k++)
        w = w + abs(terminals[j][k]-cand[i][k]);
      cand_weight[i][j] = w;
    }
    // After iterating through the terminal nodes, iterate through the candidate steiner nodes
    for (int j = 0; j < tot_cand; j++){
      int w = 0;
      for (int k = 0; k < probes; k++)
        w = w + abs(cand[i][k]-cand[j][k]);
      cand_weight[i][tot_terminals+j] = w;

    }
  }
}



// Generate the combination of steiner nodes for inclusion in the MST
// building segment. Combination of steiner nodes with terminal nodes
// are used to build MST which are then compared for building the
// minimum weight steiner trees
// comb holds the previous combinations of the indices
// k is the number of elements to be chosen at each stage
// n is the total number of elements in the set which to be chosen from
// comb is passed by reference and stores the generated combination
// Returns 0 if all the combinations have been generated, otherwise return 1
int generate_combination(int comb[], int k, int n)
{
  // Start from the back of the comb array
  int i = k - 1;
  ++comb[i];

  //Given the combination (c0, c1, ..., cn), start from the back
  //and for ci, if it is larger than (n - k + 1 + i) then increment
  //it and go on to the previous index --i.
  while ((i >= 0) && (comb[i] >= n - k + 1 + i)) {
    --i;
    if (i >= 0)
      ++comb[i];
  }

  // Combination (n-k, n-k+1, ..., n) reached
  if (comb[0] > n - k){
    //No more combinations can be generated
    return 0;
  }

  // comb now looks like (..., x, n, n, n, ..., n).
  // Turn it into (..., x, x + 1, x + 2, ...)
  for (i = i + 1; i < k; ++i)
    comb[i] = comb[i - 1] + 1;
  return 1;
}


// Calculates the total number of candidate steiner trees that will
// be generated using the exact approach
// total_steiner_nodes is the total number of infered candidate steiner nodes
// Returns total number of candidate steiner trees
unsigned int total_candidate_trees(int total_steiner_nodes)
{
  // total_trees holds the total number of steiner trees
  unsigned int total_trees = 0;
  // Combinations are generated using the nCr = (n*(n-1)*....(n-r+1))/r! formula
  unsigned int r;

  int loop_upper_bound;

  if (total_steiner_nodes < MAX_STEINER_NODES_EXACT)
    loop_upper_bound = total_steiner_nodes;
  else
    loop_upper_bound = MAX_STEINER_NODES_EXACT;

  for(int i = 1; i <= loop_upper_bound; i++){

    // Calculate (n*(n-1)*....(n-r+1))
    unsigned int temp = 1;

    for (int j = total_steiner_nodes; j >= (total_steiner_nodes - i + 1); j--){
      temp = temp * j;
    }

    // Calculate r!
    r = 1;
    for (int j = 1; j <= i; j++)
      r = r * j;

    total_trees += (temp / r);
  }
  return total_trees;
}
