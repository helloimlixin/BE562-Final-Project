// This is the main code file of the package FISHtrees to implement
// multiple methods for modelling the progression of copy number
// changes in signle cells of a tumor. Details of the input
// format and usage can be found in the README file that is
// included in the release.
// The input data may include for each cell an estimate of its
// "ploidy" which is the mode of the copy number of each
// autosome (chromosomes 1-22 in humans).
// FISHtrees includes modeling methods that do as well as
// methods that do not use the ploidy information.
// Throughout the code and comments, the methods that do use the
// ploidy are called "ploidy-based" and the methods that do not
// use the ploidy are called "ploidyless" or "ploidy-less".
// The original ploidy-based method for two probes was described in:
//
// Pennington G, Smith CA, Shackney S, Schwartz R: Reconstructing tumor
// phylogenies from heterogeneous single-cell data. J Bioinform Comput
// Biol 2007, 5:407-427.
//
// The next paragraph in this comment
// is an excerpt from Pennington et al., describing the work.
// Other parts of the ploidy-based code in other code files
// also include excerpts from the Pennington et al. 2007 paper to
// aid the reader in seeing how parts of the code match parts of the
// paper/

// Studies of gene expression in cancerous tumors have revealed that
// tumors presenting indistinguishable symptoms in the clinic can be
// substantially different entities at the molecular level. The ability
// to distinguish between these genetically distinct cancers will make
// possible more accurate prognoses and more finely targeted
// therapeutics, provided we can characterize commonly occurring cancer
// sub-types and the specific molecular abnormalities that produce them.
// We develop a new method for identifying these common tumor
// progression pathways by applying phylogeny inference algorithms to
// single-cell assays, taking advantage of information on tumor
// heterogeneity lost to prior microarray-based approaches. We combine
// this approach with expectation maximization to infer unknown
// parameters used in the phylogeny construction. We further develop new
// algorithms to merge inferred trees across different assays. We
// validate the expectation maximization method on simulated data and
// demonstrate the combined approach on a set of fluorescent in situ
// hybridization (FISH) data measuring cell-by-cell gene and chromosome
// copy numbers in a large sample of breast cancers. The results further
// validate the proposed computational methods by showing consistency
// with several previous findings on these cancers and provide novel
// insights into the mechanisms of tumor progression in these patients.
//
// The ploidy-less methods have been developed in stages and described
// in separate manuscripts. Constants declared in fish.h determine which
// ploidy-less method is being used.
// The methods associated with the constants
// PLOIDY_LESS_EXACT and PLOIDY_LESS_HEURISTIC
// were described in
// Chowdhury SA, Shackney SE, Heselmeyer-Haddad K, Ried T, Schaffer AA,
// Schwartz R: Phylogenetic Analysis of Multiprobe Fluorescence in Situ
// Hybridization Data from Tumor Cell Populations. Bioinformatics
// 2013, 29:i189-i198.
// These two methods consider only single gene changes (denoted SD)
//
// The method associated with the constant
// PLOIDY_LESS_HEURISTIC_GENOME_DUPLICATION
// was described in
// Chowdhury SA, Shackney SE, Heselmeyer-Haddad K, Ried T, Schaffer AA,
// Schwartz R: Algorithms to Model Single Gene, Single Chromosome, and
// Whole Genome Copy Number Changes Jointly in Tumor Phylogenetics.
// PLoS Computational Biology 2014, 10:e1003740.
//
// This method combines single gene changes (SD), single chromosome
// changes (CD) and whole genome duplications (GD) assigning them
// all equal weights.
//
// The method associated with the constant
// PLOIDY_LESS_HEURISTIC_WEIGHTED
// is under development in late 2014. It uses CD, CD, and GD events
// with different weights.

#include <iostream>
#include <fstream>
#include <sstream>

#include <cstdlib>
#include <cstring>
#include <cfloat>


#include "branching.h"
#include "consensus.h"
#include "edge.h"
#include "em.h"
#include "fish.h"
#include "generate_steiner_trees.h"
#include "graph.h"
#include "merge.h"
#include "node.h"
#include "obs_graph.h"
#include "output.h"
#include "patient_data.h"
#include "steiner.h"
#include "utility.h"

using namespace std;

#ifndef VERBOSE
#define VERBOSE 0
#endif

#ifndef PRINT_STEINER_INSTANCES
#define PRINT_STEINER_INSTANCES 0
#endif

// To get Steiner tree instances as separate output files
//#define PRINT_STEINER_INSTANCES

//This procedure initializes the input graph;
//name_chr contains the name of the ploidy probes
//name_gene contains the names of the gene probes.
static void
init_input_graph(vector<graph*> & input_graph,
                 const vec_names & name_chr, const vec_names & name_gene)
{
  int number_of_pairs = name_gene.size();

  // Initialize input graph for each pair of chromosome probe and gene probe.
  for (int index_pair = 0; index_pair < number_of_pairs; index_pair++) {
    // Check if only gene probes are used.
    if (GENE_PROBES_ONLY) {
      // Declare string stream to store label.
      stringstream ss_label;

      // Initialize label to be (ref_chr,ref_gene)=(in_chr,in_gene).
      ss_label << name_chr[index_pair] << "+" << name_gene[index_pair];

      // Write string stream into label.
      input_graph[index_pair] = new graph(ss_label.str());
    }
    // Check if chromosome or ploidy is used.
    else {
      input_graph[index_pair] = new graph(name_gene[index_pair]);
    }
  }
}


static void
print_possible_graph(const obs_graph & possible_graph)
{
  // Output all possible nodes in the program.
  cout << "State space = (#chromosomes,#genes)" << endl;
  output_possible_graph(possible_graph);
  cout << endl;

  // Output a graph of all possible nodes and edges into a file.
  output_possible_graph_in_dot_format(POSSIBLE_GRAPH_DOT, possible_graph);
}


/**
 * Use a ploidy-based approach to generate a consensus graph.
 *
 * The generated graphs, and intermediate trees, are printed to files.
 * name_chr contains the names of the ploidy probes
 * name_gene contains the name of the gene probes
 * patient_file_paths has the paths to the data file for each sample
 * directory is a string used to disambiguate output file name
 * reorder_genes a flag to indicate whether trees should be joined in
 *    the order given (false) or reordered heuristically (true)
 */
static void
do_ploidy_based(const vec_names & name_chr,
                const vec_names & name_gene,
                const string & directory,
                const vec_names & patient_file_paths,
                patient_data all_patient_data[],
                bool reorder_genes)
{
  int number_of_files = patient_file_paths.size();
  int number_of_pairs = name_chr.size();

  // Allocate storage for an array of joint trees.
  vector<graph *> joint_tree(number_of_files);

  // Process files one-by-one.
  for(size_t index_file = 0;
      index_file < patient_file_paths.size();
      index_file++) {

    const string & filepath = patient_file_paths[index_file];
    string filename = patient_data::basename(filepath);

    patient_data & pd = all_patient_data[index_file];

    // Allocate storage for a reference array of graphs read from patient
    // data files. One graph per probe pair and re-used by every patient.
    vector<graph *> input_graph(number_of_pairs);
    init_input_graph(input_graph, name_chr, name_gene);

    // Allocate storage for a reference array of probe trees.
    vector<graph*> probe_tree(number_of_pairs);


    // Output summary of the problem instance being solved
    cout << "Beginning of ploidy-based output for sample "
         << filename << " and probes ";
    for (int index_pair = 0; index_pair < number_of_pairs; index_pair++) {
      cout << name_chr[index_pair] << "\t" << name_gene[index_pair] << "\t";
    }
    cout << endl;
    // Loop through every pair of queried chromosome probe and gene probe.
    for (int index_pair = 0; index_pair < number_of_pairs; index_pair++) {

      // Output pair of chromosome probe and gene probe.
      cout << "Pair " << index_pair + 1 << " for " << filename
           << " = (" << name_chr[index_pair]
           << "," << name_gene[index_pair] << ")\n" << endl;

      // In "2.3. Optimal tree inference", "Let G' = (V',E') be a directed
      // graph of all possible states and edges".
      // possible_graph is a two-dimensional matrix of states as nodes.
      // First dimension is the copy number of chromosome probe.
      // Second dimension is the copy number of gene probe.
      // The children field in each node gives all possible mutations as edges.
      obs_graph possible_graph(pd.cell_count[index_pair]);

      if (VERBOSE) {
        print_possible_graph(possible_graph);

        cout << "Input state frequencies =" << endl;
        output_node_frequencies(possible_graph.frequencies);
        cout << endl;
      }

      // Locate a low-frequency noisy state, whose frequency is less
      // than f(%) of the sum of frequencies of its neighbors.
      filter_low_frequency_states2(possible_graph.frequencies, pd.total_cells);

      // Add minimal frequency to root state, if its frequency is zero.
      if(possible_graph.frequencies[NORMAL_COPY][NORMAL_COPY] < DBL_EPSILON){
        possible_graph.frequencies[NORMAL_COPY][NORMAL_COPY] = 1.0;
      }

      // Build graph for non-zero frequency states.
      // In "2.3. Optimal tree inference", "1: Convert the FISH matrix
      // for an individual patient into a graph G", "2: Add all edges
      // to G allowed by the connectivity model of Sec. 2.2".
      input_graph[index_pair]->
        set_nodes_and_edges(name_chr[index_pair], name_gene[index_pair],
                            possible_graph, &pd.list_counts);

      if (VERBOSE) {
        // Output graph (as list of edge lists as each edge list
        // contains source node and list of target nodes).
        cout << "Non-zero-frequency mutation list = " <<
          "parent index and state[|mutation type:child state]..." <<
          endl;
        output_graph(input_graph[index_pair]);
        cout << endl;
      }

      // Array of probabilities of all mutation types.
      double_vector mutation_prob;

      // Calculate mutation probabilties vector.
      input_graph[index_pair]->calculate_mutation_probabilities
        (mutation_prob);

      // Output mutation counts and prior probabilities vectors.
      cout << "Mutation types and prior probabilities =" << endl;
      output_mutation_probabilities(mutation_prob,
                                    name_chr[index_pair],
                                    name_gene[index_pair]);
      cout << endl;

      // Perform Steiner node inference.
      // In "2.3. Optimal tree inference", "3: Apply Algorithm 1 to
      // add Steiner nodes until G is connected".
      perform_steiner_node_inference(input_graph[index_pair],
                                     name_chr[index_pair],
                                     name_gene[index_pair], possible_graph,
                                     mutation_prob, &pd.list_counts);

      // Output size of the input graph as number of nodes.
      cout << "Number of nodes in the input graph = " <<
        input_graph[index_pair]->get_number_of_nodes() << endl;
      cout << endl;

      if (VERBOSE) {
        // Output frequencies matrix.
        cout << "Filtered and connected state frequencies =" << endl;
        output_node_frequencies(possible_graph.frequencies);
        cout << endl;

        // Output filtered and normalized frequencies matrix.
        cout << "Normalized state frequencies =" << endl;
        output_graph_as_table_of_node_frequencies(input_graph[index_pair]);
        cout << endl;
      }

      // Set edge weight for branching as node frequency times edge
      // probability
      // In "2.3. Optimal tree inference", "Once we have ensured that
      // every node of G is reachable, we add a weight function
      // w(v,u) = f_v p(u,v) to G".
      input_graph[index_pair]->set_edge_weight_probability(mutation_prob);
      input_graph[index_pair]->take_log_of_weights_for_highweight_branching();

      // Perform branching to find maximum weight arborescence.
      // In "2.3. Optimal tree inference", "4: Find a minimum-cost
      // arborescence on G by the method of Chu and Liu".
      probe_tree[index_pair] =
        findHighWeightBranching(input_graph[index_pair], true);

      assignParents(probe_tree[index_pair]);

      if (0) {
      // Output maximum weight arborescence in Newick tree format.
      cout << "Maximum weight arborescence in Newick tree format =" <<
        endl;
      output_tree_in_newick_format(stdout, probe_tree[index_pair]);
      cout << endl;
      }

      srandom(SEED);
      // Perform parameter inference.
      // In "2.4. Parameter inference", "We estimate the parameter set
      // \theta by EM".
      perform_parameter_inference(probe_tree[index_pair],
                                  input_graph[index_pair],
                                  name_chr[index_pair],
                                  name_gene[index_pair], possible_graph,
                                  mutation_prob);

      // Transfer ownership of the nodes to the probe_tree.
      input_graph[index_pair]->list_of_nodes.clear();

      // Output mutation counts and prior probabilities vectors.
      cout << "Mutation types and inferred probabilities =" << endl;
      output_mutation_probabilities(mutation_prob,
                                    name_chr[index_pair],
                                    name_gene[index_pair]);
      cout << endl;

      if (0) {
      // Output inferred maximum weight arborescence in Newick tree format.
      cout << "Inferred maximum weight arborescence in Newick tree format ="
        << endl;
      output_tree_in_newick_format(stdout, probe_tree[index_pair]);
      cout << endl;
      }

      // Output inferred maximum weight arborescence in DOT format.
      cout << "Inferred maximum weight arborescence in DOT format = "
        << filename << "." << probe_tree[index_pair]->get_label()
        << ".dot" << endl;
      output_tree_in_dot_format(filename, probe_tree[index_pair]);
      cout << endl;

      // Output inferred maximum weight arborescence with node
      // frequencies and edge weights.
      cout << "Inferred maximum weight arborescence in list format ="
        << endl;
      output_tree_with_node_frequency_and_edge_weight(probe_tree[index_pair]);
      cout << endl;

      if (!reorder_genes) {
        // Since we are not reordering genes, we merge the new
        // single-gene tree with the existing joint tree as soon as it
        // is created, because we have traditionally printed the
        // merged tree as soon as we have it.  If we are reordering genes,
        // we'll merge the trees later.

        // Check if this is the first pair of probes.
        if (index_pair == 0) {
          // Move the first tree, setting probe_tree[index_pair] to NULL
          // so that it will not be deleted twice.
          joint_tree[index_file] = probe_tree[index_pair];
          probe_tree[index_pair] = NULL;
        }
        // Check if this is not the first pair of probes.
        else {
          // Merge two trees.
          graph * prev_joint_tree = joint_tree[index_file];
          bool is_optimal;
          edge_counts_type edge_counts;
          merge_trees(&joint_tree[index_file], edge_counts, is_optimal,
                      prev_joint_tree, probe_tree[index_pair], filename,
                      &pd.list_counts);

          prev_joint_tree->list_of_nodes.clear();
          delete prev_joint_tree;

          // Check if this is the last pair of probes.
          // DISABLE trimming of Steiner leaf nodes.  If the leaf nodes prove
          // to be useful, we may delete this code entirely.
          if (false && index_pair == (number_of_pairs - 1)) {
            // Trim leaf Steiner nodes from the joint tree.
            joint_tree[index_file]->trim_leaf_steiner_nodes();
          }

          cout << "\nMutation table=\n"
               << as_mutation_table(edge_counts, name_gene, name_chr)
               << "\n" << endl;

          // Output size of the input graph as number of nodes.
          if (0) {
            cout << "Number of nodes in the joint tree = " <<
              joint_tree[index_file]->get_number_of_nodes() << endl;
            cout << endl;
          }

          // Output joint tree in DOT format.
          output_tree_in_dot_format(filename, joint_tree[index_file]);
          cout << endl;

          // Output joint tree in list format.
          if (is_optimal) {
            cout << "Joint tree in list format =" << endl;
          } else {
            cout << "Suboptimal joint tree in list format =" << endl;
          }
          output_tree_with_node_frequency_and_edge_weight(
            joint_tree[index_file]);
          cout << endl;
        }
      } // End if (!reorder_genes)
    } // for (int index_pair = 0; index_pair < number_of_pairs; index_pair++)
    if (reorder_genes) {
      joint_tree[index_file] =
        reorder_and_merge_trees(name_gene, probe_tree, filename,
                                &pd.list_counts);

      // Output joint tree in DOT format.
      output_tree_in_dot_format(filename, joint_tree[index_file]);
      cout << endl;

      // Output joint tree in list format.
      cout << "Joint tree in list format =" << endl;
      output_tree_with_node_frequency_and_edge_weight(joint_tree[index_file]);
      cout << endl;
    }
    // Loop through every pair of chromosome/ploidy and gene probe.
    for (int index_pair = 0; index_pair < number_of_pairs; index_pair++) {
      // Delete input graph for each pair of chromosome/ploidy and
      // gene probe.
      delete input_graph[index_pair];
    }
    for (int i = 0;  i < number_of_pairs;  i++) {
      delete probe_tree[i];
    }
  }
  if (number_of_files > 1 && !reorder_genes) {
      // Do consensus: we cannot do it for just one file (that would
      // be pointless), or if we have reordered genes (because between files
      // the genes are unlikely to be reordered the same way).

      //  Declare graph to consensus all joint trees.
      graphconsensus *consensus_joint_graph = NULL;

      // Consensus all joint trees.
      consensus_network(&consensus_joint_graph, &joint_tree[0],
                        number_of_files);

      // Output consensus graph in DOT format.
      consensus_joint_graph->
          output_at_least_threshold_in_dot_format(directory, PLOIDY_BASED, 1.0);
      cout << endl;

      // Output consensus nodes in list format.
      cout << "Consensus nodes (1.0) in list format =" << endl;
      consensus_joint_graph->output_at_least_threshold_nodes(PLOIDY_BASED, 1.0);
      cout << endl;

      // Output consensus nodes reachable from root consensus node in list format.
      cout << "Consensus nodes (1.0) reachable from root in list format ="
          << endl;
      consensus_joint_graph->
          output_at_least_threshold_nodes_from_root(PLOIDY_BASED, 1.0);
      cout << endl;

      // Output consensus nodes and edges reachable from root consensus node
      // in list format.
      cout <<
          "Consensus nodes and edges (1.0) reachable from root in list format ="
          << endl;
      consensus_joint_graph->
          output_at_least_threshold_nodes_and_edges_from_root(PLOIDY_BASED, 1.0);
      cout << endl;

      // Output consensus nodes and paths reachable from root consensus node
      // in list format.
      cout <<
          "Consensus nodes and paths (1.0) reachable from root in list format ="
          << endl;
      consensus_joint_graph->
          output_at_least_threshold_nodes_and_paths_from_root(PLOIDY_BASED, 1.0);

      cout << endl;

      delete consensus_joint_graph;
  }

  // Now that the consensus joint graph has been deleted, there
  // are no more references to the nodes of the joint_trees, and
  // so they may be deleted.
  for (int ifile = 0; ifile < number_of_files; ifile++) {
    // Delete joint tree for each patient data file.
    joint_tree[ifile]->deep_delete_nodes();
    delete joint_tree[ifile];
  }
}


/**
 * Use a ploidy-less approach to generate a consensus graph.
 *
 * The 'ploidy_less_approach' parameter determines which approach is
 * used. The generated graphs, and intermediate trees, are printed to
 * files.
 */
static void
do_ploidy_less(const vec_names & name_chr,
               const vec_names & name_gene,
               const string & directory,
               const vec_names & patient_file_paths,
               patient_data all_patient_data[],
               int ploidy_less_approach)
{
  int number_of_files = patient_file_paths.size();
  int number_of_probes = name_chr.size();

  // Allocate storage for an array of pattern trees.
  vector<graph *> pattern_tree(number_of_files);

  for(size_t index_file = 0;
      index_file < patient_file_paths.size();
      index_file++) {

    const string & filepath = patient_file_paths[index_file];
    string filename = patient_data::basename(filepath);

    // Output summary of the problem instance being solved
    cout << "Beginning of ploidyless output for sample "
         << filename << " and probes ";
    for (int index_pair = 0; index_pair < number_of_probes; index_pair++) {
      cout << name_chr[index_pair] << "\t" << name_gene[index_pair] << "\t";
    }
    cout << endl;

    patient_data & pd = all_patient_data[index_file];

    pattern_tree[index_file]=
      generate_steiner_trees(number_of_probes, name_gene, pd.terminals,
                             pd.cell_counter, pd.total_record,
                             ploidy_less_approach, pd.tot_scg_sets, pd.scg,
                             &pd.probes_on_same_chromosome[0]);
    print_graph(pattern_tree[index_file]);
    cout << endl;               // an extra blank line

    output_tree_in_dot_format(filename, pattern_tree[index_file]);

    if(PRINT_STEINER_INSTANCES) {
      output_steiner_instance(filename, number_of_probes, pd.terminals,
                              pd.total_record, pd.cell_counter);
    }
  }
  if (number_of_files > 1) {
    // Declare graph to consensus all joint trees.
    graphconsensus *consensus_pattern_graph = NULL;

    // Consensus all pattern trees.
    consensus_network(&consensus_pattern_graph, &pattern_tree[0],
                      number_of_files);

    // Output consensus pattern graph in DOT format.
    consensus_pattern_graph->
      output_at_least_threshold_in_dot_format(directory, PLOIDY_LESS, 1.0);
    cout << endl;

    // Output consensus nodes in list format.
    cout << "Consensus pattern nodes (1.0) in list format =" << endl;
    consensus_pattern_graph->output_at_least_threshold_nodes(PLOIDY_LESS, 1.0);
    cout << endl;

    // Output consensus nodes reachable from root consensus node in list format.
    cout << "Consensus pattern nodes (1.0) reachable from root in list format ="
         << endl;
    consensus_pattern_graph->
      output_at_least_threshold_nodes_from_root(PLOIDY_LESS, 1.0);
    cout << endl;

    // Output consensus nodes and edges reachable from root consensus node
    // in list format.
    cout << "Consensus pattern nodes and edges (1.0) reachable from root "
         << "in list format =" << endl;
    consensus_pattern_graph->
      output_at_least_threshold_nodes_and_edges_from_root(PLOIDY_LESS, 1.0);
    cout << endl;

    // Output consensus nodes and paths reachable from root consensus node
    // in list format.
    cout << "Consensus pattern nodes and paths (1.0) reachable from root in "
         << "list format =" << endl;
    consensus_pattern_graph->
      output_at_least_threshold_nodes_and_paths_from_root(PLOIDY_LESS, 1.0);
    cout << endl;

    delete consensus_pattern_graph;
  }
  for (int i = 0;  i < number_of_files;  i++) {
    if (pattern_tree[i]) {
      pattern_tree[i]->deep_delete_nodes();
      delete pattern_tree[i];
    }
  }
}

// Structure to hold command line options for the fish executable.
struct fish_options {
  enum { do_reorder_genes = true, dont_reorder_genes = false };
  bool reorder_genes;
  fish_options(bool r = dont_reorder_genes) : reorder_genes(r) {}
};

// Process the arg list, recording and *removing* all options from
// argv
fish_options fish_process_options(int & argc, char **& argv)
{
  if (argc > (2 * (MAX_PROBES+2))) {
    fprintf(stderr, "The number of arguments %d exceeds two times (MAX_PROBES+2)\n",argc);
    fprintf(stderr, "Increase MAX_PROBES in constants.h and rerun make to recompile\n");
    exit(EXIT_FAILURE);
  }
  for (int i = 1;  i < argc;  i++) {
    if (string("--choose-gene-order") == argv[i]) {
      std::copy(argv + i + 1, argv + argc, argv + i);
      --argc;
      return fish_options(fish_options::do_reorder_genes);
    }
    else if ((argv[i][0] == '-') && (argv[i][1] == '-')) {
      cerr << "Unrecognized option: " << argv[i] << endl;
      cerr << "Usage: " << argv[0] << " [ --choose-gene-order ] args...";
      cerr << endl;
      exit(EXIT_FAILURE);
    }
  }
  return fish_options(fish_options::dont_reorder_genes);
}

// Program entry point.
// Usage: <this program> <patient data directory> <chromosome probe 1>
//        <gene probe 1> <chromosome probe 2> <gene Probe 2> ...
//        <mode for ploidy-less method 1 or 2>
int main(int argc, char *argv[])
{
  // the first two arguments are program name
  // and patient data directory
  string directory;


  // The absolute value of the last argument is the method for
  // ploidy-less trees.
  // If the last argument is nonnegative, then model_ploidy becomes 1;
  // If the last argument is negative, then model_ploidy becomes 0.
  // Either model_ploidy or ploidy_less_approach or both can be nonzero
  // and that determines whether the ploidy-based or ploidy-less methods,
  // or both are used.
  int model_ploidy, ploidy_less_approach;

  // Symbols of queried chromosome probes and gene probes.
  vec_names name_chr, name_gene;

  // Process and remove commmand line options.
  fish_options opt = fish_process_options(argc, argv);

  // Process and echo command line arguments; these do not include options
  // but are rather what is left after options are removed.
  process_command_line_arguments(argc, argv, directory,
                                 name_chr, name_gene,
                                 model_ploidy,
                                 ploidy_less_approach);

  vec_names patient_file_paths = patient_data::find_patient_files(directory);
  int number_of_files = patient_file_paths.size();
  if (0 == number_of_files) {
    cerr << "No files with substring " << "`" << INPUT_TXT
         << "'" << " in the filename found in directory " << "`"
         << directory << "'" << endl;
    exit(EXIT_FAILURE);
  }


  // Initialize seed for random number generator.
  srandom(SEED);

  // Array holding data for each patient (can't be a vector unless
  // class patient_data is made copyable).
  patient_data * all_patient_data = new patient_data[number_of_files];

  // Process files one-by-one.
  for (size_t index_file = 0;
       index_file < patient_file_paths.size();
       index_file++) {
    all_patient_data[index_file].parse_file(name_chr, name_gene,
                                            patient_file_paths[index_file]);
  }

  if (model_ploidy) {
    do_ploidy_based(name_chr, name_gene, directory,
                    patient_file_paths, all_patient_data,
                    opt.reorder_genes);
  }

  if(ploidy_less_approach) {
    do_ploidy_less(name_chr, name_gene, directory,
                   patient_file_paths, all_patient_data,

                   ploidy_less_approach);
  }

  delete [] all_patient_data;

  cout << "FISHtrees finished." << endl;
  // End program successfully.
  return 0;
} // int main(int argc, char *argv[])
