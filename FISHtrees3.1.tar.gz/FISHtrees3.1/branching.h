#ifndef _BRANCHING_
#define _BRANCHING_

#include "node.h"
#include "edge.h"
#include "graph.h"

/*Given an input graph G, makeGreedyGraph creates a subgraph by choosing,
  at each node, the edge coming into that node of maximum positive
  weight.  If no such edge exists, it leaves the node in question as a
  source.  The greedy graph will be the maximum weight branching whenever
  it is acyclic.*/
graph *makeGreedyGraph(graph *G);

/* weighCycle toggles the 'isInCycle' flags of all the vertices of G
   in the same cycle as v, and returns the minimum edgeweight of the cycle */
double weighCycle(node *v, graph *G);

/*ancestor returns TRUE if the parental path from v includes w. The
  parental paths are created in the greedy graph, and modified
  throughout the recoverGraph function.  Each cycle should be removed
  by the end of the recovery. numNodes will be passed the number of nodes of
  the graph being tested*/
bool ancestor(node *v, node *w, int numNodes);

/*sameCycle returns TRUE if v is an ancestor of w, and vice versa, i.e.
  if v and w are in the same cycle of the greedy graph */
bool sameCycle(node *v, node *w, int numNodes);

/*collapseGraph is called by findHighWeightBranching on the input
  graph G and the greedyGraph.  it creates a new set of vertices,
  including one node for each cycle in greedyGraph, and one node for
  each vertex in G not in one of the cycles of greedyGraph.  for nodes
  resulting from the collapse of a cycle, we set the field cycleWeight
  to the weight of the minimum edge on the cycle For each new node x,
  let C_x be the cycle in G collapsing to x if x is a collapsed node,
  or let C_x be x otherwise.  For each pair of nodes of the collapsed
  graph, x, y, collapseGraph adds an arc from x to y if there is any
  arc from C_x to C_y.  The weight of the new arc is determined by the
  formula weight(x,y) = weight(C_x,C_y) + cycleWeight(y) - flowIn(y)
  This value represents the increase in weight obtained by adding the
  edge from C_x to C_y, deleting the edge going into y, and adding the
  minimum weight edge of the cycle C_x.  collapseGraph produces a
  graph which is passed to a recursive call of
  findHighWeightBranching.  The edges of G fall into three categories:
  1)negative- and zero-weight edges are deleted, 2)edges between nodes
  not in the same cycle of greedyGraph are represented by an edge
  between collapsed nodes as described above, and 3)edges between
  nodes of the same greedyGraph cycle are collapsed.  The minimum
  weight edge of the cycle has its weight assigned as the
  'cycleweight' field of the collapsed node. */
graph *collapseGraph(graph *greedyGraph, graph *G);

/* recover graph uses branching on collapsed graph and the cycle
   structure of the greedy graph to produce the maximum weight
   branching.  greedyGraph is the greedy graph of G, and
   collapsedBranching is the graph returned by recursive call to
   findHighWeightBranching.  The branching, recoveredGraph, will be on the same
   vertex set as G. For edges, it will have edges corresponding to the
   edges of H, and will have all of the edges of G except one edge
   from each cycle */
graph *recoverGraph(graph *greedyGraph, graph *collapsedBranching);

/*refreshGraph is used to reinitialize the fields used by
  findHighWeightBranching*/
void refreshGraph(graph *G);

// In "2.3. Optimal tree inference", "finding minimum weight directed
// spanning trees (arborescences) due to Chu and Liu".
/*findHighWeightBranching is the primary recursive function of the
  program.  upon the input of the graph G it returns a pointer to a
  maximum weight branching of G.  First it calls makeGreedyGraph,
  which picks out the maximum weight edge going into each vertex.  If
  the greedy graph is acyclic, we are done.  Otherwise, we must break
  up cycles.  collapseGraph collapses each cycle to a single node, and
  adjusts edge weights via formula described elsewhere.
  findHighWeightBranching then calls itself recursively, to get a
  maximum weight branching on the collapsed graph.  it then calls
  recoverGraph, which expands each of the cycles of the collapsed
  graph, ensuring that for each cycle one edge is deleted.  This
  results in the maximum weight branching.  note that the maximum
  weight branching need not be a connected graph, even if the graph G
  is strongly connected.  However, if G is a complete digraph, the
  maximum weight branching will be connected.
  top indicates whether this is the top-level  call (TRUE)
  or a recursive call (FALSE) */
graph *findHighWeightBranching(graph *G, bool top);

#endif
