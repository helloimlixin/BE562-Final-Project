// Merge two rooted trees with weighted nodes and directed edges
// across two distinct assays using a mixed integer linear programming
// (MIP) library. Earlier implementations used the glpk library. The
// current implementation uses the SCIP library from
// http://scip.zib.de/
// Achterberg T, SCIP: solving constraint integer programs,
// Mathematical Programming Computation, 1, pp. 1-41, 2009.
//
//
// The original description of the integer program to be solved
// in the paper is as follows:
// In "2.7. Merging trees across assays", "The input to our merging 
// problem can thus be assumed to be two rooted trees, A = (V_A,E_A) and
// B = (V_B,E_B), with unlabeled, weighted nodes (the output of two runs
// of our inference algorithm above). Our desired output is a joint tree
// T whose states are drawn from the set of tuples V = V_A x V_B and
// whose edges are the union of edges of A and B. That is, for all
// (u_A,v_A) \in E_A there exists some ((u_A,w_B),(v_A,w_B)) \in E and
// for all (u_B,v_B) \in E_B there exists some ((w_A,u_B),(w_A,v_B)) \in
// E."
// In "2.7. Merging trees across assays", "The weight of each node a
// from tree A must be distributed among the states of the joint tree
// that contain a as a member of the tuple, and the weights from tree B
// must be similarly divided."
// In "2.7. Merging trees across assays", "We can define the error at a
// node of the joint tree to be the difference in weight assigned to
// that node by trees A and B. The cost of a joint tree is then defined 
// to be this error summed over all the nodes. The optimal joint tree is
// the one with the minimum cost, assuming that weight from the input
// trees is assigned optimally."
//
// However, the above text does not take into account matching ploidy
// or the possibility of diagonal edges. In particular the statement
// that "...whose edges are the union of edges of A and B" is not
// general enough. The diagonal edges are encoded by variables with
// the name C, so that if C_i_j is 1 that means that the edge into
// joint node (i,j) comes from the joint node (parent(i), parent (j)).
// Furthermore, there are now terms in the cost function to take into
// account the ploidies of the nodes in A and B that are combined.
//
// The C/C++ implementation using glpk was done by Adam Lee in years
// 2010-2011.  The current implementation using SCIP was done by
// E. Michael Gertz in 2014-2015.

#ifndef MERGE_H
#define MERGE_H

#include <iostream>
#include <list>
#include <map>
#include <string>
#include <vector>

#include "fish.h"
#include "graph.h"

typedef std::map<std::vector<int>, double> edge_counts_type;

struct as_mutation_table {
  const edge_counts_type & edge_counts;
  const vec_names gene_names;
  const vec_names chr_names;

  as_mutation_table(const edge_counts_type & ec, const vec_names & gn,
                    const vec_names & cn)
  : edge_counts(ec), gene_names(gn), chr_names(cn)
  {
  }
};

std::ostream & operator<<(std::ostream & ss, const as_mutation_table & mt);


// In "2.7. Merging trees across assays", "Let A and B be two trees 
// given as input to the merging algorithm. We number the nodes of each
// tree in topological order and use the variable i to represent the ith
// node of A and j to represent the jth node of B."
// In "2.7. Merging trees across assays", "We first define a merge graph 
// G = (V,E) where V = V_A x V_B and E = 
// {((u_A,w_B),(v_A,w_B))|(u_A,v_A} \in E_A} \cup 
// {((w_A,u_B),(w_A,v_B))|(u_B,v_B) \in E_B}."
// In the corrected formulation, the edge set also includes diagonal
// edges
// {((u_A,v_B),(w_A,z_B))| (u_A, w_A) \in E_A and (v_B,z_B) \in E_B}
//
// Parameters:
//   graph **ref_joint_tree : a reference to the rooted joint tree T as
//                            G = (V_A x V_B,E_A ^ E_B)
//   graph *tree_A : rooted tree A = (V_A,E_A)
//   graph *tree_B : rooted tree B = (V_B,E_B)
//   string filename : used to write out the integer program solution
//   list<map<string,int> > *ref_list_counts : a list of mappings from
//         probe symbols to probe counts for one sample (patient data file))
// Return:
//   n/a
void merge_trees(graph **, edge_counts_type &, bool &,
                 graph *, graph *, std::string,
                 std::list<std::map<std::string,int> > *);

// Merge a vector of trees, reordering heuristically to get a low-weight
// tree.  Return the resulting merged tree.  The input parameters are *not*
// reordered; the correct order may/must be inferred from the merged
// tree.
graph *
reorder_and_merge_trees(const vec_names & name_gene,
                        const std::vector<graph*> & probe_trees,
                        const std::string & filename,
                        std::list<std::map<std::string,int> > *ref_list_counts);

#endif
