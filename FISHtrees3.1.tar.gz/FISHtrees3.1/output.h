// Output structured data to the standard output or a given file.

#ifndef OUTPUT_H
#define OUTPUT_H

#include <list>
#include <map>
#include <vector>
#include <string>

#include "obs_graph.h"
#include "node.h"
#include "edge.h"
#include "graph.h"
#include "constants.h"

// Output all allowed nodes in the program as a two-dimensional matrix.
void output_possible_graph(const obs_graph & gr);

// Output graph in Graphviz DOT format as defined in:
// http://www.graphviz.org/doc/info/lang.html
void output_possible_graph_in_dot_format(const char *, const obs_graph & gr);

// Output patient data file.
void
output_patient_file(FILE *, int, std::list<std::string>, int,
                    std::list<std::string>, int, int,
                    std::list<std::map<std::string,int> > *);

// Output frequencies matrix.
void output_node_frequencies(obs_graph::freq_t & freq);

// Output graph in a list of parent nodes as tail nodes of edges where
// each node connects to a list of child nodes as head nodes of edges.
void output_graph(graph *);

// Output graph with node frequencies and edge weights in a list of
// parent nodes as tail nodes of edges where each node connects to a
// list of child nodes as head nodes of edges.
void output_graph_with_node_frequency_and_edge_weight(graph *);

// Output node frequencies in a graph as a two-dimensional matrix.
void output_graph_as_table_of_node_frequencies(graph *);

// Output table of edges in a graph as a two-dimensional matrix.
void output_graph_as_table_of_edges(graph *);

// Output list of nodes.
void output_list_of_nodes(std::list<node *> *);

// Output list of edges.
void output_list_of_edges(std::list<edge *> *);

// Output list of paths.
void output_list_of_paths(std::list<std::list<edge *> > *);

// Output mutation probabilties vector as a one-dimensional array.
void output_mutation_probabilities(double_vector,
                                   const std::string &, const std::string &);

// Output tree with node frequencies and edge weights in a list of child
// nodes as head nodes of edges where each child node connects to its
// parent node as head node of the edge except the root node.
void output_tree_with_node_frequency_and_edge_weight(graph *);

// Output tree in Newick tree format to a given output file.
void output_tree_in_newick_format(FILE *, graph *);

// Output subtree in Newick tree format to a given output file.
void output_subtree_in_newick_format(FILE *, graph *, edge *);

// Output tree in Graphviz DOT format as defined in:
// http://www.graphviz.org/doc/info/lang.html
void output_tree_in_dot_format(std::string, graph *);

// Output the Rectilinear Steiner Minimum Tree instance in a
// format specified by Thorsten Koch
void output_steiner_instance(std::string, int, int [][MAX_PROBES], int,
                             std::vector<int>&);

#endif
