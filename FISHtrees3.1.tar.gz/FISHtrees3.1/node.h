// A single-probe node in a graph or tree represents a state pair of 
// copy numbers of a given chromosome and a given single gene in an 
// individual cell.
// In "2.1. Input data", "i copies of the chromosome and j copies of the 
// gene, which we call state (i,j)".
//
// A joint node in a tree or graph represents a state pair of two 
// state indices representing nodes from two trees or two graphs.
// In "2.7. Merging trees across assays", "Let A and B be two trees 
// given as input to the merging algorithm. We number the nodes of each 
// tree in topological order and use the variable i to represent the ith 
// node of A and j to represent the jth node of B. ... state [i,j]".

#ifndef NODE_H
#define NODE_H

#include <iostream>
#include <list>
#include <map>
#include <string>

// Declare node to represent a state pair of copy numbers of chromosome 
// probe and gene probe.
class node
{
  // Unary operator.
  friend std::ostream &operator<<(std::ostream &, const node &);

  // Binary operators.
  friend bool operator<(const node &, const node &);
  friend bool operator>(const node &, const node &);
  friend bool operator==(const node &, const node &);
  friend bool operator!=(const node &, const node &);

public:
  // 
  std::string chr_symbol;

  // 
  std::string gene_symbol;

  // Copy number of chromosome probe or ploidy.
  // Can be assigned by class constructor or class subroutine set_values().
  int chr;

  // Copy number of gene probe.
  // Can be assigned by class constructor or class subroutine set_values().
  int gene;

  // In possible graph G', class consturctor assigns index to -1.
  // In input graph G, index is used to identify a node in edges table 
  // in class subroutine graph::set_nodes_and_edges().
  int index;

  // In possible graph G', label is an empty string.
  // In input graph G, label is assigned to text of 
  // (chromosome_name,gene_name)=(#_chromosome,#_gene)\n....
  // In merge graph and consensus graph, label is concatenated by labels 
  // from mtuliple input graph.
  std::string label;

  // 
  double observed;

  // In possible grapg G', node frequency is used as integer-value 
  // frequency count read from patient data file or set as 1.0 on 
  // unobserved root node or on a Steiner node (that un-normalized 
  // weight is assigned to 1.0, a relatively small positive value; this 
  // weight will be normalized later to approximately 
  // 1.0/number_of_cells_counted_in_patient_data_file).
  // In input graph G, node frequencies are normalized to real numbers 
  // as weights and summed up to 1.0.
  double frequency;

  // Parent node in the tree.
  node *parent;

  // If this node is in cycle in the branching algorithm.
  bool is_in_cycle;

  // The weight of the cycle in the branching algorithm.
  double cycle_weight;

  // For branching.
  node *next_node;
  node *old_node;

  // In the case of this node being a joint node in joint tree, the 
  // joint_node variable points to either the first single-probe 
  // state node (if the merge involved two single-probe trees) or the 
  // previous joint node (if the merge involved a multi-probe tree and a 
  // single-probe tree) prior to the merge.
  node *joint_node;

  // In the case of this node being a joint node in joint tree, the 
  // single_node variable points to the single-probe node from the 
  // higher indexed (given in the command-line arguments) single-probe 
  // tree prior to the merge.
  node *single_node;

  // Class constructor.
  // This constructor is used to create a nodes matrix as pseudo graph 
  // of all possible nodes and edges to read patient data.
  node();

  // Class constructor with given pair values.
  // This constructor is used for joint graphs and the concensus graph.
  node(int, int);

  // Class constructor with given pairs of names and values, and index.
  // This constructor is used in the graph per probe for each patient 
  // for tree inference.
  node(const std::string&, const std::string&, int, int, int);

  // Decrease node index by 1.
  node &operator--();

  // 
  std::string get_chr_symbol();

  // 
  std::string get_gene_symbol();

  // Get number of chromosome probes or ploidy of this node.
  int get_chr();

  // Get number of gene probes of this node.
  int get_gene();

  // Get index of this node.
  int get_index();

  // Get label of this node.
  std::string get_label();

  // Get observed probability.
  double get_observed();

  // Get modeled probability.
  double get_modeled();

  // Get joint node of this joint node.
  node *get_joint_node();

  // Get single node of this joint node.
  node *get_single_node();

  // Get linear-lexicographic state index of two-dimensional 
  // (#chromomse/ploidy,#gene) node.
  int get_state_index();

  // Set values as given pair.
  void set_values(int, int);

  // Set observed probability in the patient data file.
  void set_observed(std::list<std::map<std::string,int> > *);

  // Accumulate given observed probability to the current observed probability.
  double accumulate_observed_probability(double);

  // Accumulate given modeled probability to the current modeled probability.
  double accumulate_modeled_probability(double);
};

#endif
