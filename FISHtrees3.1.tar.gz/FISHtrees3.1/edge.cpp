// A directed edge in a graph represents a valid mutation from a given 
// node to a connected tumourigenesis node.
// In "2.3. Optimal tree inference", "E is the set of all possible 
// single mutation events connecting pairs of states".

#include "edge.h"

#include "fish.h"

using namespace std;

// Class constructor.
edge::edge()
{
  // Initialize reference of tail as source node of edge to be NULL
  tail = NULL;
  // Initialize reference of head as target node of edge to be NULL
  head = NULL;
  // Initialize mutation type to be INVALID.
  type = INVALID;

  // Initialize edge weight to be 0.0.
  weight = 0.0;

  old_edge = NULL;
}

// Class copy constructor.
edge::edge(const edge& in_edge)
{
  // Initialize reference of tail as source node of edge to be as in_edge.
  tail = in_edge.tail;
  // Initialize reference of head as target node of edge to be as in_edge.
  head = in_edge.head;
  // Initialize mutation type to be as in_edge.
  type = in_edge.type;

  // Initialize edge weight to be 0.0.
  weight = 0.0;

  old_edge = NULL;
}

// Class constructor with given parent/source and child/target nodes.
edge::edge(node *in_parent, node *in_child, int in_type)
{
  // Initialize reference of tail as source node of edge to be in_parent.
  tail = in_parent;
  // Initialize reference of head as target node of edge to be in_child.
  head = in_child;
  // Initialize mutation type to be in_type.
  type = in_type;

  // Initialize edge weight to be 0.0.
  weight = 0.0;

  old_edge = NULL;
}

// Output copy numbers of chromosome probe and gene probe in pair format.
ostream &operator<<(ostream &output, const edge &edge0)
{
  output << *edge0.tail << ":" << edge0.type << ":" << *edge0.head;
  return output;
}

// Get tail/source node of this edge.
node *edge::get_tail()
{
  // Return tail/source node of this edge.
  return tail;
}

// Get head/target node of this edge.
node *edge::get_head()
{
  // Return head/target node of this edge.
  return head;
}

// Get type of this edge.
int edge::get_type()
{
  // Return type of this edge.
  return type;
}

