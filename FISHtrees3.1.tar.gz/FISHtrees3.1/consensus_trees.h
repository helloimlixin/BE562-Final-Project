#ifndef CONSENSUS_TREES_H
#define CONSENSUS_TREES_H

#include <map>
#include <set>
#include <string>
#include <utility>
#include <vector>

// child_parent_map - a map of (child => parent) edges usually
// representing a tree.  Each node is represented as a string. For
// FISHtrees, the string would represent the multiplicity of each
// probe, a "configuration".
//
// This structure maps each child to exactly one parent, with nodes
// having no parent mapped to the string "nil".  If there are no
// cycles, the graph is a collection of trees. If there is only one
// root node (node with "nil" as its parent), the graph is a tree.
//
// As a consequence of this definition, the set of nodes in the graph
// is exactly the set of keys in the map.
typedef std::map<std::string,std::string> child_parent_map;
typedef std::vector<child_parent_map> vec_child_parent_map;

// node_set -- a set of nodes represented as strings.
typedef std::set<std::string> node_set;

// child_parent_edge -- a child => parent edge. The parent should not
// be "nil".
typedef std::pair<std::string, std::string> child_parent_edge;

// vec_cp_edges -- a list of child => parent edges. No parent node of
// any edge in the list should be "nil".
typedef std::vector<child_parent_edge> vec_cp_edges;

node_set
find_shared_nodes(const vec_child_parent_map & trees,
                  int min_count_nodes);

vec_cp_edges
find_consensus_graph(const vec_child_parent_map & trees_in,
                     const node_set & all_targets,
                     int min_count_node, int min_count_edge);

child_parent_map
find_consensus_tree_fragment(const vec_child_parent_map & trees_in,
                             const node_set & all_targets,
                             int min_count_node, int min_count_edge);

std::ostream &
print_core_dot(std::ostream & ff, const vec_cp_edges & core_edges,
               const node_set & observed_nodes,
               const vec_child_parent_map & trees,
               const std::string & title,
               bool core_only);

#endif
