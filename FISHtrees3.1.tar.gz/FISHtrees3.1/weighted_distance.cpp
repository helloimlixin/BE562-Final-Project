#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include <iomanip>

#include <cmath>
#include <climits>
#include <cassert>

#include "weighted_distance.h"

#include "graph.h"
#include "generate_steiner_trees.h"
#include "median_joining.h"
#include "branching.h"

using namespace std;

typedef std::vector<std::vector<double> > double_matrix;

// Follow zig-zag paths from s on the way to d until the optimal
// remaining path contains only SD steps.
//
// diff - the first n entries represent SD steps changing the
//     corresponding gene; positive values represent gains and
//     negative represent losses.  The (n+1)st entry is the number of
//     zig-zag steps taken, where again positive numbers represent
//     gains and negative numbers losses.
// t - on entry, the starting point from which to take zig-zag paths; on exit
//     the endpoint after the optimal zig-zag paths.
// d - end configuration
// sense - -1 for loss; 1 for gain.
// weights - weights of SD changes; first row losses, second gains
// cweights - weight of CD changes; first element losses, second gains
//
// returns  the sum of the costs of the optimal zig-zag paths
double
calc_zzag_cost(int diff[], int n, int t[], const int d[],
               int sense, const double * weights,
               const double cweights[2])
{
  const double * a = weights + (sense + 1)/2 * n;
  const double * b = weights + (1 - sense)/2 * n;
  double gamma = cweights[(sense + 1)/2];

  fill_n(diff, n + 1, 0);
  int steps_taken = 0;
  double cost = 0.0;
  while(1) {
    double cost_zz = gamma, benefit_zz = 0;

    for (int k = 0;  k < n;  k++) {
      if (t[k] == 0)
        continue;               // no move possible

      if (sense*(t[k] - d[k]) >= 0)
        cost_zz += b[k];
      else
        benefit_zz += a[k];
    }

    if (cost_zz >= benefit_zz)
      break;

    ++steps_taken;
    for (int k = 0;  k < n;  k++) {
      if (t[k] == 0)
        continue;

      if (sense * (t[k] - d[k]) < 0) {
        t[k] = t[k] + sense;
      } else {
        diff[k] -= sense;
      }
    }
    cost += cost_zz;
  }
  diff[n] += sense * steps_taken;

  return cost;
}


// Return the cost of an SD step from s to d.
static double
calc_sd_cost(int counts[], const int s[], int n, const int d[],
             const double * weights)
{
  const double * losses = weights;
  const double * gains = weights + n;

  double cost = 0;
  for (int k = 0;  k < n;  k++) {
    int diff = d[k] - s[k];
    if (diff > 0) {
      cost += diff * gains[k];
      counts[2*k] += diff;
    } else {
      cost += -diff * losses[k];
      counts[2*k+1] += -diff;
    }
  }
  return cost;
}


// Calculate distance between two vectors taking into account single
// gene duplication (SD) and chromosome duplication (CD) events, where all
// probes represent genes on a single chromosome.
//
// - src, dest -- copy number profiles between which distance is calculated
// - probes -- size of src and dest
// - param -- weights of SD and CD gains or losses.
// - counts -- the number of SD and CD steps in the optimal path
//
// The arrays 'param' and 'counts' have the same size an shape.
// The element param[2*k] represents the cost of an SD gain of gene k
// param[2*k+1] is the cost of an SD loss of the same gene.
// The element param[2*n] is the cost of a CD gain and param[2*n+1] is
// the cost of a CD loss.
//
// The meaning of the elements of counts follows a similar pattern.
static double
calc_sd_cd_cost(const int src[], const int dest[], int n,
                const double * param, int * counts)
{
  vector<double> weights(2*n);
  double cweights[2];
  vector<int> t(src, src + n);
  vector<int> diff(n+1);

  const bool debug = true;

  enum { zzgain = 1,  zzloss = -1 };

  for (int k = 0;  k < n;  k++) {
    // Moving from zero to nonzero is impossible, but should have been
    // checked in the calling routine.
    assert(src[k] != 0 || dest[k] == 0);

    weights[k] = param[2*k+1];
    weights[n + k] = param[2*k];
  }
  cweights[0] = param[2*n+1];
  cweights[1] = param[2*n];

  double cost;

  fill_n(counts, 2*n + 2, 0);

  cost =
    calc_zzag_cost(&diff[0], n, &t[0], dest, zzgain, &weights[0], cweights);

  if (cost == 0) {
    cost =
      calc_zzag_cost(&diff[0], n, &t[0], dest, zzloss, &weights[0], cweights);
  }

  for (int k = 0;  k < n + 1;  k++) {
    if (diff[k] > 0) {
      counts[2*k] = diff[k];
    } else {
      counts[2*k+1] = -diff[k];
    }
  }
  double sd_cost = calc_sd_cost(counts, &t[0], n, dest, &weights[0]);

  if (debug) {
    double sum = 0;
    for (int k = 0;  k < 2*n + 2;   k++) {
      sum += param[k] * counts[k];
    }
    assert(abs(cost + sd_cost - sum) < 1e-8);
  }
  return cost + sd_cost;
}


// A table in three dimensions representing the cost of SD+GD steps.
// Dimension:
//
// 1) a fixed number of GD steps;
// 2) the start point of a SD+GD path; and
// 3) the end point of a SD+GD path
//
// The total number of SD losses and SD gains, as well at the start
// points for each GD step are recorded.  The start points are encoded
// in a decimal integer (because each start point is less than 9) in
// which the highest value digit representing the first GD step and
// the lowest value digit representing the last GD step.
//
// Because the contents of sd_gd_table does not depend on any parameters,
// it is filled with appropriate values at creation.
class sd_gd_table {
public:
  static const size_t max_gd = MAX_GD;
  static const size_t max_copy = MAX_COPY;
  static const int bignum = 10000;
  static const int scale = 10;

  struct sd_gd {
    int gains;
    int losses;
    int points;

    void push_back(int loc, int lo, int ga)
    {
      points = scale * points + loc;
      losses += lo;
      gains += ga;
    }

    sd_gd() : gains(), losses(), points() {};
  };

  typedef sd_gd gd_level[max_copy+1][max_copy + 1];

  int sd_cost(int gd, int i, int j) const
  {
    const sd_gd & record = table[gd][i][j];
    return record.gains + record.losses;
  }

  const gd_level & operator[](size_t k) const { return table[k]; }

  sd_gd_table();

private:
  gd_level table[max_gd];

  void do_gd_losses_gains(int gd, int i, int j, int point, int loss, int gain)
  {
    table[gd][i][j] = table[gd-1][i][point];
    table[gd][i][j].push_back(point, loss, gain);
  }

  void fill_nonzero_copies();

  void attach_zeros();
};


// Write a representation of one SD+GD path.
ostream & operator<<(ostream & ss, const sd_gd_table::sd_gd & record)
{
  ss << setw(2) << record.losses << ","
     << record.gains << "," << record.points;
  return ss;
}


// Write a representation of the SD+GD table.
ostream & operator<<(ostream & ss, const sd_gd_table & table)
{
  for (size_t k = 0;  k < table.max_gd;  k++) {
    ss << "========== level=" << k
       << " (losses,gains,dup_points) ==========" << endl;
    ss << "xx";
    for (size_t j = 0;  j < table.max_copy + 1;  j++) {
      // losses comma gains comma gdpoints
      int width = 2 + 1 + 1 + 1 + max(k, (size_t) 1);
      ss << "\t" << string(width - width/2 - 1, '-')
         << j << string(width/2, '-');
    }
    ss << "\n";
    for (size_t i = 1;  i < table.max_copy + 1;   i++) {
      ss << i << ":";
      for (size_t j = 0;  j < table.max_copy + 1;  j++) {
        ss << "\t" << table[k][i][j];
      }
      ss << "\n";
    }
    if (k == table.max_gd - 1)
      ss << "========== ==========";
    else
      ss << "\n";
  }
  return ss;
}


// Fill the elements of the SD+GD table that start and end at nonzero
// copy numbers.
void sd_gd_table::fill_nonzero_copies()
{
  for (size_t gd = 0;  gd < max_gd;  gd++) {
    for(size_t i = 1;  i < max_copy + 1;  i++) {
      for (size_t j = 1;  j < max_copy + 1;  j++) {
        if (gd == 0) {
          if (j > i) {
            table[0][i][j].gains = j - i;
          } else {
            table[0][i][j].losses = i - j;
          }
        } else if (j % 2 == 0) { // even
          do_gd_losses_gains(gd, i, j, j/2, 0, 0);
        } else if (j == 1) {
          do_gd_losses_gains(gd, i, 1, 1, 1, 0);
        } else {                // j is odd, but not = 1
          int upp = (j + 1) / 2;
          int low = (j - 1) / 2;

          int upper = (j != max_copy) ? sd_cost(gd - 1, i, upp) : bignum;
          int lower = (j != 1) ? sd_cost(gd - 1, i, low) : bignum;

          if (lower <= upper || (lower == upper && i <= j)) {
            do_gd_losses_gains(gd, i, j, low, 0, 1);
          } else {
            do_gd_losses_gains(gd, i, j, upp, 1, 0);
          }
        }
      }
    }
  }
}


// Fill the elements of the SD+GD table that start or end at zero.
void sd_gd_table::attach_zeros()
{
  // Note: we leave the zero-zero element as all zeros.  This is correct,
  // because duplication of zero elements should start from 0 and involve
  // no gains or losses.

  for (size_t gd = 0;  gd < max_gd;  gd++) {
    for (size_t k = 1;  k < max_copy + 1;  k++) {
      // Zero finishes
      table[gd][k][0].losses = k; // Lose to zero, then double
      // Zero-starts, nonzero finishes -- biologically impossible
      table[gd][0][k].gains = bignum;
      table[gd][0][k].losses = bignum;
    }
  }
}


// Initialize a SD+GD table, filling in all values.
sd_gd_table::sd_gd_table()
{
  fill_nonzero_copies();
  attach_zeros();
}


// Calculate cost between two profiles taking into account single
// gene duplication (SD) and chromosome duplication(CD) events
// **for only those genes sharing a chromosome with another gene**
// given the constraint that the given number of genome duplications must
// occur.
//
// - src, dest -- two copy number profiles
// - dup_profile -- duplication events that were inferred for each gene
// - gd_event -- fixed number of GD events that must occur
// - tot_same_chr -- number of distinct chromosomes with more than one gene
// - chr_profile -- mapping of chromosomes to genes
// - param -- the probabilities for SD, CD and GD events (see
//     calc_mult_probe_distance().)
// - probes -- the length of src and dest
// - costprofile -- counts of events of each type
//
// Returns -- the cost of the SD and CD steps for those gene sharing a
//     chromosome with another gene (the cost of the GD step is *not*
//     included.)
static double
calculate_chr_gain_loss(const int *src, const int *dest,
                        const int dup_profile[],
                        int gd_event, int tot_same_chr,
                        int const * const * chr_profile,
                        const double *param, int probes,
                        int *costprofile)
{
  double cost = 0;

  // temporary variables to hold source and destination configurations
  int tsrc[MAX_PROBES];
  int tdest[MAX_PROBES];

  // stores current duplication points
  int cur_dpoint[MAX_PROBES][MAX_GD];
  int k, gen;

  // For each gene, decode the GD points and store them in cur_dpoint.
  for(int p=0; p<probes; p++){
    int profile = dup_profile[p];
    for(int g=0; g<gd_event; g++){
      cur_dpoint[p][gd_event - g - 1] = profile % sd_gd_table::scale;
      profile /= sd_gd_table::scale;
    }
  }

  // weights and counts of each SD, CD event
  double *tparam = new double[2*MAX_PROBES+2];
  int *counts = new int[2*MAX_PROBES+2];

  // Iterate through each chromosome that has multiple genes.
  for(int i=0; i < tot_same_chr; i++){

    // Initialize counts.
    for(int p=0;p<2*probes+2;p++)
      counts[p] = 0;

    // Store the SD weights in tparam.
    for(int p=1;p<=chr_profile[i][0];p++){
      k = p-1;
      gen = chr_profile[i][p];
      // Supply the weights so that we don't have to use log later again.
      tparam[2*k] = (-log2(param[2*gen]));
      tparam[2*k+1] = (-log2(param[2*gen + 1]));
    }
    // Now store the CD weights.
    tparam[2*chr_profile[i][0]] = (-log2(param[2*probes+2*i]));
    tparam[2*chr_profile[i][0]+1] = (-log2(param[2*probes+2*i+1]));

    // For total 0 GD event case, calculate the SD+CD distance from
    // src to dest.
    if(gd_event == 0){
      for(int p=1;p<=chr_profile[i][0];p++){
        tsrc[p-1] = src[chr_profile[i][p]];
        tdest[p-1] = dest[chr_profile[i][p]];
      }
      // Compute the total cost for this chromosome from tsrc to tdest.
      cost +=
          calc_sd_cd_cost(tsrc, tdest, chr_profile[i][0], tparam, counts);

      // For each gene on each chromosome, store the SD gain and loss
      // counts in costprofile.
      for(int p=1;p<=chr_profile[i][0];p++){
        k = p-1;
        gen = chr_profile[i][p];
        costprofile[2*gen] = counts[2*k];
        costprofile[2*gen+1] = counts[2*k+1];
      }
      // Now store the gain and loss counts for the current chromosome
      // in costprofile.
      costprofile[2*probes+2*i] = counts[2*chr_profile[i][0]];
      costprofile[2*probes+2*i+1] = counts[2*chr_profile[i][0]+1];
      continue;
    } // end if(gd_event == 0)

    // Iterate over each GD point of the current chromosome, and
    // calculate the total SD+CD cost for the current chromosome only.
    for(int g=0; g <= gd_event; g++){
      for(int p=1;p<=chr_profile[i][0];p++){

        // For the first GD event, compute cost from src to first GD event.
        if(g==0){
          tsrc[p-1] = src[chr_profile[i][p]];
          tdest[p-1] = cur_dpoint[chr_profile[i][p]][g];
          continue;
        }
        // For the final GD event, compute cost for copy number profile from
        // last GD point to dest.
        if(g==gd_event){
          tsrc[p-1] = 2*cur_dpoint[chr_profile[i][p]][g-1];
          tdest[p-1] = dest[chr_profile[i][p]];
          continue;
        }
        // Otherwise, compute cost between two intermediate GD points.
        tsrc[p-1] = 2*cur_dpoint[chr_profile[i][p]][g-1];
        tdest[p-1] = cur_dpoint[chr_profile[i][p]][g];

      } // end for(p)

      // Compute the cost for this chromosome from tsrc to tdest.
      cost +=
          calc_sd_cd_cost(tsrc, tdest, chr_profile[i][0], tparam, counts);

      // For each gene on this chromosome, store the SD gain and loss
      // counts in costprofile.
      for(int p=1;p<=chr_profile[i][0];p++){
        k = p-1;
        gen = chr_profile[i][p];
        costprofile[2*gen] += counts[2*k];
        costprofile[2*gen+1] += counts[2*k+1];
      }
      // Now store the gain and loss counts for the current chromosome
      // in costprofile.
      costprofile[2*probes+2*i] += counts[2*chr_profile[i][0]];
      costprofile[2*probes+2*i+1] += counts[2*chr_profile[i][0]+1];
    } // end for(g)
  } // end for(i)

  delete[] tparam;
  delete[] counts;
  return cost;
}


// Calculate distance between 'src' and 'dest' based on single probe
// distance calculated in 'store' and parameter values stored in 'weight'.
//
// src, dest - the two copy number profiles between which
//     distance is calculated
// number_of_probes - the total number of probes listed by the user
// store - the encoded combination of SD and GD events for each
//     pair of single gene count
// dup_store - the duplication points at which GD event is inferred
// probabilities - the probability of each event type
// mincostprofile - total counts of each event type, used to
//     pass back the results
// tot_same_chr - number of sets of probes on the same chromosome
// chr_profile - a matrix indicating which probes go together on the
//     same chromosome
// chr_indicator - indicates for each gene if it belongs to a same chr
//     or a different chromosome
static double
calc_mult_probe_distance(const int *src, const int *dest,
                         int number_of_probes,
                         const sd_gd_table & table,
                         const double *probabilities,
                         int *mincostprofile,
                         int tot_same_chr, int const * const * chr_profile,
                         const int chr_indicator[])
{
  assert(number_of_probes > 0);

  // The array 'costprofile' stores the counts of individual events.
  // The indices are first gain and loss for each gene, then gain and loss
  // for each chromosome, and finally genome duplication.
  vector<int> costprofile(2*number_of_probes + 2*tot_same_chr + 1);

  double mincost = INT_MAX;

  int dup_profile[MAX_PROBES];

  for (int q = 0;  q < number_of_probes;  q++) {
    if (src[q] == 0 && dest[q] != 0) {
      // Biologically impossible.  Return now.
      fill_n(mincostprofile, 2*number_of_probes + 2*tot_same_chr + 1, 0);
      return INF;
    }
  }

  // Loop through each possible number of GD events, and compute the cost
  // of a SD+CD+GD path with that fixed number of GD events.
  for(int gd=0; gd<MAX_GD; gd++){
    double cost = 0;
    for(int kk = 0; kk < 2*number_of_probes + 2*tot_same_chr + 1; kk++) {
      costprofile[kk] = 0;
    }
    for(int q=0; q < number_of_probes;q++){
      // Calculate the SD cost for all genes that do not share a chromosome
      // with another gene (no CD steps are possible). Genes that do share
      // a chromosome with another gene will be handled below.

      const sd_gd_table::sd_gd & record = table[gd][src[q]][dest[q]];

      dup_profile[q] = record.points;

      if(chr_indicator[q] != 0)
        continue;

      int sdg = record.gains;
      int sdl = record.losses;

      // Store the counts in costprofile array.
      costprofile[2*q] = sdg;
      costprofile[2*q+1] = sdl;
      costprofile[2*number_of_probes + 2*tot_same_chr] = gd;

      // Add SD gain and SD loss cost to the total cost.
      cost +=
        (sdg*((-log2(probabilities[q*2]))) +
         sdl*((-log2(probabilities[q*2+1]))));
    } // end for (q)

    // Now compute SD+CD costs for genes that share a chromosome.
    if(tot_same_chr > 0){
      cost +=
        calculate_chr_gain_loss(src, dest, dup_profile, gd,
                                tot_same_chr, chr_profile,
                                probabilities,
                                number_of_probes, &costprofile[0]);
    }
    // Add GD cost to the total cost.
    cost +=
      (gd *
       ((-log2(probabilities[2*number_of_probes + 2*tot_same_chr]))));

    // If the current cost is the best seen so far, update
    // mincost and mincostprofile.
    if(cost < mincost){
      mincost = cost;
      for(int q=0; q < 2*number_of_probes + 2*tot_same_chr;q++){
        mincostprofile[q] = costprofile[q];
      }
      mincostprofile[2*number_of_probes + 2*tot_same_chr] = gd;
    }
  }

  return mincost;
}


// Convert individual records into a tree and combines the trees in
// a graph structure.
//
// - nodes -- the copy number counts of each node in the Steiner tree
// - total_nodes -- length (rows) of nodes.
// - probes -- number of probes in each node (columns of nodes).
// - root_index -- the index of the root in the Steiner tree
// - name_gene -- the gene names corresponding to the probes.
// - cell_count -- a cell count pattern read from the the patient file;
//      cell_count may have been expanded to include Steiner nodes
//      with 0 counts
//
// Return: the graph which combines the trees representing records in
//    the Steiner tree.
//
// This procedure is similar to convert_to_joint_tree in
// generate_steiner_trees.cpp
static graph *
convert_to_graph(int const * const * nodes, int total_nodes, int probes,
                 int root_index, const vec_names & name_gene,
                 const vector<int> & cell_count,
                 const double_matrix & weight)
{
  // the individual probe count values in each record
  node ***single_nodes = new node**[total_nodes];

  // the combined probe count values in each record
  node ***joint_nodes = new node**[total_nodes];

  // the total cell counts in the patient file.
  int total_cells = 0;

  // Count total number of cells and initialize single_nodes and joint_nodes.
  for (int i = 0; i < total_nodes; i++){
    total_cells += cell_count[i];
    single_nodes[i] = new node*[probes];
    joint_nodes[i] = new node*[probes];
    for (int j = 0;  j < probes;  j++) {
      single_nodes[i][j] = new node;
      joint_nodes[i][j] = new node;
    }
  }

  // Set the label of each node in the tree based on the gene probes.
  for (int i = 0; i < total_nodes; i++){
    ostringstream single_node_label;
    // Set the label of the joint nodes.  If a joint node points to
    // single node that represents the lowest level probe, then set
    // its label by the gene name of that probe.
    ostringstream probe_list, count_list;

    // For each probe, we have a single node and a joint node.
    for (int j = 0; j < probes; j++){

      // Set the probe count values of each single node.
      single_nodes[i][j]->set_values(-1, nodes[i][j]);
      single_nodes[i][j]->index = -1;

      // Otherwise, concatenate the gene name of the lower level
      // probes to the current probe to attain the label of the
      // current level joint node.
      if(j > 0){
        probe_list << ",";
        count_list << ",";
      }
      probe_list << name_gene[j];
      count_list << nodes[i][j];
      ostringstream joint_node_label;

      joint_node_label << "(" << probe_list.str() << ")=("
                       << count_list.str() << ")";

      // Put the probe count value in a parenthesis just after the
      // gene name in the label for each probe.


      // Set the label of the single nodes.  A single node represents
      // a single probe. For each node's label, first put the probe's
      // gene name, then in parenthesis, put the probes copy number
      // count.
      single_node_label << name_gene[j] << "(" << nodes[i][j] << ")";

      single_nodes[i][j]->label = single_node_label.str();

      // Set value field of the joint node, and make the single node
      // pointer point to the proper single node.  The value -1 is
      // used here because the ploidy is irrelevant
      joint_nodes[i][j]->set_values(-1,j); // j
      joint_nodes[i][j]->single_node = single_nodes[i][j];
      joint_nodes[i][j]->index = -1;

      // For the top level joint node, set the observed frequency as
      // the fraction of the cell count of the corresponding Steiner
      // tree node.
      if(j == probes-1){
        joint_nodes[i][j]->observed =
            ((double)cell_count[i] / (double)total_cells);
      }

      // Set the joint node pointers of the joint nodes point to the lower
      // level joint nodes.
      if(j > 0){
        joint_nodes[i][j]->joint_node = joint_nodes[i][j-1];
        joint_nodes[i][j]->label = joint_node_label.str();
        if(j == probes-1){
          joint_nodes[i][j]->index = i;
        }
      }

      // Set the lowest level joint nodes joint node pointer NULL.
      else{
        joint_nodes[i][j]->joint_node = NULL;
        joint_nodes[i][j]->label = single_nodes[i][j]->label;
      }
    }
  }

  // Assemble the nodes into the graph structure.
  graph *joint_graph = new graph();

  for (int i = 0; i < total_nodes; i++){
    joint_graph->addnode(joint_nodes[i][probes-1]);
  }

  // Set the edges of the graph using the set of edges present
  // in the Steiner tree.
  int **node_store = new int*[total_nodes];
  for (int i = 0; i < total_nodes; i++){
    node_store[i] = new int[probes];
    for(int j=0;j < probes; j++)
      node_store[i][j] = nodes[i][j];
  }

  // Create the edges and store the edge weights.
  joint_graph->initialize_table_of_edges_par(node_store, total_nodes,
                                             joint_nodes, probes,
                                             root_index, weight);

  // Set the size and root of the graph.
  joint_graph -> size = total_nodes;
  joint_graph -> root = joint_nodes[root_index][probes-1];

  for (int i = 0; i < total_nodes; i++){
    delete [] node_store[i];
  }
  delete[] node_store;

  for(int i = 0;  i < total_nodes;  i++) {
    delete [] single_nodes[i];
    delete [] joint_nodes[i];
  }
  delete[] joint_nodes;
  delete[] single_nodes;

  return joint_graph;
}


// Identifies the set of triplets in the graph, where the first node
// in each triplet is the parent of the other two nodes.
//
// - triplet_store -- on return, a vector of triplets
// - total_triplets -- the number of elements of triplet_store that
//    contain a valid triplet.
// - total_nodes -- the total number of nodes in the tree

static void
identify_triplets(graph *gr, vector<vector<int> > &triplet_store,
                  int &total_triplets, int total_nodes)
{
  int *neighbors = new int[total_nodes];
  total_triplets = 0;

  // Iterate through each node in the tree.
  for(int i=0; i < total_nodes; i++){
    int num_neighbors = 0; // number of neighbors of node i

    // If node j is a child of node i, then store it in 'neighbors'.
    for(int j=0; j < total_nodes; j++){
      if(gr->table_of_edges[i][j] == NULL)
        continue;
      neighbors[num_neighbors] = j;
      num_neighbors += 1;
    }
    // If the total number of children of node i is 0 or 1, then i
    // is not the parent node of a triplet.
    if(num_neighbors < 2)
      continue;
    // Iterate through each *pair* of children of i and store them in
    // the triplet array along with i.
    for(int k=0; k<num_neighbors-1; k++){
      for(int l=k+1; l<num_neighbors; l++){
        triplet_store[total_triplets][0] = i;
        triplet_store[total_triplets][1] = neighbors[k];
        triplet_store[total_triplets][2] = neighbors[l];
        total_triplets += 1;
      }
    }
  }
  delete[] neighbors;
}


// Test whether a specific triplet should be considered by the Steiner
// node inference routine.
//
// - weight -- the pairwise distance between each pair of node
// - terminals -- the copy number profiles each cell state in a matrix
//      format
// - probes - the total number probes in the dataset
// - table - a table GD points between various copy numbers
// - param -- the probability of each SD,CD and GD event
// - i,j,k - the indices of the three nodes in the triplet
// - triplet - a candidate Steiner node that may reduce the cost of
//      the triplet
// - total_chr - the number of chromosomes that contain more than one
//      probe
// - chr_profile - a matrix indicating which probes go together on the
//      same chromosome
// - chr_indicator[i] -- indicates whether the probe indexed by i lie
//       on a chromosome alone or together with another probe
static int
test_triplet(const double_matrix &weight, int const * const * terminals,
             int probes, const sd_gd_table & table,
             const double *param, int i, int j, int k,
             const int triplet[MAX_PROBES],
                 int total_chr,
             int const * const * chr_profile,
             const int chr_indicator[])
{
  // Mincostprofile is not needed here, but is a required parameter of
  // the mult_distance_routine.
  int *mincostprofile = new int[2*probes+2*total_chr+1];

  // a copy of triplet
  int *trip = new int[probes];

  for(int ind=0;ind<probes;ind++){
    trip[ind] = triplet[ind];
  }

  // the sum of cost of the edge from i to j and from i to k
  double adist = weight[i][j] + weight[i][k];

  // the sum of the cost of the edges i->trip, trip->j and trip->k
  double bdist =
    calc_mult_probe_distance(terminals[i], trip, probes, table,
                             param, mincostprofile, total_chr,
                             chr_profile, chr_indicator) +
    calc_mult_probe_distance(trip, terminals[j], probes, table,
                             param, mincostprofile, total_chr,
                             chr_profile, chr_indicator) +
    calc_mult_probe_distance(trip, terminals[k], probes, table,
                             param, mincostprofile, total_chr,
                             chr_profile, chr_indicator);

  delete[] trip;
  delete[] mincostprofile;

  // If introduction of the node 'triplet' reduces weight of the
  // subgraph structure, return 1.
  if(adist > bdist){
    return 1;
  }
  return 0;

}


// Generate the distance matrix for a set of given terminals and
// Steiner nodes.
//
// - weight -- (output) the pairwise distance between the nodes
// - terminals -- the copy number profiles of the observed data
// - tot_terminals -- the total number of terminals
// - probes -- the total number of probes
// - start -- the index from which pairwise distance values are
//       calculated, 0 for all pairwise values
// - table -- the encoded combinations of SD and GD events for each
//      pair of single gene counts
// - param -- the probability of each SD,CD and GD event
// - total_chr -- the total number of chromosomes with more than one
//      gene probe
// - chr_profile -a matrix indicating which probes go together on the
//      same chromosome
// - chr_indicator[i] -- 1 if probe indexed by i lies on a chromosome
//     with another gene and 0 otherwise
static void
generate_weighted_distance_matrix(double_matrix &weight,
                                  int const * const * terminals,
                                  int tot_terminals,
                                  int probes, int start,
                                  const sd_gd_table & table,
                                  const double *param,
                                  int total_chr,
                                  int const * const * chr_profile,
                                  const int chr_indicator[])
{
  // 'mincostprofile' is not needed here, but is a required parameter of
  // calc_mult_probe_distance.
  int *mincostprofile = new int[2*probes+2*total_chr+1];

  int ind_j = 0;

  // Iterate through each pair of nodes.
  for(int i = 0; i < tot_terminals; i++){

    // Decide the starting point for index j based on "start" parameter.
    if(start == 0)
      ind_j = i + 1;
    else
      ind_j = start;

    for(int j = ind_j; j < tot_terminals; j++){
      // Fill the diagonal entries of the matrix with large value.
      if(i == j)
        weight[i][j] = INF;

      // For non diagonal entries of the matrix, compute the weighted
      // distance between the two nodes and store it in the weight
      // matrix.
      else{

        weight[i][j] =
            calc_mult_probe_distance(terminals[i], terminals[j],
                                     probes, table, param,
                                     mincostprofile, total_chr,
                                     chr_profile, chr_indicator);
        weight[j][i] =
            calc_mult_probe_distance(terminals[j], terminals[i],
                                     probes, table, param,
                                     mincostprofile, total_chr,
                                     chr_profile, chr_indicator);
      }
    }
  }
  delete[] mincostprofile;
}


// Generate a Steiner tree using a heuristic approach.
//
// - tot_terminals -- the total number of terminals
// - probes -- the total number of probes
// - mst_node_store -- the copy number counts of each node in the
//       Steiner tree
// - table -- the encoded combinations of SD and GD events for each
//      pair of single gene counts
// - param -- the probability of each SD,CD and GD event
// - name_gene == names of the gene probes
// - cell_count -- the total number of cells belonging to each cell
//      type; cell_count gets expanded to include Steiner nodes with a 0
//      count
// - distance - the weighted cost between each pair of nodes
// - total_same_chr -- the total number of chromosomes with more than one
//      gene probe
// - chr_profile -a matrix indicating which probes go together on the
//      same chromosome
// - chr_indicator[i] -- 1 if probe indexed by i lies on a chromosome
//     with another gene and 0 otherwise
// - mst_node_store -- (output) the inferred Steiner tree
//
// Returns the total number of nodes in the inferred Steiner tree
static int
infer_steiner_nodes(int tot_terminals, int probes,
                    int **mst_node_store,
                    const sd_gd_table & table,
                    const double *param,
                    const vec_names & name_gene,
                    const vector<int> & cell_count,
                    const double_matrix & distance,
                    int tot_same_chr,
                    int const * const * chr_profile,
                    const int chr_indicator[])
{
  // maximum number of total nodes that can be generated and tested
  int total_possible_nodes =  tot_terminals + MAX_STEINER_NODES_HEURISTIC;

  // the total number of Steiner nodes generated in a particular pass
  // of the algorithm
  int steiners = 0;

  // the pairwise distance among the nodes in the candidate mst
  double_matrix mst_distance;
  mst_distance.resize(total_possible_nodes);
  for (int i = 0; i < total_possible_nodes; ++i){
    mst_distance[i].resize(total_possible_nodes);
  }


  // A list of triplets in the graph; the midpoint of each triplet may
  // be a Steiner node.
  vector<vector<int> > triplet_store(MAXIMUM_TRIPLETS, vector<int>(3));

  // stores the copy number count of each probe for each node in the
  // candidate mst
  // int mst_nodes[tot_terminals+MAX_STEINER_NODES_HEURISTIC][MAX_PROBES];

  int **nodes;
  int **mst_nodes;

  nodes = new int*[total_possible_nodes];
  for (int i = 0; i < total_possible_nodes; i++){
    nodes[i] = new int[probes];
  }
  mst_nodes = new int*[total_possible_nodes];
  for (int i = 0; i < total_possible_nodes; i++){
    mst_nodes[i] = new int[probes];
  }

  // Copy the terminals probe count value into the MST node array.
  for (int i = 0; i < tot_terminals; i++)
    for (int j = 0; j < probes; j++)
      mst_nodes[i][j] = nodes[i][j] = mst_node_store[i][j];

  // Copy the pairwise distance values.
  for(int t1 = 0; t1 < tot_terminals; t1++){
    for(int t2 =0; t2 < tot_terminals; t2++){
      mst_distance[t1][t2] = distance[t1][t2];
    }
  }

  // Generate directed MST that comprises of only the terminal nodes.
  graph * full_gr =
      convert_to_graph(mst_node_store, tot_terminals, probes, 0,
                       name_gene, cell_count, distance);

  graph * gr = findHighWeightBranching(full_gr, true);

  delete full_gr;

  // Calculate the total weight of the terminal node tree.
  double terminal_tree_weight = 0;
  for(int i=0; i < tot_terminals; i++){
    for(int j=0; j < tot_terminals; j++){
      if(gr->table_of_edges[i][j] == NULL)
        continue;
      terminal_tree_weight += ((-1)*(gr->table_of_edges[i][j]->weight));
    }
  }

  // Set the weight of the directed MST to the minimum weight
  // identified so far.
  double global_min = terminal_tree_weight;

  // Check vector saves a representative decimal value for each node
  // which is calculated using the probe count values.
  vector<unsigned int> check_vector;
  unsigned int temp = 0;

  // Iterate through each of the nodes.
  for (int i = 0; i < tot_terminals+steiners; i++){
    temp = 0;
    // For each node, iterate through all the probe count values and
    // calculate the decimal value.
    for (int j = 0; j < probes; j++){
      temp += (nodes[i][j] * pow(MAX_COPY + 1,probes-j-1));
    }
    check_vector.push_back(temp);
  }

  // Fill triplet_store with the set of triplets from gr.
  int triplets = 0;
  identify_triplets(gr,triplet_store,triplets,tot_terminals);

  // Remove the duplicate triplets.
  triplets = prune_table_local(triplet_store,triplets,3);

  gr->deep_delete_nodes();
  delete gr;

  // Loop through each set of triplet nodes index.
  for (int i = 0; i < triplets; i++){

    // temporary storage for holding each set of triplet nodes
    int triplet_nodes[3][MAX_PROBES];

    // Store the nodes in the triplet node store.
    for(int counter = 0; counter < 3; counter++){
      for (int l = 0; l < probes; l++){
        triplet_nodes[counter][l] = nodes[triplet_store[i][counter]][l];
      }
    }

    // 'arr' is used in the generate_candidate routine.
    int arr[MAX_PROBES];
    for (int i2 = 0; i2 < probes; i2++)
      arr[i2] = 0;

    // Declare storage for holding the candidate Steiner nodes.
    int res_size = pow(3,probes);
    int (*result)[MAX_PROBES] = new int[res_size][MAX_PROBES];

    // Generate the candidate Steiner nodes using the triplets.
    vector<unsigned int> candidate_check(check_vector);
    int tot_steiners =
        generate_candidate(arr, triplet_nodes, result, 3, probes,
                           candidate_check);

    // Test each candidate Steiner node to see if it should be
    // included in the final set.
    for (int j = 0; j < tot_steiners; j++){

      // Speculatively, include the selected Steiner node in the node
      // set to that will be used to generate the next directed MST.
      for (int indexer = 0; indexer < probes; indexer++){
        mst_nodes[tot_terminals+steiners][indexer] = result[j][indexer];
      }

      // Check if the current Steiner node is good enough for further
      // evaluation.
      int check =
          test_triplet(mst_distance, mst_nodes, probes, table, param,
                       triplet_store[i][0], triplet_store[i][1],
                       triplet_store[i][2], result[j],
                       tot_same_chr, chr_profile, chr_indicator);

      // If it is not good enough, then move on to the next candidate.
      if(check ==0){
        continue;
      }

      // Generate the weighted distance matrix that will be used in
      // tree generation.
      generate_weighted_distance_matrix(mst_distance, mst_nodes,
                                        tot_terminals+steiners+1,
                                        probes, tot_terminals+steiners,
                                        table, param, tot_same_chr,
                                        chr_profile, chr_indicator);

      // Generate directed MST that comprises of terminal nodes and
      // candidate Steiner node.
      full_gr =
        convert_to_graph(mst_nodes, tot_terminals+steiners+1, probes,
                         0, name_gene, cell_count, mst_distance);

      gr = findHighWeightBranching(full_gr, true);

      delete full_gr;

      // Calculate the total weight of the the MST.
      double w = 0;
      for(int i2=0; i2 < tot_terminals+steiners+1; i2++){
        for(int j=0; j < tot_terminals+steiners+1; j++){
          if(gr->table_of_edges[i2][j] == NULL)
            continue;
          w += ((-1) * (gr->table_of_edges[i2][j]->weight));
        }
      }

      gr->deep_delete_nodes();
      delete gr;

      // If weight is improved, then include this candidate Steiner
      // node in the set of observed nodes if it is not already
      // present there.
      if(w < global_min){

        global_min = w;
        temp = 0;

        // Calculate the representative decimal value for the Steiner
        // node using the probe count values.
        for (int index = 0; index < probes; index++)
          temp += (result[j][index] * pow(MAX_COPY + 1,probes-index-1));

        // Check if the selected Steiner node has a match with the
        // terminal nodes or already stored Steiner nodes.
        if(!(binary_search(check_vector.begin(), check_vector.end(), temp))){

          // If the selected Steiner node is new, so push it
          // into the checking vector storage and sort the vector
          // to facilitate future search operations.
          check_vector.push_back(temp);
          sort(check_vector.begin(),check_vector.end());

          // Store the Steiner nodes in the node storage array.
          for (int index = 0; index < probes; index++){
            mst_node_store[tot_terminals+steiners][index] =
                nodes[tot_terminals+steiners][index] =
                mst_nodes[tot_terminals+steiners][index];
          }
          steiners += 1;
        }      // end of if(binary_check)
      } // end of if(w < global_min)
    } // end of for loop where each Steiner node is stored
    delete [] result;
  }   // end of outer for loop where each triplet is tested

  for (int i = 0; i < total_possible_nodes; i++)
    delete [] nodes[i];

  delete[] nodes;

  for (int i = 0; i < total_possible_nodes; i++)
    delete [] mst_nodes[i];

  delete[] mst_nodes;

  return (tot_terminals + steiners);
}

// Remove Steiner nodes with outdegree < 2 from 'gr'.
//
// - gr -- the graph
// - nodes -- the copy number counts of each node in the Steiner tree
// - tot_terminal -- the total number of observed nodes
// - total_now -- the total number of (observed + Steiner) nodes
// - probes -- the total number of probes
// - name_gene -- the name of the gene for each probes
// - cell_count -- the total number of cells belonging to each cell
//       type (including a 0 count for Steiner nodes)
// - table -- the encoded combinations of SD and GD events for each
//      pair of single gene counts
// - param -- the probability of each SD,CD and GD event
// - mincostprofile -- total counts of each event type
// - tot_scg_sets -- the total number of chromosomes with more than one
//      gene probe
// - chr_profile -a matrix indicating which probes go together on the
//      same chromosome
// - chr_indicator[i] -- 1 if probe indexed by i lies on a chromosome
//     with another gene and 0 otherwise

static graph *
remove_redundant_steiner_nodes(graph *gr, int const * const * nodes,
                               int tot_terminals, int &total_now,
                               int probes, const vec_names & name_gene,
                               const vector<int> & cell_count,
                               const sd_gd_table & table,
                               const double *param, int *mincostprofile,
                               int tot_scg_sets,
                               int const * const * chr_profile,
                               const int chr_indicator[])

{
  int **edges; //stores edges in current tree before redundant

  assert(total_now > 0);

  int old_total = total_now;
  edges = new int*[old_total];
  for (int i = 0; i < old_total; i++){
    edges[i] = new int[2];
  }

  // 'node_store' stores the copy number profiles of the nodes.

  int **node_store;
  node_store = new int*[old_total];
  for (int i = 0; i < old_total; i++){
    node_store[i] = new int[probes];
    for(int j = 0; j < probes; j++)
      node_store[i][j] = nodes[i][j];
  }

  // Copy the pairs of vertices at each edge's endpoint.
  int edge_counter = 0;
  for(int i=0; i < total_now; i++){
    for(int j = 0; j < total_now; j++){
      if(gr->table_of_edges[i][j] != NULL){
        edges[edge_counter][0] = i;
        edges[edge_counter][1] = j;
        edge_counter += 1;
      }
    }
  }

  // Use our old routine (with different arguments) to delete the
  // redundant Steiner nodes.
  int new_tot =
    delete_redundant_steiner_nodes(node_store, edges,
                                   tot_terminals, total_now,
                                   probes);

  total_now = new_tot;

  // Store cost of converting one copy number profile to another.
  double_matrix cd;
  cd.resize(total_now);
  for (int i = 0; i < total_now; ++i){
    cd[i].resize(total_now);
  }

  for(int i=0; i<total_now;i++)
    for(int j=0; j<total_now; j++)
      cd[i][j] = INF;

  // Only compute the cost for the edges after removal of the
  // redundant Steiner node.
  for(int i=0; i < total_now-1;i++)
    cd[edges[i][0]][edges[i][1]] =
      calc_mult_probe_distance(node_store[edges[i][0]],
                               node_store[edges[i][1]], probes,
                               table, param,
                               mincostprofile, tot_scg_sets,
                               chr_profile, chr_indicator);

  gr = convert_to_graph(nodes, total_now, probes, 0, name_gene,
                        cell_count, cd);

  for (int i = 0; i < old_total; i++){
    delete [] node_store[i];
    delete [] edges[i];
  }
  delete [] edges;
  delete [] node_store;

  return gr;
}


// Compute and return the minimum cost Steiner tree when single gene
// gain loss(SD), chromosome duplication(CD) and genome
// duplication(GD) are used.
//
// number_of_probes - the total number of probes listed by the user
// name_gene - the names of the gene probes
// terminals - the copy number of each gene across the cells in
//     matrix format
// cell_count - the total number of cells with each cell count pattern
// total_record - the total number of observed cell types
// tot_scg_sets - the number of sets of genes located on the same
//     chromosomes
// chr_profile - a matrix indicating which probes go together on the
//     same chromosome

graph *
generate_weighted_trees(int number_of_probes,
                        const vec_names & name_gene,
                        const int terminals[][MAX_PROBES],
                        vector<int> cell_count, int total_record,
                        int tot_scg_sets, int const * const * chr_profile)
{
  // 'total_now' is the total number of nodes at this iteration; it grows
  // as Steiner nodes are added.
  int total_now = total_record;

  // 'cell_count' is expanded to hold future Steiner nodes with 0 frequency.
  cell_count.resize(total_now+MAX_STEINER_NODES_HEURISTIC);

  for(int i=total_now; i<total_now+MAX_STEINER_NODES_HEURISTIC;i++)
    cell_count[i] = 0;

  // indicator variable that records whether a gene shares a
  // chromosome with another gene
  int chr_indicator[MAX_PROBES] = {0};

  // For each gene, we put 0 if it resides on a chromosome on which no
  // other probes used in the current run reside, and we put 1 otherwise.
  // If the chromosomes are not specified, then all probes are assumed
  // to reside on different chromosomes and tot_scg_sets should be 0.
  for(int i=0; i < tot_scg_sets; i++){
    for(int j = 1; j <= chr_profile[i][0]; j++)
      chr_indicator[chr_profile[i][j]] = 1;
  }


  // 'mincostprofile' is the total number of different event types in
  // an array.
  // The indexing is first gain for a probe then loss for  a probe
  // over all probes then gain for a chromosome followed by loss for
  // a chromosome over all chromosomes with multiple probes and
  // finally 1 for genome duplication.
  int *mincostprofile = new int[2*number_of_probes+2*tot_scg_sets+1];

  // Generate single gene based SD and GD combinations.
  sd_gd_table table;

  // 'src', 'dest' and 'param' hold the source configuration, destination
  // configuration current values of the parameters respectively.
  int *src = new int[number_of_probes];
  int *dest = new int[number_of_probes];

  // The indexing of param is first gain for a probe then loss for a
  // probe over all probes then gain for a chromosome followed by
  // loss for a chromosome over all chromosomes with multiple probes
  // and finally 1 for genome duplication.
  double *param = new double[2*number_of_probes + 2*tot_scg_sets+1];

  // the total number of events for each event type
  int *counter = new int[2*number_of_probes + 2*tot_scg_sets + 1];

  // probabilities of each gene type in the previous iteration
  double *prev_param = new double[2*number_of_probes + 2*tot_scg_sets + 1];

  // Initialize param uniformly.
  for(int i=0; i<2*number_of_probes + 2*tot_scg_sets + 1;i++){
    prev_param[i] = param[i] = 1.0/(2*number_of_probes + 2*tot_scg_sets + 1);
  }
  double difference = 0.0;

  // the pairwise weights between the nodes
  double_matrix weight;
  weight.resize(total_now);

  for (int i = 0; i < total_now; ++i)
    weight[i].resize(total_now);

  // the copy number profile of each node in the directed MST
  int **mst_node_store;

  // Initialize mst_node_store to hold the copy number profile of each
  // observed node.
  size_t size_mst_node_store = total_now + MAX_STEINER_NODES_HEURISTIC;
  mst_node_store = new int*[size_mst_node_store]();
  for (int i = 0; i < total_now + MAX_STEINER_NODES_HEURISTIC; i++){
    mst_node_store[i] = new int[number_of_probes];
    if(i < total_now){
      for(int j=0; j < number_of_probes; j++)
        mst_node_store[i][j] = terminals[i][j];
    }
  }

  // the tumor phylogenetic tree
  graph *gr = 0;

  // main loop for parameter inference procedure
  for(int looper = 0; looper < MAX_ITERATIONS; looper++){

    // temporary variable to hold total number of events
    int tot_event;

    // Initialize the counter for each event with pseudocount of 1.
    // 'tot_event' stores the sum of all entries in counter array
    // including the pseudocounts.
    for(int i=0; i < 2*number_of_probes + 2*tot_scg_sets + 1; i++)
      counter[i] = 1;
    tot_event = 2*number_of_probes + 2*tot_scg_sets + 1;

    // Iterate through each pair of nodes, calculating the weighted
    // pairwise distance based on current parameter values.
    for(int i=0; i<total_now;i++){
      for(int j=i+1; j<total_now; j++){
        if(i==j){
          weight[i][j] = INF;
          continue;
        }
        for(int k=0;k<number_of_probes;k++){
          src[k] = mst_node_store[i][k];
          dest[k] = mst_node_store[j][k];
        }
        weight[i][j] =
          calc_mult_probe_distance(src, dest, number_of_probes, table,
                                   param, mincostprofile, tot_scg_sets,
                                   chr_profile, chr_indicator);
        weight[j][i] =
          calc_mult_probe_distance(dest, src, number_of_probes, table,
                                   param, mincostprofile, tot_scg_sets,
                                   chr_profile, chr_indicator);

      } // end for j
    } // end for i


    // Infer Steiner nodes and append the set of new Steiner nodes in
    // mst_node_store. The variable 'new_total_now' gets the returned
    // total observed + Steiner nodes from the Steiner node inference
    // routine.
    int new_total_now =
        infer_steiner_nodes(total_now, number_of_probes, mst_node_store,
                            table, param, name_gene, cell_count, weight,
                            tot_scg_sets, chr_profile, chr_indicator);

    // The matrix 'cd' stores the pairwise distances between all pairs
    // of nodes (observed nodes + all inferred Steiner nodes).  The
    // distance has already been calculated in 'weight', if both nodes
    // represent observed states.  The loop bounds use the fact that
    // the newest batch of inferred Steiner nodes have higher indices
    // than the observed nodes and any Steiner nodes inferred in
    // previous iterations.
    double_matrix cd;
    cd.resize(new_total_now);
    weight.resize(new_total_now);
    for (int i = 0; i < new_total_now; ++i){
      cd[i].resize(new_total_now);
      weight[i].resize(new_total_now);
    }

    for(int i=0; i<new_total_now;i++){
      for(int j=i+1; j<new_total_now; j++){
        if(i==j){
          cd[i][j] = INF;
          continue;
        }
        // Skip calculating the distance already been calculated.
        if((i<total_now) && (j<total_now)){
          cd[i][j] = weight[i][j];
          cd[j][i] = weight[j][i];
          continue;
        }

        cd[i][j] =
            calc_mult_probe_distance(mst_node_store[i], mst_node_store[j],
                                     number_of_probes, table, param,
                                     mincostprofile, tot_scg_sets,
                                     chr_profile, chr_indicator);
        cd[j][i] =
            calc_mult_probe_distance(mst_node_store[j], mst_node_store[i],
                                     number_of_probes, table, param,
                                     mincostprofile, tot_scg_sets,
                                     chr_profile, chr_indicator);
      }
    }
    total_now = new_total_now;

    // Create the complete graph using the copy number profiles stored
    // in 'mst_node_store' and weight values in 'cd'.
    graph * full_gr =
      convert_to_graph(mst_node_store, total_now, number_of_probes,
                       0, name_gene, cell_count, cd);

    // Compute directed MST.
    if (gr) {
      gr->deep_delete_nodes();
      delete gr;
    }
    gr = findHighWeightBranching(full_gr, true);

    delete full_gr;

    // Go through each edge in 'gr' and calculate the occurrences of
    // different events to estimate new values for the parameters.
    for(int i=0; i < total_now; i++){
      for(int j=0; j < total_now; j++){
        if(gr->table_of_edges[i][j] == NULL)
          continue;
        for(int k=0;k<number_of_probes;k++){
          src[k] = mst_node_store[i][k];
          dest[k] = mst_node_store[j][k];
        } // end for (k)
        calc_mult_probe_distance(src, dest, number_of_probes, table,
                                 param, mincostprofile, tot_scg_sets,
                                 chr_profile, chr_indicator);

        // Store event counts related to each edge in counter array.
        for(int q=0; q <2*number_of_probes + 2*tot_scg_sets + 1;q++){
          counter[q] += mincostprofile[q];
          tot_event += mincostprofile[q];
        }
      } // end for j
    } // end for i

    // Calculate parameter values and test how different the new
    // parameter values are compared to the previous iteration.
    difference = 0.0;
    for(int q=0; q < 2*number_of_probes + 2*tot_scg_sets + 1; q++){
      param[q] = (double)counter[q]/tot_event;
      if(param[q] >= prev_param[q])
        difference = difference + (param[q] - prev_param[q]);
      else
        difference = difference + (prev_param[q] - param[q]);
      prev_param[q] = param[q];
    }


    // If MAX_ITERATIONS is reached or convergence is achieved, then
    // stop the iteration.
    if((looper == MAX_ITERATIONS-1) || (difference <= THR)){
      cout << "\nPloidyless weighted method: mutation types and inferred probabilities\n";
      cout << "Single gene gains and losses:\n";
      for(int q=0; q < number_of_probes; q++){
	cout << name_gene[q] << ".loss" << "\t" << name_gene[q] << ".gain" << "\t";
      }
      cout << endl;
      for(int q=0; q < number_of_probes; q++){
	cout << param[2 * q +1] << "\t" << param[2*q] << "\t";
      }
      cout << endl;

      if (tot_scg_sets > 0) {
	cout << "Loss and Gain probabilities of each chromosome with multiple probes =\n";
      }
      else {
	cout << "There is no chromosome with multiple probes\n";
      }
      for(int q=2*number_of_probes; q < ((2*number_of_probes) + (2*tot_scg_sets)); q+=2){
        cout << param[q+1] << "\t" << param[q] << endl;
      }
      cout << "Probability of whole genome duplication =\n";
      cout << param[(2*number_of_probes) + (2*tot_scg_sets)] << endl;

      // Remove Steiner nodes with outdegree < 2.

      graph * new_gr =
        remove_redundant_steiner_nodes(gr, mst_node_store, total_record,
                                       total_now, number_of_probes,
                                       name_gene,  cell_count,
                                       table, param, mincostprofile,
                                       tot_scg_sets, chr_profile,
                                       chr_indicator);
      gr->deep_delete_nodes();
      delete gr;
      gr = new_gr;

      break;
    }
  } // end (for looper)

  delete[] src;
  delete[] dest;
  delete[] param;
  delete[] mincostprofile;
  delete[] counter;
  delete[] prev_param;

  // Multiply the edge weight by -1 for each edge in the returned
  // graph.  The sign of weights had been reversed because the code to
  // find maximum weight branching was used to find the minimum cost
  // Steiner tree.
  for(int i=0; i < total_now; i++){
    for(int j=0; j < total_now; j++){
      if(gr->table_of_edges[i][j] == NULL)
        continue;
      gr->table_of_edges[i][j]->weight = -gr->table_of_edges[i][j]->weight;
    }
  }

  for (size_t i = 0; i < size_mst_node_store; i++) {
    delete [] mst_node_store[i];
  }
  delete [] mst_node_store;

  // Return lowest cost inferred Steiner tree.
  return gr;
}
